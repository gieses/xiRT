"""Exercise FAIMS report inspection without downloading data or training models."""

import json
import runpy
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
import torch

from xirt.faims import FAIMSPredictor

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def reports(tmp_path):
    directory = tmp_path / "reports"
    directory.mkdir()
    (directory / "completion.json").write_text("{}")
    (directory / "manifest.json").write_text(
        json.dumps({"protocol": {"upstream_revision": "synthetic-notebook-test"}})
    )
    (directory / "data_audit.json").write_text(
        json.dumps([{"source": "synthetic", "raw_observations": 20, "precursors": 6}])
    )
    (directory / "transfer_audit.json").write_text(
        json.dumps(
            [{"source": "pooled_4pm_8pm", "target": "26s", "excluded_shared_pair_precursors": 0}]
        )
    )
    metric_rows, run_rows = [], []
    for cohort in ("pooled_4pm_8pm", "26s", "293t"):
        pd.DataFrame(
            {
                "precursor_id": ["a", "b", "c"],
                "pair_group": ["a", "b", "c"],
                "source": cohort,
                "split": ["train", "validation", "test"],
            }
        ).to_csv(directory / f"{cohort}__partitions.csv", index=False)
        for model in ("xirt_precursor", "xirt_sequence_only"):
            for seed in (17, 42, 73):
                pd.DataFrame(
                    {
                        "loss": [1.0, 0.8],
                        "val_loss": [1.1, 0.9],
                        "target_scale_v": [10, 10],
                    }
                ).to_csv(directory / f"{cohort}__{model}__{seed}__history.csv", index=False)
                run_rows.append(
                    {
                        "cohort": cohort,
                        "model": model,
                        "seed": seed,
                        "epochs": 2,
                        "best_epoch": 2,
                    }
                )
                pd.DataFrame(
                    {
                        "faims_cv": [-60, -50, -40],
                        "faims_cv_prediction_v": [-58, -52, -42],
                        "precursor_charge": [3, 4, 4],
                        "unknown_token_count": [0, 0, 0],
                    }
                ).to_csv(directory / f"{cohort}__{model}__{seed}__test.csv", index=False)
                for evaluation in ("test", "transfer_26s"):
                    for stratification, stratum in (
                        ("all", "all"),
                        ("token_coverage", "known_only"),
                        ("precursor_charge", "3"),
                    ):
                        metric_rows.append(
                            {
                                "cohort": cohort,
                                "model": model,
                                "seed": seed,
                                "evaluation": evaluation,
                                "stratification": stratification,
                                "stratum": stratum,
                                "n": 3,
                                "rmse_v": 2.0,
                                "mae_v": 2.0,
                                "r2": 0.94,
                                "unknown_precursors": 0,
                            }
                        )
    pd.DataFrame(metric_rows).to_csv(directory / "metrics.csv", index=False)
    pd.DataFrame(run_rows).to_csv(directory / "runs.csv", index=False)
    import matplotlib.pyplot as plt

    figure, axis = plt.subplots()
    axis.plot([1, 2], [3, 4])
    figure.savefig(directory / "heldout_rmse.png")
    plt.close(figure)
    return directory


def test_report_notebook_executes_without_weights_or_training(reports, tmp_path, monkeypatch):
    def no_training(*args, **kwargs):
        pytest.fail("Opening the inspection notebook must not start training.")

    monkeypatch.setattr(FAIMSPredictor, "fit", no_training)
    app = runpy.run_path(str(ROOT / "examples/faims.py"))["app"]
    _, definitions = app.run(defs={"reports": reports, "work": tmp_path / "missing-weights"})
    assert len(definitions["summary"]) == 6
    assert np.isfinite(definitions["summary"]["rmse_v"]).all()
    assert not definitions["demo_button"].value
    assert len(definitions["test_predictions"]) == 3


def test_report_notebook_requires_completed_evidence(tmp_path):
    app = runpy.run_path(str(ROOT / "examples/faims.py"))["app"]
    with pytest.raises(FileNotFoundError, match="Completed FAIMS reports"):
        app.run(defs={"reports": tmp_path, "work": tmp_path / "weights"})


def test_training_demo_requires_explicit_button_and_uses_two_epochs(reports, tmp_path, monkeypatch):
    work = tmp_path / "work"
    work.mkdir()
    pd.DataFrame(
        {
            "peptide1": ["AK", "CK", "DK", "EK", "FK", "GK", "HK", "IK"],
            "peptide2": ["PEPK"] * 8,
            "link_pos1": [2] * 8,
            "link_pos2": [4] * 8,
            "precursor_charge": [3] * 8,
            "precursor_mz": [700.0] * 8,
            "precursor_mass": [2100.0] * 8,
            "faims_cv": [-45, -50, -40, -55, -45, -60, -50, -40],
            "split": ["train"] * 4 + ["validation"] * 2 + ["test"] * 2,
        }
    ).to_csv(work / "pooled_4pm_8pm__precursors.csv", index=False)
    fit = FAIMSPredictor.fit
    trained = []

    def record_fit(model, train, validation, **kwargs):
        result = fit(model, train, validation, **kwargs)
        trained.append(result)
        assert len(train) == 4 and len(validation) == 2
        return result

    monkeypatch.setattr(FAIMSPredictor, "fit", record_fit)
    torch.set_num_threads(2)
    app = runpy.run_path(str(ROOT / "examples/faims.py"))["app"]
    app.run(
        defs={
            "reports": reports,
            "work": work,
            "demo_button": SimpleNamespace(value=True),
        }
    )
    assert len(trained) == 1
    assert trained[0].params["learning"]["epochs"] == 2
    assert len(trained[0].history["loss"]) == 2
