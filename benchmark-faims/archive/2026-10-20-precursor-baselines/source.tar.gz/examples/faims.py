"""Inspect the frozen xiFAIMS CV experiment without rerunning model training."""

import marimo

__generated_with = "0.25.1"
app = marimo.App(width="full")


@app.cell
def introduction():
    import marimo as mo

    mo.md("""
    # Crosslinked-peptide FAIMS compensation voltage

    **The output is CV in volts, not collision cross section (CCS).**
    This notebook inspects the frozen xiRT/xiFAIMS comparison: original 4PM+8PM,
    26S and 293T cohorts, two recurrent models, three initialization seeds and
    three feature-based baselines. Opening it does **not** download data or
    rerun the benchmark. The optional training demo requires a button click.

    Target: the CSM-weighted **mean observed CV** for each modified crosslink,
    link-site pair and charge. Multiple transmission settings can identify the
    same precursor; these data do not establish an intensity-calibrated optimum.
    """)
    return (mo,)


@app.cell
def inputs():
    import json
    from pathlib import Path

    import matplotlib.pyplot as plt
    import numpy as np
    import pandas as pd

    from xirt.faims import FAIMSPredictor, default_faims_params

    root = Path(__file__).resolve().parents[1]
    return FAIMSPredictor, default_faims_params, json, np, pd, plt, root


@app.cell
def artifact_directories(root):
    reports = root / "benchmark-faims/reports"
    work = root / "local-data/faims"
    return reports, work


@app.cell
def completed_reports(json, pd, reports):
    if not (reports / "completion.json").is_file():
        raise FileNotFoundError(
            "Completed FAIMS reports are required. From a source checkout run "
            "`python -m xirt.data_pipelines.benchmarks.faims.run` after placing "
            "the pinned CSVs in local-data/xifaims/<revision>/; see benchmark-faims/README.md."
        )
    manifest = json.loads((reports / "manifest.json").read_text())
    audits = pd.DataFrame(json.loads((reports / "data_audit.json").read_text()))
    metrics = pd.read_csv(reports / "metrics.csv")
    runs = pd.read_csv(reports / "runs.csv")
    return audits, manifest, metrics, runs


@app.cell
def protocol(audits, manifest, mo):
    mo.vstack(
        [
            mo.md(f"""
        ## Provenance and target audit

        Upstream: [Rappsilber-Laboratory/xiFAIMS](https://github.com/Rappsilber-Laboratory/xiFAIMS),
        Apache-2.0, pinned revision `{manifest["protocol"]["upstream_revision"]}`.
        Dataset SHA-256 values, code hashes, package versions and all model
        settings are in `benchmark-faims/reports/manifest.json`.

        The combined 4PM/8PM CSV overlaps the originals and is **excluded**.
        Only explicit target-target identifications with FDR <= 0.01 are retained.
        `ambiguous_precursors` counts precursors observed at multiple CV settings.
        """),
            mo.ui.table(audits, selection=None),
        ]
    )
    return


@app.cell
def split_checks(mo, pd, reports):
    split_rows = []
    for _name in ("pooled_4pm_8pm", "26s", "293t"):
        _partition = pd.read_csv(reports / f"{_name}__partitions.csv")
        assert _partition.groupby("pair_group")["split"].nunique().max() == 1
        for _split, _part in _partition.groupby("split"):
            split_rows.append(
                {
                    "cohort": _name,
                    "split": _split,
                    "precursors": len(_part),
                    "unmodified_pairs": _part["pair_group"].nunique(),
                }
            )
    split_table = pd.DataFrame(split_rows)
    mo.vstack(
        [
            mo.md("""
        ## Leakage controls

        Fixed seed-42 splits use 75/12.5/12.5% of unordered **unmodified pairs**.
        All charges, PTMs and sites for a pair stay together. Pair overlap is
        asserted above. Individual peptides, proteins and runs are not held out.
        Vocabulary, numeric scaling and target scaling use training rows only.
        Validation selects the checkpoint; the test set never controls training.
        """),
            mo.ui.table(split_table, selection=None),
        ]
    )
    return


@app.cell
def controls(metrics, mo):
    cohort_picker = mo.ui.dropdown(
        options=list(metrics["cohort"].drop_duplicates()), value="pooled_4pm_8pm", label="Cohort"
    )
    seed_picker = mo.ui.dropdown(options=[17, 42, 73], value=42, label="Initialization seed")
    mo.hstack([cohort_picker, seed_picker])
    return cohort_picker, seed_picker


@app.cell
def comparisons(cohort_picker, metrics, mo, pd, reports, runs):
    heldout = metrics.loc[(metrics["evaluation"] == "test") & (metrics["stratification"] == "all")]
    summary = (
        heldout.groupby(["cohort", "model"], sort=False)
        .agg(
            rmse_v=("rmse_v", "mean"),
            rmse_seed_sd_v=("rmse_v", "std"),
            mae_v=("mae_v", "mean"),
            r2=("r2", "mean"),
            test_precursors=("n", "first"),
        )
        .reset_index()
    )
    mo.vstack(
        [
            mo.md("""
        ## Held-out comparison

        Recurrent rows average three initializations on the **same fixed split**.
        Seed SD measures optimization variation, not biological replication or
        a confidence interval. Baselines run once; their SD is undefined.
        The descriptor tree is sklearn HistGradientBoosting, **not** a claimed
        reproduction of upstream XGBoost/hyperparameter search.
        """),
            mo.ui.table(summary.loc[summary["cohort"] == cohort_picker.value], selection=None),
            mo.image(reports / "heldout_rmse.png"),
            mo.md("### Executed epochs and restored validation-best epochs"),
            mo.ui.table(runs.loc[runs["cohort"] == cohort_picker.value], selection=None),
        ]
    )
    return (summary,)


@app.cell
def learning_curves(cohort_picker, pd, plt, reports, seed_picker):
    learning_figure, learning_axis = plt.subplots(figsize=(7, 4))
    for _model in ("xirt_precursor", "xirt_sequence_only"):
        _history = pd.read_csv(
            reports / f"{cohort_picker.value}__{_model}__{seed_picker.value}__history.csv"
        )
        _scale = _history["target_scale_v"].iloc[0]
        learning_axis.plot(
            _history.index + 1,
            _history["loss"].pow(0.5) * _scale,
            label=f"{_model}: training",
        )
        learning_axis.plot(
            _history.index + 1,
            _history["val_loss"].pow(0.5) * _scale,
            linestyle="--",
            label=f"{_model}: validation",
        )
    learning_axis.set(xlabel="Epoch", ylabel="RMSE (V)", title="Learning curves")
    learning_axis.legend(fontsize=8)
    learning_figure
    return


@app.cell
def predictions(cohort_picker, np, pd, plt, reports, seed_picker):
    test_predictions = pd.read_csv(
        reports / f"{cohort_picker.value}__xirt_precursor__{seed_picker.value}__test.csv"
    )
    prediction_figure, prediction_axes = plt.subplots(1, 3, figsize=(15, 4), layout="constrained")
    _actual = test_predictions["faims_cv"]
    _predicted = test_predictions["faims_cv_prediction_v"]
    _scatter = prediction_axes[0].scatter(
        _actual, _predicted, c=test_predictions["precursor_charge"], s=15, alpha=0.6
    )
    _limits = [min(_actual.min(), _predicted.min()), max(_actual.max(), _predicted.max())]
    prediction_axes[0].plot(_limits, _limits, "--", color="black")
    prediction_axes[0].set(xlabel="Observed mean CV (V)", ylabel="Predicted CV (V)")
    prediction_figure.colorbar(_scatter, ax=prediction_axes[0], label="Charge")
    prediction_axes[1].scatter(_actual, _predicted - _actual, s=15, alpha=0.6)
    prediction_axes[1].axhline(0, color="black", linestyle="--")
    prediction_axes[1].set(xlabel="Observed mean CV (V)", ylabel="Residual (V)")
    _charge_errors = (
        test_predictions.assign(absolute_error_v=np.abs(_predicted - _actual))
        .groupby("precursor_charge")["absolute_error_v"]
        .mean()
    )
    prediction_axes[2].bar(_charge_errors.index.astype(str), _charge_errors.values)
    prediction_axes[2].set(xlabel="Charge", ylabel="MAE (V)", title="Held-out charge dependence")
    prediction_figure
    return (test_predictions,)


@app.cell
def strata(cohort_picker, metrics, mo, seed_picker):
    mo.vstack(
        [
            mo.md("### Charge/source strata (small strata need cautious interpretation)"),
            mo.ui.table(
                metrics.loc[
                    (metrics["cohort"] == cohort_picker.value)
                    & (metrics["evaluation"] == "test")
                    & (metrics["seed"] == seed_picker.value)
                    & metrics["stratification"].isin(["precursor_charge", "source"])
                ],
                selection=None,
            ),
        ]
    )
    return


@app.cell
def transfer(json, metrics, mo, pd, reports):
    transfer_table = metrics.loc[
        metrics["evaluation"].str.startswith("transfer_")
        & metrics["stratification"].isin(["all", "token_coverage"])
    ]
    transfer_summary = (
        transfer_table.groupby(["evaluation", "model", "stratification", "stratum"], sort=False)
        .agg(
            n=("n", "first"),
            rmse_v=("rmse_v", "mean"),
            mae_v=("mae_v", "mean"),
            r2=("r2", "mean"),
            unknown_precursors=("unknown_precursors", "first"),
        )
        .reset_index()
    )
    mo.vstack(
        [
            mo.md("""
        ## Zero-shot transfer: pooled 4PM+8PM to 26S / 293T

        No target-cohort labels are used to fit these predictions. All eligible
        target-cohort rows are evaluated (including that cohort's local training
        rows); this is distinct from its within-cohort held-out test. Shared
        unmodified pairs are removed against the entire pooled cohort.

        `all` includes unknown PTMs mapped to the explicit reserved token.
        `known_only` is a coverage subset, not a competing model or a correction.
        The unknown embedding may be untrained; inspect the coverage counts.
        Crosslinker, protein mixture and acquisition changes can reduce transfer.
        """),
            mo.ui.table(transfer_summary, selection=None),
            mo.ui.table(
                pd.DataFrame(json.loads((reports / "transfer_audit.json").read_text())),
                selection=None,
            ),
        ]
    )
    return


@app.cell
def checkpoint_demo(FAIMSPredictor, cohort_picker, mo, pd, seed_picker, work):
    _checkpoint = work / f"{cohort_picker.value}__xirt_precursor__{seed_picker.value}.pt"
    _data_path = work / f"{cohort_picker.value}__precursors.csv"
    if _checkpoint.is_file() and _data_path.is_file():
        restored = FAIMSPredictor.load(_checkpoint)
        _table = pd.read_csv(_data_path)
        minimal_inputs = _table.loc[
            _table["split"] == "test",
            [
                "peptide1",
                "peptide2",
                "link_pos1",
                "link_pos2",
                "precursor_charge",
                "precursor_mz",
                "precursor_mass",
            ],
        ].head(5)
        inference_example = minimal_inputs.join(restored.predict(minimal_inputs))
        checkpoint_display = mo.vstack(
            [
                mo.md("## Checkpoint inference without run names, FDR or target CV"),
                mo.ui.table(inference_example, selection=None),
            ]
        )
    else:
        checkpoint_display = mo.md("""
        ## Local checkpoints are not present

        Reports remain inspectable without weights. Reproduce the benchmark
        to generate `local-data/faims/*.pt`; weights and raw CSVs are not committed.
        """)
    checkpoint_display
    return


@app.cell
def demo_control(mo):
    demo_button = mo.ui.run_button(label="Run a two-epoch API training demonstration")
    mo.vstack(
        [
            mo.md("""
        ## Optional API training demonstration

        Uses at most 40 training and 12 disjoint validation precursors from the
        selected cohort. This is an execution example, **not** a new benchmark.
        The full reproduction command is shown below.
        """),
            demo_button,
        ]
    )
    return (demo_button,)


@app.cell
def training_demo(FAIMSPredictor, cohort_picker, default_faims_params, demo_button, mo, pd, work):
    if demo_button.value:
        _path = work / f"{cohort_picker.value}__precursors.csv"
        if not _path.is_file():
            raise FileNotFoundError(
                "Reproduce the benchmark to prepare the local precursor tables."
            )
        _data = pd.read_csv(_path)
        _params = default_faims_params()
        _params["learning"]["epochs"] = 2
        _demo = FAIMSPredictor(_params).fit(
            _data.loc[_data["split"] == "train"].head(40),
            _data.loc[_data["split"] == "validation"].head(12),
        )
        demo_display = mo.ui.table(pd.DataFrame(_demo.history), selection=None)
    else:
        demo_display = mo.md("Training is idle. No benchmark or download is started automatically.")
    demo_display
    return


@app.cell
def limitations(mo):
    mo.md("""
    ## Interpretation and reproduction

    - Negative CV is the instrument setting in **volts**; no CCS calibration is available.
    - Labels are means of detected CSM settings, not abundance-weighted transmission optima.
    - Pair grouping prevents exact-pair leakage, not shared-peptide/protein/run effects.
    - Three seeds share one partition; results do not establish generalization to new instruments.
    - No test-driven model selection, confidence intervals or superiority claims are implied.
    - PTMs seen only outside training use a counted unknown token; known-only transfer is conditional.
    - The small 293T cohort and charge strata can have high sampling uncertainty.

    Full experiment from the locked source checkout after preparing the pinned data:

    ```bash
    uv run --no-sync python -m xirt.data_pipelines.benchmarks.faims.run
    uv run --no-sync marimo edit examples/faims.py --host 127.0.0.1
    ```

    See `benchmark-faims/README.md` for the predeclared plan, checksums, exclusions,
    complete commands and artifact layout. Existing reports are resumed only
    when the frozen protocol, code hashes and environment manifest match.
    """)
    return


if __name__ == "__main__":
    app.run()
