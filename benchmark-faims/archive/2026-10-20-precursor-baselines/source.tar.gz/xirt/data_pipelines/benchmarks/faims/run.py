"""Execute the frozen FAIMS protocol on verified local xiFAIMS CSV files.

Run from a source checkout; raw observations and tensor checkpoints remain in
ignored local-data while compact evaluation evidence is written to reports.
"""

import argparse
import hashlib
import json
import logging
import platform
import subprocess
import time
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
import torch
from sklearn.ensemble import HistGradientBoostingRegressor
from threadpoolctl import threadpool_limits

from xirt.faims import (
    FAIMSPredictor,
    cv_metrics,
    default_faims_params,
    precursor_descriptors,
    prepare_faims_observations,
    split_precursors,
)

ROOT = Path(__file__).resolve().parents[4]
logger = logging.getLogger(__name__)


def write_json(path: Path, data: Any) -> None:
    """Write strict JSON suitable for notebook inspection and archival."""
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")


def sha256(path: Path) -> str:
    """Hash a source, dataset or checkpoint."""
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def record_metrics(frame: pd.DataFrame, **labels: Any) -> list[dict[str, Any]]:
    """Evaluate the whole prediction set and prespecified strata."""
    rows = []
    subsets = [("all", "all", frame)]
    for column in ("precursor_charge", "source"):
        subsets.extend((column, str(key), part) for key, part in frame.groupby(column))
    subsets.append(("token_coverage", "known_only", frame.loc[frame["unknown_token_count"] == 0]))
    for stratification, value, subset in subsets:
        if len(subset):
            rows.append(
                {
                    **labels,
                    "stratification": stratification,
                    "stratum": value,
                    **cv_metrics(subset["faims_cv"], subset["faims_cv_prediction_v"]),
                    "unknown_precursors": int((subset["unknown_token_count"] > 0).sum()),
                }
            )
    return rows


def evaluation_table(data: pd.DataFrame, predictions: Any, unknown: Any = None) -> pd.DataFrame:
    """Keep stable IDs and evaluation labels, not raw identification metadata."""
    columns = [
        "precursor_id",
        "source",
        "pair_group",
        "precursor_charge",
        "faims_cv",
        "observation_count",
        "distinct_cv_count",
        "cv_spread_v",
    ]
    result = data[columns].copy()
    result["faims_cv_prediction_v"] = np.asarray(predictions)
    result["unknown_token_count"] = 0 if unknown is None else np.asarray(unknown)
    return result


def make_plots(reports: Path) -> None:
    """Plot fixed-seed held-out errors and all recurrent learning curves."""
    metrics = pd.read_csv(reports / "metrics.csv")
    heldout = metrics.loc[(metrics["evaluation"] == "test") & (metrics["stratification"] == "all")]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4), constrained_layout=True)
    for ax, (cohort, group) in zip(axes, heldout.groupby("cohort", sort=False)):
        summary = group.groupby("model", sort=False)["rmse_v"].agg(["mean", "std"]).fillna(0)
        ax.barh(summary.index, summary["mean"], xerr=summary["std"])
        ax.set(title=cohort, xlabel="Held-out RMSE (V)")
    fig.savefig(reports / "heldout_rmse.png", dpi=150)
    plt.close(fig)
    fig, axes = plt.subplots(1, 3, figsize=(14, 4), constrained_layout=True)
    for ax, cohort in zip(axes, heldout["cohort"].drop_duplicates()):
        for model in ("xirt_precursor", "xirt_sequence_only"):
            for seed in (17, 42, 73):
                history = pd.read_csv(reports / f"{cohort}__{model}__{seed}__history.csv")
                ax.plot(
                    history.index + 1,
                    np.sqrt(history["val_loss"]) * history["target_scale_v"].iloc[0],
                    label=model if seed == 17 else None,
                    alpha=0.6,
                )
        ax.set(title=cohort, xlabel="Epoch", ylabel="Validation RMSE (V)")
        ax.legend(fontsize=7)
    fig.savefig(reports / "learning_curves.png", dpi=150)
    plt.close(fig)
    fig, axes = plt.subplots(2, 3, figsize=(12, 7), constrained_layout=True)
    for column, cohort in enumerate(heldout["cohort"].drop_duplicates()):
        data = pd.read_csv(reports / f"{cohort}__xirt_precursor__42__test.csv")
        actual, predicted = data["faims_cv"], data["faims_cv_prediction_v"]
        axes[0, column].scatter(actual, predicted, c=data["precursor_charge"], s=10, alpha=0.5)
        limits = [min(actual.min(), predicted.min()), max(actual.max(), predicted.max())]
        axes[0, column].plot(limits, limits, color="black", linestyle="--")
        axes[0, column].set(title=cohort, xlabel="Observed mean CV (V)", ylabel="Predicted CV (V)")
        axes[1, column].scatter(actual, predicted - actual, s=10, alpha=0.5)
        axes[1, column].axhline(0, color="black", linestyle="--")
        axes[1, column].set(xlabel="Observed mean CV (V)", ylabel="Prediction − observation (V)")
    fig.savefig(reports / "heldout_predictions.png", dpi=150)
    plt.close(fig)


def run(args: argparse.Namespace) -> None:
    """Verify inputs and protocol before any model sees training data."""
    protocol = json.loads(args.protocol.read_text())
    torch.set_num_threads(protocol["training"]["cpu_threads"])
    args.reports.mkdir(parents=True, exist_ok=True)
    args.work.mkdir(parents=True, exist_ok=True)
    source_files = [
        ROOT / "xirt/faims.py",
        ROOT / "xirt/xirtnet.py",
        ROOT / "xirt/config.py",
        ROOT / "xirt/training.py",
        ROOT / "xirt/processing.py",
        ROOT / "xirt/sequences.py",
        Path(__file__),
    ]
    hashes = {str(path.relative_to(ROOT)): sha256(path) for path in source_files}
    data, audits = {}, []
    for name, spec in protocol["datasets"].items():
        path = args.data / spec["file"]
        if sha256(path) != spec["sha256"]:
            raise ValueError(f"Dataset checksum mismatch: {path}")
        data[name], audit = prepare_faims_observations(
            pd.read_csv(path), name, maximum_fdr=protocol["target"]["maximum_fdr"]
        )
        audits.append(audit)
    cohorts = {
        name: split_precursors(
            pd.concat([data[source] for source in sources], ignore_index=True),
            seed=protocol["split"]["seed"],
            fractions=tuple(protocol["split"]["fractions"]),
        )
        for name, sources in protocol["training_cohorts"].items()
    }
    manifest = {
        "protocol": protocol,
        "source_sha256": hashes,
        "git_base": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip(),
        "python": platform.python_version(),
        "torch": str(torch.__version__),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "sklearn": sklearn.__version__,
        "device": "cpu",
        "threads": torch.get_num_threads(),
        "test_used_for_selection": False,
    }
    manifest_path = args.reports / "manifest.json"
    if manifest_path.exists():
        if json.loads(manifest_path.read_text()) != manifest:
            raise ValueError(
                "Existing experiment manifest differs; choose fresh work/reports paths."
            )
    else:
        write_json(manifest_path, manifest)
    write_json(args.reports / "data_audit.json", audits)
    for name, cohort in cohorts.items():
        cohort.to_csv(args.work / f"{name}__precursors.csv", index=False)
        cohort[["precursor_id", "pair_group", "source", "split"]].to_csv(
            args.reports / f"{name}__partitions.csv", index=False
        )
        assert cohort.groupby("pair_group")["split"].nunique().max() == 1
    metrics: list[dict[str, Any]] = []
    runs = []
    transfer_audit = []
    for cohort_name, cohort in cohorts.items():
        train = cohort.loc[cohort["split"] == "train"]
        validation = cohort.loc[cohort["split"] == "validation"]
        test = cohort.loc[cohort["split"] == "test"]
        evaluations = {"test": test}
        if cohort_name == protocol["transfer"]["source"]:
            for target in protocol["transfer"]["targets"]:
                external = cohorts[target]
                keep = ~external["pair_group"].isin(set(cohort["pair_group"]))
                evaluations[f"transfer_{target}"] = external.loc[keep]
                transfer_audit.append(
                    {
                        "source": cohort_name,
                        "target": target,
                        "excluded_shared_pair_precursors": int((~keep).sum()),
                        "evaluated_precursors": int(keep.sum()),
                    }
                )
        for model_name in protocol["models"]:
            for seed in protocol["initialization_seeds"]:
                tag = f"{cohort_name}__{model_name}__{seed}"
                checkpoint = args.work / f"{tag}.pt"
                history_path = args.reports / f"{tag}__history.csv"
                status_path = args.reports / f"{tag}__run.json"
                if status_path.exists():
                    status = json.loads(status_path.read_text())
                    if sha256(checkpoint) != status["checkpoint_sha256"]:
                        raise ValueError(f"Checkpoint changed: {checkpoint}")
                    predictor = FAIMSPredictor.load(checkpoint)
                else:
                    params = default_faims_params(
                        seed=seed, precursor_features=model_name == "xirt_precursor"
                    )
                    assert params["learning"]["epochs"] == protocol["training"]["maximum_epochs"]
                    started = time.monotonic()
                    predictor = FAIMSPredictor(params).fit(train, validation)
                    predictor.save(checkpoint)
                    history = pd.DataFrame(predictor.history)
                    history["target_scale_v"] = predictor.metadata["target_scale"]
                    history.to_csv(history_path, index=False)
                    status = {
                        "cohort": cohort_name,
                        "model": model_name,
                        "seed": seed,
                        "epochs": len(history),
                        "best_epoch": int(history["val_loss"].argmin()) + 1,
                        "seconds": time.monotonic() - started,
                        "checkpoint_sha256": sha256(checkpoint),
                        "checkpoint": str(checkpoint.relative_to(ROOT)),
                        "params": predictor.model.params,
                    }
                    write_json(status_path, status)
                runs.append({k: v for k, v in status.items() if k != "params"})
                for evaluation, subset in evaluations.items():
                    prediction = predictor.predict(subset)
                    result = evaluation_table(
                        subset,
                        prediction["faims_cv_prediction_v"],
                        prediction["unknown_token_count"],
                    )
                    result.to_csv(args.reports / f"{tag}__{evaluation}.csv", index=False)
                    rows = record_metrics(
                        result,
                        cohort=cohort_name,
                        model=model_name,
                        seed=seed,
                        evaluation=evaluation,
                    )
                    metrics.extend(rows)
                logger.info("%s: epochs=%s best=%s", tag, status["epochs"], status["best_epoch"])
                pd.DataFrame(metrics).to_csv(args.reports / "metrics.csv", index=False)
        descriptors = precursor_descriptors(train)
        with threadpool_limits(limits=protocol["training"]["cpu_threads"]):
            tree = HistGradientBoostingRegressor(**protocol["evaluation"]["tree_parameters"]).fit(
                descriptors, train["faims_cv"]
            )
            global_mean = float(train["faims_cv"].mean())
            charge_means = train.groupby("precursor_charge")["faims_cv"].mean()
            for name in protocol["baselines"]:
                for evaluation, subset in evaluations.items():
                    if name == "training_mean":
                        prediction = np.full(len(subset), global_mean)
                    elif name == "charge_mean":
                        prediction = (
                            subset["precursor_charge"].map(charge_means).fillna(global_mean)
                        )
                    elif name == "hist_gradient_boosting":
                        prediction = tree.predict(precursor_descriptors(subset))
                    else:
                        raise ValueError(f"Unknown baseline: {name}")
                    result = evaluation_table(subset, prediction)
                    result.to_csv(
                        args.reports / f"{cohort_name}__{name}__42__{evaluation}.csv", index=False
                    )
                    metrics.extend(
                        record_metrics(
                            result, cohort=cohort_name, model=name, seed=42, evaluation=evaluation
                        )
                    )
        pd.DataFrame(metrics).to_csv(args.reports / "metrics.csv", index=False)
    pd.DataFrame(runs).to_csv(args.reports / "runs.csv", index=False)
    write_json(args.reports / "transfer_audit.json", transfer_audit)
    metric_frame = pd.DataFrame(metrics)
    summary = (
        metric_frame.loc[metric_frame["stratification"] == "all"]
        .groupby(["cohort", "model", "evaluation"], sort=False)[["rmse_v", "mae_v", "r2"]]
        .agg(["mean", "std"])
    )
    summary.to_csv(args.reports / "summary.csv")
    make_plots(args.reports)
    write_json(
        args.reports / "completion.json",
        {
            "recurrent_runs": len(runs),
            "protocol_sha256": sha256(args.protocol),
            "report_files": sorted(path.name for path in args.reports.iterdir() if path.is_file()),
        },
    )
    print(summary.to_string())


def main() -> None:
    """Resolve checkout-local defaults and run the complete experiment."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--protocol", type=Path, default=ROOT / "benchmark-faims/protocol.json")
    parser.add_argument(
        "--data",
        type=Path,
        default=ROOT / "local-data/xifaims/b85482ffc246b2dc669c4592f752568fd9b1baed",
    )
    parser.add_argument("--work", type=Path, default=ROOT / "local-data/faims")
    parser.add_argument("--reports", type=Path, default=ROOT / "benchmark-faims/reports")
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
    run(parser.parse_args())


if __name__ == "__main__":
    main()
