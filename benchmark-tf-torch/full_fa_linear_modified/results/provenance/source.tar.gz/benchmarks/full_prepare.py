"""Prepare all model-ready linked tables, without counting source variants as studies."""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import re
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from benchmarks.run import LEGACY, ROOT, SEEDS, configuration, digest, write_json


def main() -> None:
    """Prepare complete PTM-aware and originally unmodified source views.

    >>> callable(main)
    True
    """
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("--only", nargs="+", default=[])
    cli.add_argument("--output-root", type=Path, default=ROOT / "benchmarks/results")
    cli.add_argument("--split-seed", type=int, default=20261012)
    cli.add_argument("--max-groups", type=int, default=0, help="Explicit smoke scope, zero uses all")
    cli.add_argument("--pilot-manifest", type=Path, default=ROOT / "benchmarks/results/pairs.csv")
    cli.add_argument("--views", nargs="+", choices=["modified", "canonical"],
                     default=["modified", "canonical"])
    args = cli.parse_args()
    args.output_root = args.output_root.resolve()
    if not args.output_root.is_relative_to(ROOT / "benchmarks"):
        raise ValueError("Prepared artifacts must remain under benchmarks/")
    if args.max_groups < 0:
        raise ValueError("max-groups must be nonnegative")
    from pyteomics import parser

    from xirt import sequences as xs

    cache = ROOT / "benchmarks/.cache/sources"
    primary = cache / "ecoli/ecoli/DSS_CSM_anpxirt.csv"
    local = ROOT / "sample_data/DSS_xisearch_fdr_CSM50percent_minimal.csv"
    plink = cache / "ecoli_plink2/ecoli_plink2/plink_qval050.csv"
    fa = cache / "FA_complex/FA_complex/xifdr_results80p"
    specs = [
        (
            "full_ecoli",
            "Ecoli",
            False,
            True,
            [
                (primary, "Peptide1", "Peptide2", "rp", 1.0),
                (local, "Peptide1", "Peptide2", "rp", 1.0),
            ],
        ),
        (
            "full_plink",
            "Ecoli alternative search engine",
            False,
            True,
            [(plink, "ModSeq1", "ModSeq2", "rp", 60.0)],
        ),
        (
            "full_fa_cross",
            "FA complex",
            False,
            False,
            [(fa / "FDR_CSM_xiFDR2.1.3.csv", "PepSeq1", "PepSeq2", "ElutionStart", 1.0)],
        ),
        (
            "full_fa_linear",
            "FA complex same acquisition, linear analytes",
            True,
            False,
            [(fa / "FDR_Linear_PSM_xiFDR2.1.3.csv", "PepSeq1", None, "ElutionStart", 1.0)],
        ),
        (
            "full_ecoli_linear",
            "Ecoli linear HPO same biological source",
            True,
            True,
            [
                (
                    cache / "paper/FigS2_source_cde_part2.csv",
                    "Seq_Peptide1",
                    None,
                    "ElutionStart",
                    1.0,
                )
            ],
        ),
    ]
    alphabet = set("ACDEFGHIKLMNPQRSTVWY")

    def number(value: str) -> float:
        """Read numeric CSV fields that may contain thousands separators.

        >>> float("1,234".replace(",", ""))
        1234.0
        """
        return float(value.replace(",", ""))

    def bare(sequence: str) -> str:
        """Remove lowercase and numeric PTM annotations without dropping residues.

        >>> "".join(re.findall("[A-Z]", "AKbs3nh2Mox"))
        'AKM'
        """
        return "".join(re.findall("[A-Z]", sequence))

    def group_key(pair: tuple[str, ...]) -> tuple[str, ...]:
        """Unify modification states and crosslink orientations before splitting.

        >>> tuple(sorted(("AK", "MA")))
        ('AK', 'MA')
        """
        return tuple(sorted(map(bare, pair)))

    def tokenize(sequence: str) -> list[str]:
        """Retain PTMs through the package's actual modX normalization.

        >>> callable(main)
        True
        """
        prepared = xs.simplify_alphabet(sequence)
        prepared = xs.remove_brackets_underscores(prepared)
        prepared = xs.replace_numbers(prepared)
        prepared = xs.remove_nterm_mod(prepared)
        prepared = xs.rewrite_modsequences(prepared)
        return parser.parse(prepared, show_unmodified_termini=True)

    def normalized_run(value: str) -> str:
        """Align primary and repository run spellings for CSM deduplication.

        >>> Path("folder/recal_run.mgf").name
        'recal_run.mgf'
        """
        value = Path(value).name
        value = re.sub(r"^recal_", "", value)
        return re.sub(r"\.mgf$", "", value, flags=re.IGNORECASE)

    with args.pilot_manifest.open() as stream:
        pilot = list(csv.DictReader(stream))
    pilot_groups = {group_key((row["peptide_a"], row["peptide_b"])) for row in pilot}
    for name, study, linear, fractions, sources in specs:
        if args.only and name not in args.only:
            continue
        observations, source_details, seen = [], [], set()
        duplicate_csms, invalid = 0, 0
        for path, a_column, b_column, rp_column, factor in sources:
            raw = list(csv.DictReader(path.open()))
            confidence_count = 0
            for index, row in enumerate(raw):
                if row["isTT"].lower() != "true" or number(row["fdr"]) > 0.01:
                    continue
                confidence_count += 1
                a, b = row[a_column], row[b_column] if b_column else ""
                a = a.split(".")[1] if "." in a else a
                b = b.split(".")[1] if "." in b else b
                rp = number(row[rp_column]) * factor
                if not a or (not linear and not b) or not math.isfinite(rp):
                    invalid += 1
                    continue
                run = normalized_run(row.get("Run", row.get("run", "")))
                psmid = str(int(number(row["PSMID"]))) if row["PSMID"] else f"row{index}"
                identity = run, psmid
                if identity in seen:
                    duplicate_csms += 1
                    continue
                seen.add(identity)
                observations.append(
                    {
                        "Peptide1": a,
                        "Peptide2": b,
                        "rp": rp,
                        "hsax": row.get("hsax", ""),
                        "scx": row.get("scx", ""),
                        "isTT": "True",
                        "fdr": number(row["fdr"]),
                        "Run": run,
                        "PSMID": psmid,
                        "source_file": str(path.relative_to(ROOT)),
                        "source_row": index,
                    }
                )
            source_details.append(
                {
                    "path": str(path.relative_to(ROOT)),
                    "sha256": digest(path.read_bytes()),
                    "total_rows": len(raw),
                    "confidence_eligible_rows": confidence_count,
                    "peptide_a_column": a_column,
                    "peptide_b_column": b_column,
                    "rp_column": rp_column,
                    "rp_to_seconds_factor": factor,
                    "original_rp_units": "minutes" if factor == 60.0 else "seconds",
                }
            )
        grouped = {}
        for index, row in enumerate(observations):
            pair = (
                (row["Peptide1"],) if linear else tuple(sorted((row["Peptide1"], row["Peptide2"])))
            )
            grouped.setdefault(pair, []).append((index, row))
        if args.max_groups:
            selected = sorted({group_key(pair) for pair in grouped})
            random.Random(args.split_seed).shuffle(selected)
            selected_groups = set(selected[:args.max_groups])
            grouped = {pair: records for pair, records in grouped.items()
                       if group_key(pair) in selected_groups}
        groups = sorted({group_key(pair) for pair in grouped})
        reserved = set(groups) & pilot_groups if study.startswith("Ecoli") else set()
        remaining = sorted(set(groups) - reserved)
        random.Random(args.split_seed).shuffle(remaining)
        train_count, val_count = int(0.7 * len(groups)), int(0.15 * len(groups))
        if len(groups) < 10 or len(reserved) > train_count:
            raise ValueError("Insufficient fresh groups for nonempty train/validation/test splits")
        assignments = {key: "train" for key in reserved}
        for index, key in enumerate(remaining):
            assignments[key] = (
                "train"
                if index < train_count - len(reserved)
                else "validation"
                if index < train_count - len(reserved) + val_count
                else "test"
            )
        for view in args.views:
            canonical_only = view == "canonical"
            destination = args.output_root / f"{name}_{view}"
            destination.mkdir(parents=True, exist_ok=True)
            pairs = sorted(
                pair for pair in grouped if not canonical_only or set("".join(pair)) <= alphabet
            )
            rows, token_alphabet = [], set()
            for pair in pairs:
                a, b = pair[0], "" if linear else pair[1]
                records = grouped[pair]
                tokens_a, tokens_b = tokenize(a), tokenize(b) if b else []
                token_alphabet.update(tokens_a + tokens_b)
                rows.append(
                    {
                        "peptide_a": a,
                        "peptide_b": b,
                        "rp_seconds": statistics.mean(float(row["rp"]) for _, row in records),
                        "hsax": statistics.mode(int(number(row["hsax"])) for _, row in records)
                        if fractions
                        else "",
                        "scx": statistics.mode(int(number(row["scx"])) for _, row in records)
                        if fractions
                        else "",
                        "source_rows": ";".join(str(index) for index, _ in records),
                        "tokens_a": json.dumps(tokens_a),
                        "tokens_b": json.dumps(tokens_b),
                        "group_key": json.dumps(group_key(pair)),
                    }
                )
            with (destination / "observations.csv").open("w") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(observations[0]))
                writer.writeheader()
                writer.writerows(observations)
            with (destination / "pairs.csv").open("w") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
                writer.writeheader()
                writer.writerows(rows)
            splits = {key: [] for key in ("train", "validation", "test")}
            for index, pair in enumerate(pairs):
                splits[assignments[group_key(pair)]].append(index)
            train_targets = [rows[i]["rp_seconds"] for i in splits["train"]]
            config = configuration()
            config["learning"]["epochs"] = 30
            batch_size = 256 if len(pairs) > 10_000 else 64
            config["learning"]["batch_size"] = batch_size
            manifest = {
                "schema_version": 2,
                "dataset": destination.name,
                "biological_study": study,
                "source": str((destination / "observations.csv").relative_to(ROOT)),
                "source_sha256": digest((destination / "observations.csv").read_bytes()),
                "actual_source_files": source_details,
                "source_rows_total": sum(s["total_rows"] for s in source_details),
                "confidence_eligible_rows_before_dedup": sum(
                    s["confidence_eligible_rows"] for s in source_details
                ),
                "confidence_eligible_rows": len(observations),
                "duplicate_csms_removed": duplicate_csms,
                "invalid_label_rows_removed": invalid,
                "modified_aware_eligible_pairs": len(grouped),
                "pair_count": len(rows),
                "eligible_unique_pairs": len(pairs),
                "pairs_sha256": digest((destination / "pairs.csv").read_bytes()),
                "legacy_commit": LEGACY,
                "training_seeds": SEEDS,
                "selection_seed": None,
                "split_seed": args.split_seed,
                "max_groups": args.max_groups,
                "scope": "smoke_subset" if args.max_groups else "full_cohort",
                "splits": splits,
                "units": "seconds",
                "siamese": not linear,
                "fraction_labels_available": fractions,
                "fraction_levels": {
                    task: sorted({int(row[task]) for row in rows}) for task in ("hsax", "scx")
                }
                if fractions
                else {},
                "encoding": "residue_tokens",
                "alphabet": sorted(token_alphabet),
                "max_length": max(
                    len(json.loads(row[key])) for row in rows for key in ("tokens_a", "tokens_b")
                ),
                "tokenizer": "actual xiRT sequence normalization + pyteomics modX parser with termini",
                "tokenizer_source_sha256": digest((ROOT / "xirt/sequences.py").read_bytes()),
                "padding": "left token0; legacy learned padding, new masked padding",
                "target_normalization": {
                    "mean": statistics.mean(train_targets),
                    "std": statistics.pstdev(train_targets),
                },
                "epochs": 30,
                "batch_size": batch_size,
                "early_stopping_patience": 8,
                "early_stopping_min_delta": 0.0001,
                "config": config,
                "device": "CPU",
                "threads": 2,
                "pair_definition": "unordered modification-aware raw peptide pair, or single linear sequence",
                "split_group": "UNMODIFIED peptide pair/sequence; all modification states grouped together",
                "unmodified_group_count": len(groups),
                "pilot_groups_reserved_for_training": len(reserved),
                "pilot_pair_manifest_sha256": digest(args.pilot_manifest.read_bytes()),
                "test_protection": "all previously inspected pilot Ecoli pair groups reserved train-only",
                "canonical_only": canonical_only,
                "excluded_modified_pairs_for_esm": len(grouped) - len(pairs)
                if canonical_only
                else 0,
                "acquisition_relationship": "Ecoli versions/alternative engine and FA linear/cross are correlated views; TWO biostudies",
                "deduplication": "TT/FDR<=.01 per source, then normalized Run+PSMID; linked primary source first",
                "selection": "fixed Adam/AdamW LR.003; validation-only epoch selection/early stopping",
            }
            write_json(destination / "manifest.json", manifest)
            print(
                destination.name,
                len(rows),
                {key: len(indices) for key, indices in splits.items()},
                "groups",
                len(groups),
                "confidence_rows",
                len(observations),
                flush=True,
            )


if __name__ == "__main__":
    main()
