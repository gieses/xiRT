"""Framework-independent data and metric contracts for isolated benchmark jobs."""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

import numpy as np

from benchmarks.run import configuration
from benchmarks.workflow.protocol import file_hash


class BenchmarkData:
    """Read immutable group splits and train-only normalization for every backend."""

    def __init__(self, directory: Path, config: dict[str, Any]) -> None:
        """Validate the pair fingerprint and construct corresponding token arrays."""
        self.directory = directory
        self.manifest = json.loads((directory / "manifest.json").read_text())
        if file_hash(directory / "pairs.csv") != self.manifest["pairs_sha256"]:
            raise ValueError("Prepared pair table changed after its manifest was written")
        with (directory / "pairs.csv").open() as stream:
            self.rows = list(csv.DictReader(stream))
        self.raw_y = np.asarray([float(row["rp_seconds"]) for row in self.rows], dtype=np.float32)
        normalization = self.manifest["target_normalization"]
        self.y: dict[str, np.ndarray] = {
            "rp": (self.raw_y - normalization["mean"]) / normalization["std"],
        }
        self.levels = self.manifest["fraction_levels"]
        self.excluded_tasks = [
            task for task in config["tasks"] if task != "rp" and task not in self.levels
        ]
        self.tasks = sorted(task for task in config["tasks"] if task != "rp" and task in self.levels)
        self.tasks.append("rp")
        for task in self.tasks:
            if task != "rp":
                mapping = {int(value): index for index, value in enumerate(self.levels[task])}
                self.y[task] = np.asarray([mapping[int(row[task])] for row in self.rows])
        mapping = {token: index + 1 for index, token in enumerate(self.manifest["alphabet"])}
        self.inputs = []
        columns = ["tokens_a", "tokens_b"] if self.manifest["siamese"] else ["tokens_a"]
        for column in columns:
            matrix = np.zeros((len(self.rows), self.manifest["max_length"]), dtype=np.int64)
            for index, row in enumerate(self.rows):
                encoded = [mapping[token] for token in json.loads(row[column])]
                matrix[index, -len(encoded):] = encoded
            self.inputs.append(matrix)

    def parameters(self, config: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
        """Construct actual shared xiRT dimensions and explicitly matched linear heads."""
        params = configuration("adamw", candidate["learning_rate"], "mse")
        architecture = config["architecture"]
        params["embedding"]["length"] = architecture["embedding_dim"]
        params["LSTM"]["units"] = architecture["gru_units"]
        params["dense"]["neurons"] = [architecture["dense_units"]]
        params["dense"]["activation"] = [architecture["dense_activation"]]
        params["dense"]["dropout"] = [candidate["dropout"]]
        params["learning"]["weight_decay"] = candidate["weight_decay"]
        params["learning"]["clip_norm"] = 1.0
        params["learning"]["device"] = "cpu"
        params["siamese"]["use"] = self.manifest["siamese"]
        params["predictions"]["fractions"] = [task for task in self.tasks if task != "rp"]
        for task in params["predictions"]["fractions"]:
            params["output"].update({
                f"{task}-activation": "softmax", f"{task}-dimension": len(self.levels[task]),
                f"{task}-loss": "categorical_crossentropy", f"{task}-metrics": "accuracy",
                f"{task}-column": task, f"{task}-weight": 1,
            })
        return params

    def objective(self, predictions: dict[str, np.ndarray], indices: list[int]) -> float:
        """Use shared unit-weight standardized RP MSE plus categorical cross entropy."""
        loss = 0.0
        for task in self.tasks:
            predicted = predictions[task]
            if not np.isfinite(predicted).all():
                raise FloatingPointError(f"Nonfinite {task} validation predictions")
            truth = self.y[task][indices]
            if task == "rp":
                loss += float(np.mean((predicted.reshape(-1) - truth) ** 2))
            else:
                loss -= float(np.log(np.clip(
                    predicted[np.arange(len(indices)), truth], 1e-7, 1
                )).mean())
        return loss

    def quality(self, predictions: dict[str, np.ndarray], indices: list[int]) -> dict[str, Any]:
        """Report calibrated seconds and supported-class fraction metrics."""
        normalization = self.manifest["target_normalization"]
        prediction = predictions["rp"].reshape(-1) * normalization["std"] + normalization["mean"]
        truth = self.raw_y[indices].astype(np.float64)
        residual = prediction.astype(np.float64) - truth
        denominator = float(((truth - truth.mean()) ** 2).sum())
        result: dict[str, Any] = {
            "mae_seconds": float(np.abs(residual).mean()),
            "rmse_seconds": float(np.sqrt(np.mean(residual ** 2))),
            "r2": float(1 - (residual ** 2).sum() / denominator) if denominator > 0 else None,
        }
        for task in self.tasks:
            if task == "rp":
                continue
            targets = self.y[task][indices]
            labels = predictions[task].argmax(1)
            result[f"{task}_accuracy"] = float(np.mean(labels == targets))
            result[f"{task}_macro_recall"] = float(np.mean([
                np.mean(labels[targets == label] == label) for label in np.unique(targets)
            ]))
        return result

    def write_predictions(
        self, path: Path, predictions: dict[str, np.ndarray], indices: list[int]
    ) -> None:
        """Write row-aligned predictions in seconds, with optional fraction probabilities."""
        norm = self.manifest["target_normalization"]
        fields = ["pair_index", "truth_seconds", "prediction_seconds"]
        for task in self.tasks:
            if task != "rp":
                fields += [f"{task}_truth", f"{task}_probabilities"]
        with path.open("w") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            for offset, index in enumerate(indices):
                row = {
                    "pair_index": index, "truth_seconds": float(self.raw_y[index]),
                    "prediction_seconds": float(
                        predictions["rp"].reshape(-1)[offset] * norm["std"] + norm["mean"]
                    ),
                }
                for task in self.tasks:
                    if task != "rp":
                        row[f"{task}_truth"] = int(self.y[task][index])
                        row[f"{task}_probabilities"] = json.dumps(predictions[task][offset].tolist())
                writer.writerow(row)
