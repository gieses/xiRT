"""Independently verify scheduled artifacts and report per-cohort, per-seed evidence."""

from __future__ import annotations

import collections
import csv
import json
import statistics
from pathlib import Path
from typing import Any

import numpy as np

from benchmarks.workflow.data import BenchmarkData
from benchmarks.workflow.protocol import WARMSTARTED, file_hash, identity, write_json


def _verify_predictions(
    path: Path, data: BenchmarkData, indices: list[int], recorded: dict[str, Any]
) -> float:
    """Recompute metrics from row-aligned CSV values, independently of either framework."""
    with path.open() as stream:
        rows = list(csv.DictReader(stream))
    if [int(row["pair_index"]) for row in rows] != indices:
        raise ValueError(f"Prediction row identities changed: {path}")
    truth = np.array([float(row["truth_seconds"]) for row in rows])
    if not np.allclose(truth, data.raw_y[indices], rtol=1e-7, atol=1e-3):
        raise ValueError(f"Prediction targets changed: {path}")
    norm = data.manifest["target_normalization"]
    predicted = np.array([float(row["prediction_seconds"]) for row in rows])
    predictions = {"rp": (predicted - norm["mean"]) / norm["std"]}
    for task in data.tasks:
        if task != "rp":
            predictions[task] = np.array([json.loads(row[f"{task}_probabilities"]) for row in rows])
            if not np.allclose(predictions[task].sum(1), 1, atol=1e-5):
                raise ValueError(f"Invalid fraction probabilities: {path}")
    measured = data.quality(predictions, indices)
    for key, value in measured.items():
        expected = recorded[key]
        if value is None and expected is None:
            continue
        if value is None or expected is None or not np.isclose(value, expected, rtol=1e-5, atol=1e-5):
            raise ValueError(f"Independent {key} mismatch: {path}")
    return data.objective(predictions, indices)


def report(run_dir: Path, provenance: dict[str, Any]) -> None:
    """Require all requested jobs and verify provenance/splits before publishing a verdict."""
    config = provenance["config"]
    groups: dict[tuple[str, str], list[dict[str, Any]]] = collections.defaultdict(list)
    checked = []
    if file_hash(run_dir / "source.tar.gz") != provenance["source_archive_sha256"]:
        raise ValueError("Source archive changed")
    for dataset in config["datasets"]:
        data = BenchmarkData(run_dir / "data" / dataset, config)
        manifest = data.manifest
        splits = manifest["splits"]
        partition = [index for indices in splits.values() for index in indices]
        if sorted(partition) != list(range(len(data.rows))):
            raise ValueError("Partitions are not a disjoint exhaustive index assignment")
        group_sets = {
            key: {data.rows[index]["group_key"] for index in indices}
            for key, indices in splits.items()
        }
        for first, a in group_sets.items():
            for second, b in group_sets.items():
                if first != second and a & b:
                    raise ValueError("Modification states leak between data partitions")
        inner = manifest["pretraining_splits"]
        if sorted(inner["train"] + inner["validation"]) != sorted(splits["train"]):
            raise ValueError("Pretraining accesses outer validation or test rows")
        training_targets = [float(data.rows[index]["rp_seconds"]) for index in splits["train"]]
        if not np.isclose(np.mean(training_targets), manifest["target_normalization"]["mean"]):
            raise ValueError("Target mean is not train-only")
        if not np.isclose(np.std(training_targets), manifest["target_normalization"]["std"]):
            raise ValueError("Target scale is not train-only")
        for source in manifest["actual_source_files"]:
            from benchmarks.run import ROOT

            if file_hash(ROOT / source["path"]) != source["sha256"]:
                raise ValueError("Raw source fingerprint changed")
        for variant in config["variants"]:
            selection_path = run_dir / "selection" / dataset / f"{variant}.json"
            selection = json.loads(selection_path.read_text())
            if [item["candidate_id"] for item in selection["candidates"]] != [
                item["id"] for item in config["candidates"]
            ]:
                raise ValueError("Selection does not cover all prespecified candidates")
            best = min(selection["candidates"], key=lambda item: (
                item["mean_validation_loss"], item["candidate_id"]
            ))
            if selection["test_used"] or selection["candidate_id"] != best["candidate_id"]:
                raise ValueError("Candidate was not selected by validation-only criterion")
            for candidate in selection["candidates"]:
                if len(candidate["records"]) != len(config["tuning_seeds"]):
                    raise ValueError("Selection does not cover all prespecified tuning seeds")
                losses = []
                for seed, pointer in zip(config["tuning_seeds"], candidate["records"], strict=True):
                    path = run_dir / pointer["path"]
                    expected_path = (
                        run_dir / "tuning" / dataset / variant / candidate["candidate_id"]
                        / f"s{seed}" / "result.json"
                    )
                    record = json.loads(path.read_text())
                    if (
                        path != expected_path or file_hash(path) != pointer["sha256"]
                        or record["test_evaluated"] or record["status"] != "ok"
                        or record["protocol_sha256"] != provenance["protocol_sha256"]
                        or record["source_snapshot_sha256"] != provenance["source_snapshot_sha256"]
                        or record["data_manifest_sha256"] != file_hash(data.directory / "manifest.json")
                    ):
                        raise ValueError("Validation-only selection record was modified")
                    if (path.parent / "test.csv").exists():
                        raise ValueError("A tuning job contains forbidden test predictions")
                    for name, key in (
                        ("checkpoint.bin", "checkpoint_sha256"),
                        ("validation.csv", "validation_predictions_sha256"),
                    ):
                        if file_hash(path.parent / name) != record[key]:
                            raise ValueError("Tuning artifact fingerprint mismatch")
                    loss = _verify_predictions(
                        path.parent / "validation.csv", data, splits["validation"],
                        record["validation_quality"],
                    )
                    if not np.isclose(loss, record["validation_loss"], rtol=1e-5, atol=1e-5):
                        raise ValueError("Independent validation objective mismatch")
                    losses.append(record["validation_loss"])
                if (
                    losses != candidate["validation_losses"]
                    or statistics.mean(losses) != candidate["mean_validation_loss"]
                ):
                    raise ValueError("Candidate mean does not match its validation-only records")
            for seed in config["seeds"]:
                directory = run_dir / "final" / dataset / variant / f"s{seed}"
                record_path = directory / "result.json"
                record = json.loads(record_path.read_text())
                if (
                    record["status"] != "ok" or not record["test_evaluated"]
                    or record["protocol_sha256"] != provenance["protocol_sha256"]
                    or record["source_snapshot_sha256"] != provenance["source_snapshot_sha256"]
                    or record["data_manifest_sha256"] != file_hash(data.directory / "manifest.json")
                    or record["selection_sha256"] != file_hash(selection_path)
                    or record["candidate"]["id"] != selection["candidate_id"]
                ):
                    raise ValueError(f"Final run provenance mismatch: {record_path}")
                for name, key in (
                    ("checkpoint.bin", "checkpoint_sha256"),
                    ("validation.csv", "validation_predictions_sha256"),
                    ("test.csv", "test_predictions_sha256"),
                ):
                    if file_hash(directory / name) != record[key]:
                        raise ValueError(f"Artifact fingerprint mismatch: {directory / name}")
                for split in ("validation", "test"):
                    _verify_predictions(
                        directory / f"{split}.csv", data, splits[split], record[f"{split}_quality"]
                    )
                if variant in WARMSTARTED:
                    checkpoint = run_dir / "pretrain" / dataset / f"s{seed}" / "checkpoint.bin"
                    if file_hash(checkpoint) != record["model"]["warmstart_sha256"]:
                        raise ValueError("Adapter and control did not share the recorded base")
                if variant in {"esm_lora", "esm_lokr", "lokr_gru", "lokr_linear"}:
                    if not (
                        record["initial_adapter_gradient_l2"] > 0
                        and record["diagnostics"]["adapter_update_l2"] > 0
                        and record["diagnostics"]["frozen_parameters_unchanged"]
                    ):
                        raise ValueError("Adapter gradient/update or frozen-base evidence is missing")
                groups[dataset, variant].append(record)
                checked.append({
                    "path": str(record_path.relative_to(run_dir)), "sha256": file_hash(record_path),
                })
    aggregates = []
    lines = [
        "# Scheduled xiRT benchmark", "",
        f"**Scope: {provenance['scope']}**. "
        + ("Smoke measurements prove execution/reconstruction, not predictive superiority."
           if config["max_groups"] else "Complete linked model-ready cohorts; two biological studies."),
        "", "Legacy TensorFlow is an isolated deprecated architecture reference, explicitly using "
        "AdamW. No TensorFlow code or scheduler dependencies are installed with xiRT.", "",
        "| Cohort | Variant | Selected candidate | RT RMSE s | Trainable parameters | "
        "Selected training s | Warm-start s | Live inference ms |",
        "|---|---|---|---:|---:|---:|---:|---:|",
    ]
    for (dataset, variant), records in sorted(groups.items()):
        values = [record["test_quality"]["rmse_seconds"] for record in records]
        mean = statistics.mean(values)
        deviation = statistics.stdev(values) if len(values) > 1 else None
        warm = [
            json.loads((run_dir / "pretrain" / dataset / f"s{record['seed']}" / "result.json").read_text())
            ["training_seconds"] if variant in WARMSTARTED else 0.0
            for record in records
        ]
        item = {
            "dataset": dataset, "variant": variant, "seeds": len(records),
            "candidate_id": records[0]["candidate"]["id"], "rt_rmse_seconds_mean": mean,
            "rt_rmse_seconds_seed_sd": deviation,
            "trainable_parameters": records[0]["model"]["trainable_parameters"],
            "training_seconds_mean": statistics.mean(r["training_seconds"] for r in records),
            "warmstart_seconds_mean": statistics.mean(warm),
            "inference_seconds_mean": statistics.mean(r["inference_seconds"] for r in records),
            "test_quality_per_seed": {str(r["seed"]): r["test_quality"] for r in records},
        }
        aggregates.append(item)
        score = f"{mean:.2f}" + (f" +/- {deviation:.2f}" if deviation is not None else "")
        lines.append(
            f"| {dataset} | {variant} | {item['candidate_id']} | {score} | "
            f"{item['trainable_parameters']} | {item['training_seconds_mean']:.2f} | "
            f"{item['warmstart_seconds_mean']:.2f} | {1000 * item['inference_seconds_mean']:.2f} |"
        )
    lines += [
        "", "## Interpretation", "",
        "Compare GRU/linear LoKr to both matched train-only full fine-tuning and frozen-encoder "
        "head training, not only to scratch training. Scratch recurrent budgets include the "
        "pretraining epoch allowance; warm-start cost is reported separately. ESM variants share "
        "pinned pretrained weights, seeded heads, PTM-blind projection and adaptation budgets. "
        "No full-ESM fine-tuning superiority or total protein-pretraining cost is established.", "",
        "Hyperparameters are selected by mean validation objective only. Test evaluation follows "
        "selection and checkpoint reconstruction; timing repeats never influence selection. "
        "Dropout is head dropout, not GRU recurrent dropout. Cosine warmup, constant LR and plateau "
        "schedules use the same explicit semantics across frameworks. Linear dense activations "
        "match the historical effective architecture.", "",
        "Splits protect unordered sequence identities across modification states, not every "
        "individual peptide across different pairs. Input alphabet/padding width describe the "
        "full structural schema. Targets are scaled using training rows only. These are new "
        "grouped partitions of previously studied data, not prospectively untouched external "
        "validation. Correlated views and seed dispersion are not independent biological replications.", "",
        "The local profile serializes measured jobs; other users may still contend for this "
        "shared host. GPU inference is synchronized and includes live ESM forward calls. "
        "Setup/source hashing and base checkpoint loading are not hidden in head-only timings. "
        "Candidate-search compute is separate from the selected model's training cost.", "",
    ]
    write_json(run_dir / "summary.json", {
        "scope": provenance["scope"], "protocol_sha256": provenance["protocol_sha256"],
        "aggregates": aggregates,
    })
    write_json(run_dir / "verification.json", {
        "status": "ok", "final_runs_verified": len(checked), "records": checked,
        "verification_sha256": identity(checked),
        "checks": ["code/archive/source/checkpoint/prediction hashes", "grouped disjoint partitions",
                   "train-only target scaling and pretraining", "validation-only candidate selection",
                   "independent prediction metrics", "adapter gradients/updates and frozen bases"],
    })
    (run_dir / "report.md").write_text("\n".join(lines))
