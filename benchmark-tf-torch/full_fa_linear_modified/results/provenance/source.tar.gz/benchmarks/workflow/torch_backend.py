"""Modern-only benchmark implementations: native xiRT and genuine ESM adapters."""

from __future__ import annotations

import hashlib
import re
from contextlib import nullcontext
from pathlib import Path
from typing import Any

import numpy as np
import torch
from torch import nn

from benchmarks.workflow.data import BenchmarkData
from benchmarks.workflow.protocol import WARMSTARTED, file_hash, is_esm
from xirt.adapters import LoKrLinear, LoRALinear, apply_lokr, apply_lokr_gru
from xirt.embeddings import ESMCEncoder, ESMCRetentionModel
from xirt.training import seed_everything
from xirt.xirtnet import xiRTNET


def _parameter_digest(parameters: list[tuple[str, torch.Tensor]]) -> str:
    """Fingerprint actual tensor values, using at most one tensor-sized CPU copy."""
    digest = hashlib.sha256()
    for name, parameter in parameters:
        value = parameter.detach().cpu().contiguous()
        digest.update(f"{name}:{value.dtype}:{tuple(value.shape)}".encode())
        digest.update(memoryview(value.reshape(-1).view(torch.uint8).numpy()))
    return digest.hexdigest()


class ESMPairedModel(nn.Module):
    """Shared pooled ESM-C representations with the same dense head across adapters."""

    def __init__(
        self, encoder: ESMCRetentionModel, data: BenchmarkData, config: dict[str, Any],
        candidate: dict[str, Any], seed: int,
    ) -> None:
        """Initialize an identical seeded head after variant-specific adapter injection."""
        super().__init__()
        self.encoder = encoder
        self.tasks, self.paired = data.tasks, data.manifest["siamese"]
        width = encoder.regressor.in_features
        # Adapter initialization consumes a variant-dependent number of RNG draws.
        # Reset before heads so frozen, LoRA and LoKr controls begin identically.
        seed_everything(seed + 101, config["deterministic"])
        units = config["architecture"]["dense_units"]
        self.heads = nn.ModuleDict()
        self.outputs = nn.ModuleDict()
        for task in self.tasks:
            activation = config["architecture"]["dense_activation"]
            if activation not in {"linear", "relu", "gelu"}:
                raise ValueError(f"Unsupported ESM dense activation: {activation}")
            self.heads[task] = nn.Sequential(
                nn.Linear(width, units),
                {"linear": nn.Identity, "relu": nn.ReLU, "gelu": nn.GELU}[activation](),
                nn.Dropout(candidate["dropout"]),
            )
            self.outputs[task] = nn.Linear(units, 1 if task == "rp" else len(data.levels[task]))
        self.encoder.regressor.requires_grad_(False)
        seed_everything(seed, config["deterministic"])

    def forward(
        self, first: torch.Tensor, first_mask: torch.Tensor,
        second: torch.Tensor | None = None, second_mask: torch.Tensor | None = None,
    ) -> dict[str, torch.Tensor]:
        """Pool before Siamese addition so every task receives exactly one head bias."""
        if second is None:
            width = int(first_mask.sum(1).max().item()) + 2
            pooled = self.encoder.encode(first[:, :width], first_mask[:, :width])
        else:
            if second_mask is None:
                raise ValueError("Second peptide requires its residue mask")
            tokens = torch.cat((first, second))
            masks = torch.cat((first_mask, second_mask))
            width = int(masks.sum(1).max().item()) + 2
            encoded = self.encoder.encode(tokens[:, :width], masks[:, :width])
            pooled = encoded[:len(first)] + encoded[len(first):]
        return {task: self.outputs[task](self.heads[task](pooled)) for task in self.tasks}


class TorchBackend:
    """Train native PyTorch or true backbone adapters through a shared worker contract."""

    def __init__(
        self, data: BenchmarkData, config: dict[str, Any], candidate: dict[str, Any],
        seed: int, variant: str, warmstart: Path | None, esm_assets: dict[str, Any] | None = None,
    ) -> None:
        """Build a seeded model, load train-only base weights, and freeze explicit targets."""
        torch.set_num_threads(config["threads_per_job"])
        seed_everything(seed, config["deterministic"])
        self.data, self.config, self.variant = data, config, variant
        self.device = torch.device(config["device"] if is_esm(variant) else "cpu")
        self.use_autocast = is_esm(variant) and config["precision"] == "bfloat16"
        self.initial_adapter_gradient: float | None = None
        targets: tuple[str, ...] = ()
        encoder_fingerprint = None
        if is_esm(variant):
            if self.device.type != "cuda" or not torch.cuda.is_available():
                raise RuntimeError("Real ESM-C benchmark variants require the configured CUDA GPU")
            if self.use_autocast and not torch.cuda.is_bf16_supported():
                raise RuntimeError("Configured GPU does not support the requested bfloat16")
            if esm_assets is None:
                raise ValueError("ESM variants require a pinned asset manifest")
            from esm.models.esmc import ESMC
            from esm.tokenization import get_esmc_model_tokenizers

            from benchmarks.run import ROOT

            checkpoint = ROOT / esm_assets["path"]
            if file_hash(checkpoint) != config["esm"]["checkpoint_sha256"]:
                raise ValueError("Pinned ESM-C weight file was modified")
            base = ESMC(
                d_model=960, n_heads=15, n_layers=30,
                tokenizer=get_esmc_model_tokenizers(), use_flash_attn=False,
            )
            base.load_state_dict(torch.load(checkpoint, map_location="cpu", weights_only=True))
            base.to(
                device=self.device,
                dtype=torch.bfloat16 if self.use_autocast else torch.float32,
            )
            frozen = ESMCEncoder("esmc_300m", device=self.device, model=base)
            encoder_fingerprint = frozen.fingerprint
            kind = {"esm_frozen": "none", "esm_lora": "lora", "esm_lokr": "lokr"}[variant]
            adapter = config["adapter"]
            encoder = ESMCRetentionModel(
                model=frozen.model, device=self.device, adapter_kind=kind,
                rank=adapter["rank"], factor=adapter["factor"], alpha=adapter["alpha"],
            )
            for layer in encoder.backbone.modules():
                if isinstance(layer, (LoKrLinear, LoRALinear)):
                    for name, parameter in list(layer.named_parameters(recurse=False)):
                        layer.register_parameter(name, nn.Parameter(parameter.float()))
            targets = encoder.adapter_targets
            self.model = ESMPairedModel(encoder, data, config, candidate, seed).to(self.device)
            sequences = [
                "".join(re.findall("[A-Z]", row["peptide_a"])).replace("U", "C")
                for row in data.rows
            ]
            if data.manifest["siamese"]:
                sequences += [
                    "".join(re.findall("[A-Z]", row["peptide_b"])).replace("U", "C")
                    for row in data.rows
                ]
            tokens, masks = encoder.tokenize(sequences)
            length = len(data.rows)
            self.inputs = [tokens[:length], masks[:length]]
            if data.manifest["siamese"]:
                self.inputs += [tokens[length:], masks[length:]]
            self.checkpoint_trainable_only = True
        else:
            params = data.parameters(config, candidate)
            network = xiRTNET(params, data.manifest["max_length"], len(data.manifest["alphabet"]) + 1)
            network.build_model(
                siamese=data.manifest["siamese"], alphabet=len(data.manifest["alphabet"]) + 1
            )
            self.model = network.model
            if self.model is None:
                raise RuntimeError("Native xiRT model was not built")
            if variant in WARMSTARTED:
                if warmstart is None:
                    raise ValueError("Adapter/fine-tuning control requires a train-only base checkpoint")
                base = torch.load(warmstart, map_location="cpu", weights_only=True)
                self.model.load_state_dict(base["state_dict"])
            if variant in {"lokr_gru", "lokr_linear", "recurrent_frozen_encoder"}:
                self.model.requires_grad_(False)
                self.model.outputs.requires_grad_(True)
                if variant != "lokr_linear":
                    self.model.heads.requires_grad_(True)
                if variant == "lokr_gru":
                    targets = apply_lokr_gru(self.model, **{
                        key: config["adapter"][key] for key in ("rank", "factor", "alpha")
                    })
                elif variant == "lokr_linear":
                    targets = apply_lokr(self.model.heads, **{
                        key: config["adapter"][key] for key in ("rank", "factor", "alpha")
                    })
            self.inputs = [torch.as_tensor(value, device=self.device) for value in data.inputs]
            self.checkpoint_trainable_only = False
        self.targets = {
            task: torch.as_tensor(values, dtype=torch.float32 if task == "rp" else torch.long,
                                  device=self.device)
            for task, values in data.y.items()
        }
        self.frozen_versions = {
            name: parameter._version for name, parameter in self.model.named_parameters()
            if not parameter.requires_grad
        }
        self.frozen_values = {
            name: parameter.detach().clone() for name, parameter in self.model.named_parameters()
            if not parameter.requires_grad and not is_esm(variant)
        }
        self.adapter_parameters = [
            parameter for name, parameter in self.model.named_parameters()
            if parameter.requires_grad and ("lokr_" in name or "lora_" in name)
        ]
        adapter_ids = {id(parameter) for parameter in self.adapter_parameters}
        ordinary = [
            parameter for parameter in self.model.parameters()
            if parameter.requires_grad and id(parameter) not in adapter_ids
        ]
        groups = [{"params": ordinary, "lr": candidate["learning_rate"]}]
        if self.adapter_parameters:
            groups.append({
                "params": self.adapter_parameters,
                "lr": candidate["learning_rate"] * config["adapter"]["learning_rate_ratio"],
            })
        self.optimizer = torch.optim.AdamW(groups, weight_decay=candidate["weight_decay"])
        self.base_rates = [group["lr"] for group in self.optimizer.param_groups]
        head_parameters = [
            (name, value) for name, value in self.model.named_parameters()
            if name.startswith(("heads.", "outputs."))
        ]
        self.metadata = {
            "framework": "PyTorch", "framework_version": str(torch.__version__),
            "device": str(self.device), "optimizer": "AdamW",
            "precision": config["precision"] if is_esm(variant) else "float32",
            "total_parameters": sum(p.numel() for p in self.model.parameters()),
            "trainable_parameters": sum(p.numel() for p in self.model.parameters() if p.requires_grad),
            "adapter_targets": list(targets),
            "initial_head_sha256": _parameter_digest(head_parameters),
            "warmstart_sha256": file_hash(warmstart) if warmstart else None,
            "pretrained_esm_fingerprint": encoder_fingerprint,
            "pretrained_esm_checkpoint_sha256": config["esm"]["checkpoint_sha256"]
            if is_esm(variant) else None,
            "adapter_parameter_precision": "float32" if self.adapter_parameters else None,
            "checkpoint_format": "Torch state_dict (weights_only=True)",
            "checkpoint_trainable_only": self.checkpoint_trainable_only,
            "ptm_projection": "uppercase residues; U -> C; no PTM or link-site chemistry"
            if is_esm(variant) else "modification-aware residue tokens",
            "initial_learning_rates": self.base_rates,
            "esm_padding": "trim right padding to minibatch longest; retain BOS/EOS"
            if is_esm(variant) else None,
        }

    def _autocast(self) -> Any:
        """Apply one explicit precision policy consistently to forward/backward."""
        return torch.autocast("cuda", dtype=torch.bfloat16) if self.use_autocast else nullcontext()

    def set_learning_rate(self, ratio: float) -> None:
        """Preserve adapter/head LR ratios under the shared epoch scheduler."""
        for group, base in zip(self.optimizer.param_groups, self.base_rates, strict=True):
            group["lr"] = base * ratio

    def train_batch(self, indices: np.ndarray) -> float:
        """Backpropagate actual task losses, including genuine recurrent/backbone adapters."""
        self.model.train()
        self.optimizer.zero_grad(set_to_none=True)
        selected = torch.as_tensor(indices, device=self.device)
        with self._autocast():
            outputs = self.model(*(array[selected] for array in self.inputs))
            losses = [
                nn.functional.mse_loss(outputs[task].float().reshape(-1), self.targets[task][selected])
                if task == "rp" else nn.functional.cross_entropy(
                    outputs[task].float(), self.targets[task][selected]
                )
                for task in self.data.tasks
            ]
            loss = torch.stack(losses).sum()
        if not torch.isfinite(loss):
            raise FloatingPointError("Nonfinite training loss")
        loss.backward()
        if self.adapter_parameters and self.initial_adapter_gradient is None:
            gradient = sum(
                float(parameter.grad.float().square().sum().item())
                for parameter in self.adapter_parameters if parameter.grad is not None
            ) ** 0.5
            if not gradient > 0 or not np.isfinite(gradient):
                raise FloatingPointError("Adapter did not receive a finite nonzero training gradient")
            self.initial_adapter_gradient = gradient
        nn.utils.clip_grad_norm_(
            [parameter for parameter in self.model.parameters() if parameter.requires_grad],
            1.0, error_if_nonfinite=True,
        )
        self.optimizer.step()
        self._check_frozen()
        return float(loss.detach().item())

    def predict(self, indices: list[int], batch_size: int) -> dict[str, np.ndarray]:
        """Evaluate live encoders/backbones without fitting on the requested split."""
        self.model.eval()
        chunks: dict[str, list[np.ndarray]] = {task: [] for task in self.data.tasks}
        with torch.inference_mode():
            for start in range(0, len(indices), batch_size):
                selected = torch.as_tensor(indices[start:start + batch_size], device=self.device)
                with self._autocast():
                    outputs = self.model(*(array[selected] for array in self.inputs))
                for task, value in outputs.items():
                    value = value.float() if task == "rp" else value.float().softmax(1)
                    chunks[task].append(value.cpu().numpy())
        return {task: np.concatenate(values) for task, values in chunks.items()}

    def _check_frozen(self) -> None:
        """Detect any in-place update of the nominally frozen large backbone."""
        if not is_esm(self.variant):
            return
        for name, parameter in self.model.named_parameters():
            if name in self.frozen_versions and parameter._version != self.frozen_versions[name]:
                raise RuntimeError(f"Frozen ESM parameter was modified: {name}")

    def state(self) -> dict[str, torch.Tensor]:
        """Copy small trainable-only ESM states, never the full 333M backbone."""
        trainable = {name for name, value in self.model.named_parameters() if value.requires_grad}
        return {
            name: value.detach().cpu().clone() for name, value in self.model.state_dict().items()
            if not self.checkpoint_trainable_only or name in trainable
        }

    def restore(self, state: dict[str, torch.Tensor]) -> None:
        """Require exact trainable keys before loading a partial ESM checkpoint."""
        if self.checkpoint_trainable_only:
            expected = {name for name, value in self.model.named_parameters() if value.requires_grad}
            if set(state) != expected:
                raise ValueError("ESM checkpoint does not contain exactly the expected trainable tensors")
            result = self.model.load_state_dict(state, strict=False)
            if result.unexpected_keys or any(name in expected for name in result.missing_keys):
                raise ValueError("ESM checkpoint reconstruction failed")
        else:
            self.model.load_state_dict(state)
        self._check_frozen()

    def save(self, path: Path) -> None:
        """Persist constructor provenance and safe tensor states for reconstruction."""
        torch.save({"state_dict": self.state(), "metadata": self.metadata}, path)

    def load(self, path: Path) -> None:
        """Read only tensor/primitive checkpoint contents and require base identity."""
        checkpoint = torch.load(path, map_location="cpu", weights_only=True)
        saved = checkpoint["metadata"]
        for key in ("pretrained_esm_fingerprint", "warmstart_sha256", "initial_head_sha256"):
            if saved.get(key) != self.metadata.get(key):
                raise ValueError(f"Checkpoint base/initialization differs: {key}")
        self.restore(checkpoint["state_dict"])

    def diagnostics(self) -> dict[str, Any]:
        """Verify frozen recurrent values and quantify actual nonzero adapter updates."""
        self._check_frozen()
        for name, parameter in self.model.named_parameters():
            if name in self.frozen_values and not torch.equal(parameter, self.frozen_values[name]):
                raise RuntimeError(f"Frozen recurrent parameter was modified: {name}")
        update = sum(
            float(parameter.detach().float().square().sum().item())
            for name, parameter in self.model.named_parameters()
            if "lora_b" in name or "lokr_w2_b" in name
        ) ** 0.5 if self.adapter_parameters else None
        return {"frozen_parameters_unchanged": True, "adapter_update_l2": update}

    def synchronize(self) -> None:
        """Include completed GPU kernels in timing rather than asynchronous dispatch."""
        if self.device.type == "cuda":
            torch.cuda.synchronize(self.device)
