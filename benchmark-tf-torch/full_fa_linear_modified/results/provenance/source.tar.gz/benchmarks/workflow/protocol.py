"""Shared, dependency-light contracts for the scheduled xiRT comparison.

Example:
    >>> is_esm("esm_lora")
    True
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any

VARIANTS = (
    "legacy_tf", "pytorch", "esm_frozen", "esm_lora", "esm_lokr",
    "lokr_gru", "lokr_linear", "recurrent_full_finetune", "recurrent_frozen_encoder",
)
WARMSTARTED = frozenset({
    "lokr_gru", "lokr_linear", "recurrent_full_finetune", "recurrent_frozen_encoder",
})
DATA_SOURCES = {
    "full_ecoli_modified": [
        "benchmarks/.cache/sources/ecoli/ecoli/DSS_CSM_anpxirt.csv",
        "sample_data/DSS_xisearch_fdr_CSM50percent_minimal.csv",
    ],
    "full_plink_modified": [
        "benchmarks/.cache/sources/ecoli_plink2/ecoli_plink2/plink_qval050.csv",
    ],
    "full_fa_cross_modified": [
        "benchmarks/.cache/sources/FA_complex/FA_complex/xifdr_results80p/FDR_CSM_xiFDR2.1.3.csv",
    ],
    "full_fa_linear_modified": [
        "benchmarks/.cache/sources/FA_complex/FA_complex/xifdr_results80p/"
        "FDR_Linear_PSM_xiFDR2.1.3.csv",
    ],
    "full_ecoli_linear_modified": [
        "benchmarks/.cache/sources/paper/FigS2_source_cde_part2.csv",
    ],
}


def is_esm(variant: str) -> bool:
    """Identify live ESM-C variants for GPU scheduling."""
    return variant.startswith("esm_")


def identity(value: Any) -> str:
    """Hash a canonical strict-JSON value for protocol identity."""
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()


def file_hash(path: Path) -> str:
    """Hash large datasets/checkpoints without loading entire files into RAM."""
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write_json(path: Path, value: Any) -> None:
    """Atomically publish strict JSON, never a partially written success marker."""
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = path.with_suffix(path.suffix + ".pending")
    try:
        pending.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
        pending.replace(path)
    finally:
        pending.unlink(missing_ok=True)


def validate_config(config: dict[str, Any], root: Path) -> dict[str, Any]:
    """Reject unsafe paths, unknown experimental labels and invalid budgets."""
    required = {
        "schema_version", "run_dir", "modern_python", "legacy_python", "datasets",
        "variants", "seeds", "tuning_seeds", "split_seed", "max_groups", "tasks", "epochs",
        "pretrain_epochs", "patience", "min_delta", "batch_size", "esm_batch_size",
        "threads_per_job", "job_timeout_seconds", "device", "precision", "deterministic",
        "allow_downloads", "esm", "architecture", "pretraining", "adapter", "candidates", "scheduler",
    }
    if set(config) != required:
        raise ValueError(
            f"Configuration keys differ: missing={required - set(config)}, "
            f"unknown={set(config) - required}"
        )
    if config["schema_version"] != 1:
        raise ValueError("Unsupported scheduled-benchmark schema")
    destination = (root / config["run_dir"]).resolve()
    if destination == root / "benchmarks/results" or not destination.is_relative_to(
        root / "benchmarks/results"
    ):
        raise ValueError("Use a distinct run directory under benchmarks/results/")
    for key, allowed in (("variants", set(VARIANTS)), ("datasets", set(DATA_SOURCES))):
        values = config[key]
        if not values or len(values) != len(set(values)) or not set(values) <= allowed:
            raise ValueError(f"Invalid or duplicate {key}: {values}")
    for key in ("seeds", "tuning_seeds"):
        values = config[key]
        if (
            not values or len(values) != len(set(values))
            or any(isinstance(v, bool) or not isinstance(v, int) or v < 0 for v in values)
        ):
            raise ValueError(f"Invalid {key}")
    if not set(config["seeds"]) <= set(config["tuning_seeds"]):
        raise ValueError("Every final seed must be trained in validation-only tuning")
    if "rp" not in config["tasks"] or not set(config["tasks"]) <= {"rp", "hsax", "scx"}:
        raise ValueError("Tasks must include rp and may also include hsax/scx")
    if len(config["tasks"]) != len(set(config["tasks"])):
        raise ValueError("Duplicate tasks")
    for key in (
        "epochs", "pretrain_epochs", "patience", "batch_size", "esm_batch_size",
        "threads_per_job", "job_timeout_seconds",
    ):
        if isinstance(config[key], bool) or not isinstance(config[key], int) or config[key] < 1:
            raise ValueError(f"{key} must be a positive integer")
    if config["max_groups"] < 0:
        raise ValueError("max_groups must be nonnegative")
    if config["pretraining"]["strategy"] != "within_cohort_train_only":
        raise ValueError("Only explicitly train-only within-cohort pretraining is implemented")
    if not 0 < config["pretraining"]["validation_fraction"] < 0.5:
        raise ValueError("Pretraining validation_fraction must be in (0, 0.5)")
    if config["precision"] not in {"float32", "bfloat16"}:
        raise ValueError("precision must be float32 or bfloat16")
    if config["esm"]["model"] != "esmc_300m":
        raise ValueError("This protocol pins the ESM-C 300M architecture")
    if config["architecture"]["dense_activation"] != "linear" and "legacy_tf" in config["variants"]:
        raise ValueError("Legacy dense activations were ignored: use linear for a matched comparison")
    for key in ("embedding_dim", "gru_units", "dense_units"):
        if config["architecture"][key] < 1:
            raise ValueError(f"architecture.{key} must be positive")
    candidates = config["candidates"]
    names: set[str] = set()
    for candidate in candidates:
        if set(candidate) != {"id", "learning_rate", "dropout", "weight_decay", "scheduler"}:
            raise ValueError("Candidate must specify id, learning_rate, dropout, weight_decay, scheduler")
        name = candidate["id"]
        if not re.fullmatch("[a-z][a-z0-9_]*", name) or name in names:
            raise ValueError("Candidate IDs must be unique safe filenames")
        names.add(name)
        if (
            not math.isfinite(candidate["learning_rate"]) or candidate["learning_rate"] <= 0
            or not 0 <= candidate["dropout"] < 1
            or not math.isfinite(candidate["weight_decay"]) or candidate["weight_decay"] < 0
        ):
            raise ValueError(f"Invalid numerical candidate settings: {name}")
        if candidate["scheduler"] not in {"constant", "cosine", "plateau"}:
            raise ValueError(f"Unknown scheduler: {candidate['scheduler']}")
    if not candidates:
        raise ValueError("At least one prespecified candidate is required")
    scheduler = config["scheduler"]
    if (
        not 0 <= scheduler["warmup_fraction"] < 1
        or not 0 < scheduler["minimum_lr_ratio"] <= 1
        or not 0 < scheduler["plateau_factor"] < 1
        or scheduler["plateau_patience"] < 1
        or scheduler["plateau_min_delta"] < 0
    ):
        raise ValueError("Invalid learning-rate scheduler settings")
    adapter = config["adapter"]
    if (
        adapter["rank"] < 1 or adapter["factor"] < 1 or adapter["alpha"] <= 0
        or not 0 < adapter["learning_rate_ratio"] <= 1
    ):
        raise ValueError("Invalid adapter settings")
    return config


def candidate_by_id(config: dict[str, Any], name: str) -> dict[str, Any]:
    """Look up an exact prespecified candidate, without silent defaults."""
    return next(candidate for candidate in config["candidates"] if candidate["id"] == name)


def epoch_budget(config: dict[str, Any], variant: str, stage: str) -> int:
    """Match recurrent scratch budgets to pretraining plus subsequent adaptation."""
    if stage == "pretrain":
        return int(config["pretrain_epochs"])
    budget = int(config["epochs"])
    if variant in {"legacy_tf", "pytorch"}:
        budget += int(config["pretrain_epochs"])
    return budget


class LearningRateSchedule:
    """Shared epoch-level warmup/cosine/plateau semantics for both frameworks.

    >>> schedule = LearningRateSchedule("constant", 4, {"minimum_lr_ratio": .01,
    ...     "warmup_fraction": 0, "plateau_factor": .5, "plateau_patience": 2,
    ...     "plateau_min_delta": .001})
    >>> schedule.ratio(0)
    1.0
    """

    def __init__(self, kind: str, epochs: int, settings: dict[str, Any]) -> None:
        """Initialize a schedule whose plateau state observes validation only."""
        self.kind, self.epochs, self.settings = kind, epochs, settings
        self.warmup = max(1, round(epochs * settings["warmup_fraction"])) if (
            kind == "cosine" and settings["warmup_fraction"] > 0
        ) else 0
        self.multiplier, self.best, self.stale = 1.0, math.inf, 0

    def ratio(self, epoch: int) -> float:
        """Return the multiplier applied before the supplied zero-based epoch."""
        if self.kind == "plateau":
            return self.multiplier
        if self.kind == "constant":
            return 1.0
        if epoch < self.warmup:
            return (epoch + 1) / self.warmup
        progress = (epoch - self.warmup) / max(1, self.epochs - self.warmup - 1)
        floor = self.settings["minimum_lr_ratio"]
        return floor + (1 - floor) * (1 + math.cos(math.pi * progress)) / 2

    def observe(self, validation_loss: float) -> None:
        """Update only a plateau schedule, enforcing the prespecified LR floor."""
        if self.kind != "plateau":
            return
        if validation_loss < self.best - self.settings["plateau_min_delta"]:
            self.best, self.stale = validation_loss, 0
        else:
            self.stale += 1
        if self.stale >= self.settings["plateau_patience"]:
            self.multiplier = max(
                self.settings["minimum_lr_ratio"],
                self.multiplier * self.settings["plateau_factor"],
            )
            self.stale = 0
