"""One isolated training or final-evaluation job; tuning never evaluates test data."""

from __future__ import annotations

import json
import math
import resource
import statistics
import time
from pathlib import Path
from typing import Any

import numpy as np

from benchmarks.workflow.data import BenchmarkData
from benchmarks.workflow.protocol import (
    WARMSTARTED,
    LearningRateSchedule,
    candidate_by_id,
    epoch_budget,
    file_hash,
    identity,
    is_esm,
    write_json,
)


def run_job(
    root: Path, run_dir: Path, provenance: dict[str, Any], dataset: str,
    variant: str, stage: str, seed: int, candidate_id: str | None,
) -> None:
    """Select on validation only, then reconstruct a selected checkpoint for one test evaluation."""
    config = provenance["config"]
    data = BenchmarkData(run_dir / "data" / dataset, config)
    selection = None
    if stage == "pretrain":
        variant = "pytorch"
        candidate = {
            "id": "pretraining", "scheduler": "constant", **{
                key: config["pretraining"][key]
                for key in ("learning_rate", "dropout", "weight_decay")
            },
        }
        destination = run_dir / "pretrain" / dataset / f"s{seed}"
    elif stage == "tune":
        if candidate_id is None:
            raise ValueError("Tuning requires a prespecified candidate ID")
        candidate = candidate_by_id(config, candidate_id)
        destination = run_dir / "tuning" / dataset / variant / candidate_id / f"s{seed}"
    elif stage == "final":
        selection_path = run_dir / "selection" / dataset / f"{variant}.json"
        selection = json.loads(selection_path.read_text())
        candidate = candidate_by_id(config, selection["candidate_id"])
        destination = run_dir / "final" / dataset / variant / f"s{seed}"
    else:
        raise ValueError(f"Unknown worker stage: {stage}")
    destination.mkdir(parents=True, exist_ok=True)
    warmstart = (
        run_dir / "pretrain" / dataset / f"s{seed}" / "checkpoint.bin"
        if variant in WARMSTARTED else None
    )
    started = time.perf_counter()
    deadline = started + config["job_timeout_seconds"]

    def guard() -> None:
        if time.perf_counter() > deadline:
            raise TimeoutError(f"Job exceeded {config['job_timeout_seconds']} seconds")

    if variant == "legacy_tf":
        from benchmarks.reference.legacy_tf import LegacyTensorFlowBackend

        backend: Any = LegacyTensorFlowBackend(
            data, config, candidate, seed, provenance["legacy_source_sha256"]
        )
    else:
        from benchmarks.workflow.torch_backend import TorchBackend

        assets = json.loads((run_dir / "esm-assets.json").read_text()) if is_esm(variant) else None
        backend = TorchBackend(data, config, candidate, seed, variant, warmstart, assets)
    backend.synchronize()
    setup_seconds = time.perf_counter() - started
    train = data.manifest["pretraining_splits"]["train"] if stage == "pretrain" else (
        data.manifest["splits"]["train"]
    )
    validation = data.manifest["pretraining_splits"]["validation"] if stage == "pretrain" else (
        data.manifest["splits"]["validation"]
    )
    batch_size = config["esm_batch_size"] if is_esm(variant) else config["batch_size"]
    history, best_state, best_epoch = [], None, 0
    best, stopping_best, stale = math.inf, math.inf, 0
    training_seconds = 0.0
    if stage == "final":
        source = run_dir / "tuning" / dataset / variant / candidate["id"] / f"s{seed}"
        selected = json.loads((source / "result.json").read_text())
        if file_hash(source / "checkpoint.bin") != selected["checkpoint_sha256"]:
            raise ValueError("Selected checkpoint differs from the completed tuning record")
        backend.load(source / "checkpoint.bin")
        history, best_epoch = selected["history"], selected["best_epoch"]
        training_seconds = selected["training_seconds"]
    else:
        budget = epoch_budget(config, variant, stage)
        scheduler = LearningRateSchedule(candidate["scheduler"], budget, config["scheduler"])
        generator = np.random.default_rng(seed)
        backend.synchronize()
        training_start = time.perf_counter()
        for epoch in range(budget):
            guard()
            ratio = scheduler.ratio(epoch)
            backend.set_learning_rate(ratio)
            order = generator.permutation(train)
            losses, sizes = [], []
            for start in range(0, len(order), batch_size):
                guard()
                indices = order[start:start + batch_size]
                losses.append(backend.train_batch(indices))
                sizes.append(len(indices))
            predictions = backend.predict(validation, batch_size)
            score = data.objective(predictions, validation)
            if not math.isfinite(score) or not np.isfinite(losses).all():
                raise FloatingPointError("Nonfinite training/validation objective")
            history.append({
                "epoch": epoch + 1, "train_loss": float(np.average(losses, weights=sizes)),
                "validation_loss": score, "learning_rate_ratio": ratio,
            })
            if score < best:
                best, best_epoch, best_state = score, epoch + 1, backend.state()
            if score < stopping_best - config["min_delta"]:
                stopping_best, stale = score, 0
            else:
                stale += 1
            scheduler.observe(score)
            if stale >= config["patience"]:
                break
        backend.synchronize()
        training_seconds = time.perf_counter() - training_start
        if best_state is None:
            raise RuntimeError("No finite validation-selected checkpoint was produced")
        backend.restore(best_state)
    guard()
    predictions = backend.predict(validation, batch_size)
    validation_loss = data.objective(predictions, validation)
    data.write_predictions(destination / "validation.csv", predictions, validation)
    diagnostics = backend.diagnostics()
    checkpoint = destination / "checkpoint.bin"
    backend.save(checkpoint)
    # Reload independently constructed checkpoints in final jobs; this write then
    # load also catches unsupported formats before publishing a success marker.
    backend.load(checkpoint)
    result = {
        "status": "ok", "scope": data.manifest["scope"], "stage": stage,
        "dataset": dataset, "variant": variant, "candidate": candidate, "seed": seed,
        "protocol_sha256": provenance["protocol_sha256"],
        "source_snapshot_sha256": provenance["source_snapshot_sha256"],
        "data_manifest_sha256": file_hash(data.directory / "manifest.json"),
        "pairs_sha256": data.manifest["pairs_sha256"],
        "tasks": data.tasks, "excluded_unavailable_tasks": data.excluded_tasks,
        "best_epoch": best_epoch, "history": history,
        "epochs_budget": epoch_budget(config, variant, stage),
        "setup_seconds": setup_seconds, "training_seconds": training_seconds,
        "checkpoint_sha256": file_hash(checkpoint), "checkpoint_bytes": checkpoint.stat().st_size,
        "validation_predictions_sha256": file_hash(destination / "validation.csv"),
        "validation_loss": validation_loss,
        "validation_quality": data.quality(predictions, validation),
        "initial_adapter_gradient_l2": selected["initial_adapter_gradient_l2"]
        if stage == "final" else backend.initial_adapter_gradient,
        "model": backend.metadata, "diagnostics": diagnostics,
        "peak_cpu_rss_mib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024,
        "test_evaluated": False,
    }
    if stage == "final":
        test = data.manifest["splits"]["test"]
        backend.predict(test, batch_size)
        times = []
        for _ in range(3):
            guard()
            backend.synchronize()
            begin = time.perf_counter()
            test_predictions = backend.predict(test, batch_size)
            backend.synchronize()
            times.append(time.perf_counter() - begin)
        data.write_predictions(destination / "test.csv", test_predictions, test)
        result.update(
            test_evaluated=True, test_quality=data.quality(test_predictions, test),
            inference_seconds=statistics.median(times),
            selection_sha256=file_hash(selection_path),
            selected_training_record_sha256=file_hash(source / "result.json"),
            test_predictions_sha256=file_hash(destination / "test.csv"),
        )
        if not np.isclose(validation_loss, selected["validation_loss"], rtol=1e-5, atol=1e-5):
            raise ValueError("Reconstructed checkpoint changed validation predictions")
    elif (destination / "test.csv").exists():
        raise ValueError("Validation-only job directory contains forbidden test predictions")
    result["job_seconds"] = time.perf_counter() - started
    result["record_identity"] = identity({
        key: result[key] for key in ("dataset", "variant", "stage", "seed", "candidate",
                                     "protocol_sha256", "pairs_sha256")
    })
    write_json(destination / "result.json", result)
