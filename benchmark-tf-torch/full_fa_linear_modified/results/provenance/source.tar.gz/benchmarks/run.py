"""Reproducible subprocess-isolated benchmarks. Run --help for commands."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import random
import shutil
import statistics
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

ROOT = Path(
    os.environ.get("XIRT_BENCHMARK_REPO_ROOT", Path(__file__).resolve().parents[1])
).resolve()
OUT = Path(os.environ.get("XIRT_BENCHMARK_RESULTS_DIR", ROOT / "benchmarks/results")).resolve()
if not OUT.is_relative_to(ROOT / "benchmarks"):
    raise ValueError("Benchmark artifacts must remain under benchmarks/")
LEGACY = "52f49bfa79d4b451b2003a8cb19748bc0384c1a6"
SEEDS = [17, 29, 43]


def digest(data: bytes) -> str:
    """Return the content identity used in provenance manifests.

    >>> len(digest(b"xiRT"))
    64
    """
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, data: Any) -> None:
    """Serialize a durable strict-JSON artifact.

    >>> callable(write_json)
    True
    """
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + "\n")


def snapshot_package(output: Path = OUT) -> tuple[Path, str]:
    """Freeze concurrently edited new sources without changing the working package.

    >>> callable(snapshot_package)
    True
    """
    for _ in range(3):
        hashes = {
            str(path.relative_to(ROOT / "xirt")): digest(path.read_bytes())
            for path in sorted((ROOT / "xirt").rglob("*.py"))
            if "__pycache__" not in path.parts
        }
        identity = digest(json.dumps(hashes, sort_keys=True).encode())
        destination = ROOT / "benchmarks/.cache" / f"new-package-{identity}"
        if not destination.exists():
            shutil.copytree(
                ROOT / "xirt", destination / "xirt", ignore=shutil.ignore_patterns("__pycache__")
            )
        copied = {name: digest((destination / "xirt" / name).read_bytes()) for name in hashes}
        if copied == hashes:
            write_json(
                output / "new-source-index.json",
                {
                    "snapshot_sha256": identity,
                    "files": hashes,
                    "snapshot_path": str(destination.relative_to(ROOT)),
                    "base_git_commit": subprocess.check_output(
                        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
                    ).strip(),
                    "description": "Actual uncommitted new package snapshot; not a recreated network",
                },
            )
            return destination, identity
        shutil.rmtree(destination)
    raise RuntimeError("Package changed during three snapshot attempts")


def configuration(optimizer: str = "adam", lr: float = 0.003, loss: str = "mse") -> dict[str, Any]:
    """Construct the prespecified compact network configuration.

    >>> configuration()["LSTM"]["units"]
    16
    """
    categorical = loss in ("categorical_crossentropy", "categorical_focal")
    binary = loss in ("binary_crossentropy", "binary_focal")
    task = "hsax" if categorical or binary else "rp"
    return {
        "LSTM": {
            "activation": "tanh",
            "activity_regularization": "l2",
            "activityregularizer_value": 0.0,
            "bidirectional": False,
            "kernel_regularization": "l2",
            "kernelregularizer_value": 0.0,
            "lstm_bn": False,
            "nlayers": 1,
            "type": "GRU",
            "units": 16,
        },
        "dense": {
            "activation": ["linear"],
            "dense_bn": [False],
            "dropout": [0.0],
            "kernel_regularizer": ["l2"],
            "regularizer_value": [0.0],
            "regularization": [False],
            "neurons": [16],
            "nlayers": 1,
        },
        "embedding": {"length": 8},
        "learning": {
            "batch_size": 64,
            "epochs": 12,
            "learningrate": lr,
            "optimizer": optimizer,
            "weight_decay": 0.1 if optimizer == "lion" else 0.0 if optimizer == "adam" else 0.01,
            "clip_norm": 1.0e9,
            "verbose": 0,
            "device": "cpu",
        },
        "output": {
            f"{task}-activation": "softmax" if categorical else "sigmoid" if binary else "linear",
            f"{task}-dimension": 10 if categorical else 1,
            f"{task}-loss": loss,
            f"{task}-metrics": "accuracy" if categorical else "mse",
            f"{task}-column": task,
            f"{task}-weight": 1,
        },
        "siamese": {"use": True, "merge_type": "add", "single_predictions": False},
        "callbacks": {},
        "predictions": {
            "fractions": [task] if categorical or binary else [],
            "continues": [] if categorical or binary else [task],
        },
    }


def prepare(args: argparse.Namespace) -> None:
    """Prepare the immutable pilot fixture from confidently identified real pairs.

    >>> callable(prepare)
    True
    """
    OUT.mkdir(parents=True, exist_ok=True)
    source = ROOT / "sample_data/DSS_xisearch_fdr_CSM50percent_minimal.csv"
    raw = source.read_bytes()
    if (OUT / "manifest.json").exists() and any(OUT.glob("*-s[0-9]*.json")):
        previous = json.loads((OUT / "manifest.json").read_text())
        if (previous["pair_count"], previous["epochs"], previous["source_sha256"]) != (
            args.rows,
            args.epochs,
            digest(raw),
        ):
            raise ValueError(
                "Existing measured jobs use another manifest; archive results before preparing a new fixture"
            )
    groups = {}
    excluded = 0
    alphabet = "ACDEFGHIKLMNPQRSTVWY"
    for index, row in enumerate(csv.DictReader(raw.decode().splitlines())):
        a, b = row["Peptide1"], row["Peptide2"]
        if (
            row["isTT"] != "True"
            or float(row["fdr"]) > 0.01
            or any(c not in alphabet for c in a + b)
        ):
            excluded += 1
            continue
        key = tuple(sorted((a, b)))
        groups.setdefault(key, []).append((index, float(row["rp"]), int(row["hsax"])))
    keys = sorted(groups)
    random.Random(20261012).shuffle(keys)
    keys = keys[: args.rows]
    # Split groups before aggregating targets: all measurements of a pair stay together.
    rows = []
    for a, b in keys:
        records = groups[a, b]
        rows.append(
            {
                "peptide_a": a,
                "peptide_b": b,
                "rp_seconds": statistics.mean(r[1] for r in records),
                "hsax": statistics.mode(r[2] for r in records),
                "source_rows": ";".join(str(r[0]) for r in records),
            }
        )
    with (OUT / "pairs.csv").open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    indices = list(range(len(rows)))
    random.Random(101).shuffle(indices)
    ntrain, nval = int(0.7 * len(rows)), int(0.15 * len(rows))
    splits = {
        "train": indices[:ntrain],
        "validation": indices[ntrain : ntrain + nval],
        "test": indices[ntrain + nval :],
    }
    train_targets = [rows[i]["rp_seconds"] for i in splits["train"]]
    manifest = {
        "schema_version": 1,
        "legacy_commit": LEGACY,
        "source": str(source.relative_to(ROOT)),
        "source_sha256": digest(raw),
        "pairs_sha256": digest((OUT / "pairs.csv").read_bytes()),
        "pair_count": len(rows),
        "eligible_unique_pairs": len(groups),
        "excluded_source_rows": excluded,
        "selection_seed": 20261012,
        "split_seed": 101,
        "training_seeds": SEEDS,
        "splits": splits,
        "units": "seconds",
        "target_normalization": {
            "mean": statistics.mean(train_targets),
            "std": statistics.pstdev(train_targets),
        },
        "alphabet": alphabet,
        "padding": "left, token=0; legacy learns padding; new masks it",
        "max_length": max(len(r[k]) for r in rows for k in ("peptide_a", "peptide_b")),
        "pair_definition": "unordered unmodified sequence pair; FDR<=0.01, TT; group RP mean, hSAX mode",
        "device": "CPU",
        "threads": 2,
        "epochs": args.epochs,
        "batch_size": 64,
        "config": configuration(),
        "selection": "minimum validation loss epoch; no test selection",
    }
    write_json(OUT / "manifest.json", manifest)
    print(f"Prepared {len(rows)} unique pairs; split {ntrain}/{nval}/{len(rows) - ntrain - nval}")


def load_data() -> tuple[dict[str, Any], list[dict[str, str]], tuple[Any, ...]]:
    """Load hashed pair labels and their actual recurrent encodings.

    >>> callable(load_data)
    True
    """
    import numpy as np

    manifest = json.loads((OUT / "manifest.json").read_text())
    assert digest((OUT / "pairs.csv").read_bytes()) == manifest["pairs_sha256"]
    rows = list(csv.DictReader((OUT / "pairs.csv").open()))
    mapping = {c: i + 1 for i, c in enumerate(manifest["alphabet"])}
    arrays = []
    columns = [("peptide_a", "tokens_a")]
    if manifest.get("siamese", True):
        columns.append(("peptide_b", "tokens_b"))
    for column, token_column in columns:
        array = np.zeros((len(rows), manifest["max_length"]), dtype=np.int64)
        for i, row in enumerate(rows):
            sequence = (
                json.loads(row[token_column])
                if manifest.get("encoding") == "residue_tokens"
                else row[column]
            )
            tokens = [mapping[c] for c in sequence]
            array[i, -len(tokens) :] = tokens
        arrays.append(array)
    return manifest, rows, tuple(arrays)


def metrics(y: Any, prediction: Any) -> dict[str, float]:
    """Compute held-out regression scores in the units of the supplied targets.

    >>> metrics([1., 2., 3.], [1., 2., 3.])["rmse"]
    0.0
    """
    import numpy as np

    y, prediction = np.asarray(y).ravel(), np.asarray(prediction).ravel()
    residual = prediction - y
    denom = ((y - y.mean()) ** 2).sum()
    return {
        "mae": float(np.abs(residual).mean()),
        "rmse": float(np.sqrt((residual**2).mean())),
        "r2": float(1 - (residual**2).sum() / denom),
        "pearson": float(np.corrcoef(y, prediction)[0, 1]) if prediction.std() > 0 else 0.0,
    }


def worker(args: argparse.Namespace) -> None:
    """Train one actual implementation, selecting its epoch on validation only.

    >>> callable(worker)
    True
    """
    import copy
    import resource

    import numpy as np

    manifest, rows, X = load_data()
    legacy_ref = manifest["legacy_commit"]
    package_root = Path(os.environ.get("XIRT_BENCHMARK_PACKAGE_ROOT", ROOT))
    source_hashes = {
        name: digest((package_root / "xirt" / name).read_bytes())
        for name in ("xirtnet.py", "training.py", "config.py")
        if (package_root / "xirt" / name).exists()
    }
    random.seed(args.seed)
    np.random.seed(args.seed)
    params = configuration(args.optimizer, args.lr, args.loss)
    multitask = args.loss in ("multitask", "multitask_focal")
    if multitask:
        params = configuration(args.optimizer, args.lr, "mse")
        params["predictions"]["fractions"] = ["hsax", "scx"]
        for task in ("hsax", "scx"):
            params["output"].update(
                {
                    f"{task}-activation": "softmax",
                    f"{task}-dimension": len(manifest["fraction_levels"][task]),
                    f"{task}-loss": "categorical_focal"
                    if args.loss == "multitask_focal"
                    else "categorical_crossentropy",
                    f"{task}-metrics": "accuracy",
                    f"{task}-column": task,
                    f"{task}-weight": 1,
                }
            )
    params["learning"]["epochs"] = manifest["epochs"]
    params["learning"]["seed"] = args.seed
    params["learning"]["batch_size"] = manifest["batch_size"]
    input_width = manifest["max_length"]
    if args.backend == "torch-esm":
        metadata = json.loads((OUT / "esm-features.json").read_text())
        assert metadata["status"] == "ok" and metadata["pairs_sha256"] == manifest["pairs_sha256"]
        assert digest((OUT / "esm-features.npz").read_bytes()) == metadata["features_sha256"]
        with np.load(OUT / "esm-features.npz") as features:
            X = (
                (features["first"], features["second"])
                if manifest.get("siamese", True)
                else (features["first"],)
            )
        train_features = np.concatenate([a[manifest["splits"]["train"]] for a in X])
        feature_mean, feature_std = train_features.mean(0), train_features.std(0).clip(0.01)
        X = tuple(((a - feature_mean) / feature_std).astype(np.float32) for a in X)
        input_width = metadata["embedding_dim"]
        params["encoder"] = {"route": "esm-c", "embedding_dim": input_width, "model": "esmc_300m"}
    if args.backend == "legacy":
        if args.loss.startswith("categorical") or multitask:
            for task in params["predictions"]["fractions"]:
                params["output"][f"{task}-metrics"] = "categorical_accuracy"
        import tensorflow as tf

        tf.config.threading.set_inter_op_parallelism_threads(2)
        tf.config.threading.set_intra_op_parallelism_threads(2)
        tf.keras.utils.set_random_seed(args.seed)
        # tf-keras 2.16 passes 1e9 (float) to Random.randint; Python 3.12 rejects it.
        from tf_keras.src import backend as keras_backend

        class IntegerSeedRandom(random.Random):
            """Adapt tf-keras's float seed bound to Python's integer requirement."""

            def randint(self, a: int, b: int) -> int:
                """Preserve seeded randint behavior after explicit integer conversion.

                >>> int(1.e9)
                1000000000
                """
                return super().randint(int(a), int(b))

        keras_backend._SEED_GENERATOR.generator = IntegerSeedRandom(args.seed)
        source = subprocess.check_output(
            ["git", "show", legacy_ref + ":xirt/xirtnet.py"], cwd=ROOT
        ).decode()
        namespace = {"__name__": "legacy_xirtnet"}
        exec(compile(source, f"git:{legacy_ref}:xirt/xirtnet.py", "exec"), namespace)
        network_class = namespace["xiRTNET"]
        version = tf.__version__
    else:
        import torch

        torch.set_num_threads(2)
        torch.manual_seed(args.seed)
        sys.path.insert(0, str(package_root))
        from xirt.xirtnet import xiRTNET

        network_class = xiRTNET
        version = torch.__version__
    network = network_class(params, input_width, 8)
    network.build_model(
        siamese=manifest.get("siamese", True), alphabet=len(manifest["alphabet"]) + 1
    )
    network.compile()
    model = network.model
    if args.backend == "legacy":
        # The old `lr=` spelling is ignored by modern tf-keras optimizers.
        model.optimizer.learning_rate.assign(args.lr)
        param_count = model.count_params()
    else:
        module = getattr(model, "module", model)
        param_count = sum(p.numel() for p in module.parameters())
    categorical = args.loss.startswith("categorical")
    binary = args.loss.startswith("binary")
    raw_y = np.array([float(r["rp_seconds"]) for r in rows], dtype=np.float32)
    fractions = (
        np.array([int(r["hsax"]) - 1 for r in rows])
        if categorical or binary
        else np.zeros(len(rows), dtype=int)
    )
    norm = manifest["target_normalization"]
    y = (
        np.eye(10, dtype=np.float32)[fractions]
        if categorical
        else (
            (fractions >= 5).astype(np.float32)[:, None]
            if binary
            else ((raw_y - norm["mean"]) / norm["std"])[:, None]
        )
    )
    fraction_truth = {}
    if multitask:
        targets = []
        for task in ("hsax", "scx"):
            labels = {value: i for i, value in enumerate(manifest["fraction_levels"][task])}
            fraction_truth[task] = np.array([labels[int(row[task])] for row in rows])
            targets.append(np.eye(len(labels), dtype=np.float32)[fraction_truth[task]])
        targets.append(y)
    else:
        targets = [y]
    train, val, test = (manifest["splits"][key] for key in ("train", "validation", "test"))

    def split_x(idx: list[int]) -> tuple[Any, ...]:
        """Select corresponding inputs without mixing split membership.

        >>> split_x(manifest["splits"]["train"])  # doctest: +SKIP
        """
        return tuple(a[idx] for a in X)

    history = []
    best, best_epoch, weights = float("inf"), 0, None
    stale = 0
    started = time.perf_counter()
    for epoch in range(manifest["epochs"]):
        result = model.fit(
            split_x(train),
            [target[train] for target in targets],
            validation_data=(split_x(val), [target[val] for target in targets]),
            epochs=1,
            batch_size=manifest["batch_size"],
            verbose=0,
        )
        values = {k: float(v[-1]) for k, v in result.history.items()}
        values["epoch"] = epoch + 1
        history.append(values)
        score = values["val_loss"]
        substantial = score < best - manifest.get("early_stopping_min_delta", 0.0)
        if score < best:
            best, best_epoch = score, epoch + 1
            weights = (
                model.get_weights()
                if args.backend == "legacy"
                else copy.deepcopy(module.state_dict())
            )
        stale = 0 if substantial else stale + 1
        if manifest.get("early_stopping_patience") and stale >= manifest["early_stopping_patience"]:
            break
    train_seconds = time.perf_counter() - started
    if args.backend == "legacy":
        model.set_weights(weights)
    else:
        module.load_state_dict(weights)
    prediction = model.predict(split_x(test), batch_size=manifest["batch_size"], verbose=0)
    # Warm-up excluded; report median of five complete held-out inference calls.
    timings = []
    for _ in range(5):
        start = time.perf_counter()
        prediction = model.predict(split_x(test), batch_size=manifest["batch_size"], verbose=0)
        timings.append(time.perf_counter() - start)
    fraction_predictions = {}
    if multitask:
        assert isinstance(prediction, list) and len(prediction) == 3
        fraction_predictions = {
            task: np.asarray(prediction[i]) for i, task in enumerate(("hsax", "scx"))
        }
        prediction = np.asarray(prediction[-1]).ravel() * norm["std"] + norm["mean"]
        quality = metrics(raw_y[test], prediction)
        for task, probabilities in fraction_predictions.items():
            labels, truth = probabilities.argmax(1), fraction_truth[task][test]
            quality[f"{task}_accuracy"] = float((labels == truth).mean())
            quality[f"{task}_macro_recall"] = float(
                np.mean([np.mean(labels[truth == c] == c) for c in np.unique(truth)])
            )
    elif categorical or binary:
        prediction = np.asarray(prediction[0] if isinstance(prediction, list) else prediction)
        labels = prediction.argmax(1) if categorical else (prediction.ravel() >= 0.5).astype(int)
        truth = fractions[test] if categorical else (fractions[test] >= 5).astype(int)
        quality = {
            "accuracy": float((labels == truth).mean()),
            "macro_recall": float(
                np.mean([np.mean(labels[truth == c] == c) for c in np.unique(truth)])
            ),
        }
    else:
        prediction = np.asarray(prediction[0] if isinstance(prediction, list) else prediction)
        prediction = prediction.ravel() * norm["std"] + norm["mean"]
        quality = metrics(raw_y[test], prediction)
    result = {
        "status": "ok",
        "backend": args.backend,
        "seed": args.seed,
        "optimizer": args.optimizer,
        "lr": args.lr,
        "loss": args.loss,
        "framework_version": version,
        "python": platform.python_version(),
        "device": "cpu",
        "parameter_count": param_count,
        "weight_decay": params["learning"]["weight_decay"],
        "best_epoch": best_epoch,
        "validation_loss": best,
        "train_seconds": train_seconds,
        "epochs_executed": len(history),
        "epochs_budget": manifest["epochs"],
        "inference_seconds": statistics.median(timings),
        "test_count": len(test),
        "peak_process_rss_mib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024,
        "quality": quality,
        "history": history,
        "source_sha256": digest(source.encode())
        if args.backend == "legacy"
        else source_hashes["xirtnet.py"],
        "compatibility_shims": [
            "tf-keras seeded randint integer bound",
            "optimizer learning_rate assignment",
        ]
        + (["explicit categorical_accuracy metric name"] if categorical else [])
        if args.backend == "legacy"
        else [],
        "config": params,
        "implementation_sha256": source_hashes
        if args.backend != "legacy"
        else {"xirtnet.py": digest(source.encode())},
        "runner_sha256": digest(Path(__file__).read_bytes()),
    }
    result["snapshot_sha256"] = (
        os.environ.get("XIRT_BENCHMARK_SNAPSHOT") if args.backend != "legacy" else None
    )
    write_json(OUT / f"{args.name}.json", result)
    with (OUT / f"{args.name}-predictions.csv").open("w") as handle:
        writer = csv.writer(handle)
        fields = ["pair_index", "truth", "prediction"]
        if multitask:
            fields += ["hsax_truth", "hsax_probabilities", "scx_truth", "scx_probabilities"]
        writer.writerow(fields)
        for offset, (i, t, p) in enumerate(
            zip(test, raw_y[test] if not categorical and not binary else truth, prediction)
        ):
            row = [i, float(t), json.dumps(np.asarray(p).tolist())]
            if multitask:
                for task in ("hsax", "scx"):
                    row += [
                        int(fraction_truth[task][i]),
                        json.dumps(fraction_predictions[task][offset].tolist()),
                    ]
            writer.writerow(row)
    print(json.dumps({k: v for k, v in result.items() if k != "history"}))


def suite(args: argparse.Namespace) -> None:
    """Launch isolated pilot candidate jobs with fixed resource limits.

    >>> callable(suite)
    True
    """
    OUT.mkdir(exist_ok=True)
    (OUT / "logs").mkdir(exist_ok=True)
    package_snapshot, snapshot_hash = snapshot_package()
    jobs = []
    for seed in SEEDS:
        jobs += [("legacy", seed, "adam", 0.003, "mse"), ("torch", seed, "adam", 0.003, "mse")]
        jobs += [
            ("legacy", seed, "adam", 0.003, loss)
            for loss in ("categorical_crossentropy", "binary_crossentropy")
        ]
        for optimizer, rates in [
            ("adamw", [0.001, 0.003]),
            ("lion", [0.0001, 0.0003]),
            ("muon", [0.001, 0.003]),
        ]:
            jobs += [("torch", seed, optimizer, lr, "mse") for lr in rates]
        jobs += [
            ("torch", seed, "adamw", 0.003, loss)
            for loss in (
                "categorical_crossentropy",
                "categorical_focal",
                "binary_crossentropy",
                "binary_focal",
            )
        ]
        if (OUT / "esm-features.npz").exists():
            jobs += [("torch-esm", seed, "adamw", lr, "mse") for lr in (0.001, 0.003)]
    for backend, seed, optimizer, lr, loss in jobs:
        name = f"{backend}-{optimizer}-{lr:g}-{loss}-s{seed}"
        if args.only and args.only not in name:
            continue
        if (OUT / f"{name}.json").exists() and not args.rerun:
            continue
        command = [
            args.legacy_python if backend == "legacy" else args.python,
            str(Path(__file__).resolve()),
            "worker",
            "--backend",
            backend,
            "--seed",
            str(seed),
            "--optimizer",
            optimizer,
            "--lr",
            str(lr),
            "--loss",
            loss,
            "--name",
            name,
        ]
        environment = os.environ.copy()
        runtime = ROOT / "benchmarks/.cache/runtime"
        runtime.mkdir(parents=True, exist_ok=True)
        environment.update(
            {
                "CUDA_VISIBLE_DEVICES": "",
                "OMP_NUM_THREADS": "2",
                "MKL_NUM_THREADS": "2",
                "TF_USE_LEGACY_KERAS": "1",
                "TF_CPP_MIN_LOG_LEVEL": "2",
                "TMPDIR": str(runtime),
            }
        )
        if backend != "legacy":
            environment.update(
                {
                    "XIRT_BENCHMARK_PACKAGE_ROOT": str(package_snapshot),
                    "XIRT_BENCHMARK_SNAPSHOT": snapshot_hash,
                }
            )
        start = time.perf_counter()
        try:
            completed = subprocess.run(
                command, cwd=ROOT, env=environment, capture_output=True, text=True, timeout=570
            )
            (OUT / "logs" / f"{name}.txt").write_text(completed.stdout + "\n" + completed.stderr)
            if completed.returncode:
                write_json(
                    OUT / f"{name}.json",
                    {
                        "status": "failed",
                        "backend": backend,
                        "seed": seed,
                        "optimizer": optimizer,
                        "lr": lr,
                        "loss": loss,
                        "error": completed.stderr[-6000:],
                        "seconds": time.perf_counter() - start,
                    },
                )
            print(name, completed.returncode, round(time.perf_counter() - start, 2), flush=True)
        except subprocess.TimeoutExpired:
            write_json(
                OUT / f"{name}.json",
                {
                    "status": "timeout",
                    "backend": backend,
                    "seed": seed,
                    "optimizer": optimizer,
                    "lr": lr,
                    "loss": loss,
                    "seconds": 570,
                },
            )
            print(name, "timeout", flush=True)
    summarize()


def summarize() -> None:
    """Persist all recorded pilot candidates without test-based selection.

    >>> callable(summarize)
    True
    """
    records = []
    for path in sorted(OUT.glob("*-s[0-9]*.json")):
        record = json.loads(path.read_text())
        record["run"] = path.stem
        record.update(record.pop("quality", {}))
        record.pop("history", None)
        record.pop("error", None)
        for key in ("config", "implementation_sha256", "compatibility_shims"):
            record.pop(key, None)
        records.append(record)
    if records:
        fields = sorted(set().union(*(r.keys() for r in records)))
        with (OUT / "summary.csv").open("w") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(records)


def main() -> None:
    """Dispatch fixture, worker, suite, and summary CLI commands.

    >>> callable(main)
    True
    """
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    prep = sub.add_parser("prepare")
    prep.add_argument("--rows", type=int, default=1000)
    prep.add_argument("--epochs", type=int, default=12)
    run = sub.add_parser("suite")
    run.add_argument("--python", default=str(ROOT / ".venv/bin/python"))
    run.add_argument("--legacy-python", default=str(ROOT / "benchmarks/.venv-legacy/bin/python"))
    run.add_argument("--only", default="")
    run.add_argument("--rerun", action="store_true")
    work = sub.add_parser("worker")
    work.add_argument("--backend", choices=["torch", "torch-esm", "legacy"], required=True)
    work.add_argument("--seed", type=int, required=True)
    work.add_argument("--optimizer", default="adam")
    work.add_argument("--lr", type=float, default=0.003)
    work.add_argument("--loss", default="mse")
    work.add_argument("--name", required=True)
    sub.add_parser("summarize")
    args = parser.parse_args()
    {"prepare": prepare, "suite": suite, "worker": worker, "summarize": lambda _: summarize()}[
        args.command
    ](args)


if __name__ == "__main__":
    main()
