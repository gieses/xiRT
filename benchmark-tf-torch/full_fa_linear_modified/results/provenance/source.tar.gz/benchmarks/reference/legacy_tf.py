"""Deprecated comparison-only loader; no maintained TensorFlow xiRT implementation.

The historical network is read from one pinned git object. This module is not
installed in the xiRT package and must run in the separate locked TF environment.
"""

from __future__ import annotations

import os
import random
import subprocess
from pathlib import Path
from typing import Any

import numpy as np

from benchmarks.run import LEGACY, ROOT
from benchmarks.workflow.data import BenchmarkData


class LegacyTensorFlowBackend:
    """Expose the archived TF architecture through the shared benchmark contract."""

    def __init__(
        self, data: BenchmarkData, config: dict[str, Any], candidate: dict[str, Any],
        seed: int, expected_source_hash: str,
    ) -> None:
        """Load exact historical source and explicitly substitute matched AdamW."""
        import hashlib

        os.environ["TF_USE_LEGACY_KERAS"] = "1"
        import tensorflow as tf
        from tf_keras.src import backend as keras_backend

        tf.config.threading.set_inter_op_parallelism_threads(config["threads_per_job"])
        tf.config.threading.set_intra_op_parallelism_threads(config["threads_per_job"])
        tf.keras.utils.set_random_seed(seed)
        if config["deterministic"]:
            tf.config.experimental.enable_op_determinism()

        class IntegerSeedRandom(random.Random):
            """Correct tf-keras's float randint bound without changing seed semantics."""

            def randint(self, a: int, b: int) -> int:
                return super().randint(int(a), int(b))

        keras_backend._SEED_GENERATOR.generator = IntegerSeedRandom(seed)
        source = subprocess.check_output(["git", "show", f"{LEGACY}:xirt/xirtnet.py"], cwd=ROOT)
        if hashlib.sha256(source).hexdigest() != expected_source_hash:
            raise ValueError("Pinned legacy git source differs from provenance")
        namespace: dict[str, Any] = {"__name__": "deprecated_legacy_xirt_reference"}
        exec(compile(source, f"git:{LEGACY}:xirt/xirtnet.py", "exec"), namespace)
        params = data.parameters(config, candidate)
        params["learning"]["optimizer"] = "adam"
        for task in params["predictions"]["fractions"]:
            params["output"][f"{task}-metrics"] = "categorical_accuracy"
        network = namespace["xiRTNET"](params, data.manifest["max_length"], 8)
        network.build_model(
            siamese=data.manifest["siamese"], alphabet=len(data.manifest["alphabet"]) + 1
        )
        self.model = network.model
        losses = {task: params["output"][f"{task}-loss"] for task in data.tasks}
        self.optimizer = tf.keras.optimizers.AdamW(
            learning_rate=candidate["learning_rate"], weight_decay=candidate["weight_decay"],
            global_clipnorm=1.0, epsilon=1e-8,
        )
        self.model.compile(optimizer=self.optimizer, loss=losses)
        self.data, self.tf, self.base_lr = data, tf, candidate["learning_rate"]
        initial = hashlib.sha256()
        for index, value in enumerate(self.model.get_weights()):
            initial.update(f"{index}:{value.shape}:{value.dtype}".encode())
            initial.update(value.tobytes())
        self.metadata = {
            "framework": "TensorFlow", "framework_version": tf.__version__, "device": "cpu",
            "optimizer": "AdamW", "legacy_commit": LEGACY, "source_sha256": expected_source_hash,
            "optimizer_exception": "Original architecture; benchmark explicitly replaces optimizer "
                                   "with AdamW rather than the historical default Adam.",
            "checkpoint_format": "NumPy NPZ (allow_pickle=False)",
            "total_parameters": int(self.model.count_params()),
            "trainable_parameters": int(self.model.count_params()), "adapter_targets": [],
            "initial_parameters_sha256": initial.hexdigest(),
        }
        self.initial_adapter_gradient = None

    def set_learning_rate(self, ratio: float) -> None:
        """Apply the common epoch scheduler to the real Keras optimizer."""
        self.optimizer.learning_rate.assign(self.base_lr * ratio)

    def train_batch(self, indices: np.ndarray) -> float:
        """Train one predetermined minibatch of the actual legacy network."""
        self.model.reset_metrics()
        targets = {
            task: self.data.y[task][indices, None] if task == "rp"
            else np.eye(len(self.data.levels[task]), dtype=np.float32)[self.data.y[task][indices]]
            for task in self.data.tasks
        }
        value = self.model.train_on_batch(
            [array[indices] for array in self.data.inputs], targets, return_dict=True
        )
        return float(value["loss"])

    def predict(self, indices: list[int], batch_size: int) -> dict[str, np.ndarray]:
        """Run inference without calling the training API or updating optimizer state."""
        chunks = {task: [] for task in self.data.tasks}
        for start in range(0, len(indices), batch_size):
            batch = indices[start:start + batch_size]
            values = self.model([array[batch] for array in self.data.inputs], training=False)
            values = values if isinstance(values, (list, tuple)) else [values]
            for task, value in zip(self.data.tasks, values, strict=True):
                chunks[task].append(value.numpy())
        return {task: np.concatenate(values) for task, values in chunks.items()}

    def state(self) -> list[np.ndarray]:
        """Copy only the small historical network's weights for epoch selection."""
        return self.model.get_weights()

    def restore(self, state: list[np.ndarray]) -> None:
        """Restore a validation-selected state without retraining."""
        self.model.set_weights(state)

    def save(self, path: Path) -> None:
        """Persist safe array weights; checkpoint metadata lives in the run JSON."""
        with path.open("wb") as stream:
            np.savez_compressed(
                stream, **{f"weight_{index}": value for index, value in enumerate(self.state())}
            )

    def load(self, path: Path) -> None:
        """Reconstruct exactly the saved ordered network arrays without pickle."""
        with np.load(path, allow_pickle=False) as checkpoint:
            self.restore([checkpoint[f"weight_{index}"] for index in range(len(checkpoint.files))])

    def diagnostics(self) -> dict[str, Any]:
        """State explicitly that legacy reference training has no adapters."""
        return {"frozen_parameters_unchanged": True, "adapter_update_l2": None}

    def synchronize(self) -> None:
        """CPU TensorFlow calls above materialize arrays synchronously."""
