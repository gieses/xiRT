# Reproducible measured benchmarks

## Scheduled AdamW comparison

`workflow/Snakefile` schedules seven variants: deprecated TensorFlow reference,
vanilla PyTorch, frozen ESM-C, transformer LoRA, transformer LoKr, GRU-weight
LoKr and linear-weight LoKr. Two matched recurrent controls (full fine-tuning
and frozen-encoder head training) distinguish adapter effects from pretraining.
All orchestration, tuning and legacy utilities remain outside the xiRT package;
neither TensorFlow nor Snakemake is a package dependency. The old application
implementation is deprecated now and will not ship in the next release.

Use uv, Python **3.12.3** on Linux x86_64 and three separate environments. The
worker locks record the executed dependency closures; the modern lock uses
CUDA 13 PyTorch wheels. Snakemake needs a different `packaging` version from
the modern release tools, so do not install it in the package environment.

```bash
# Setup only: uv creates/syncs modern, legacy and scheduler environments.
./run.sh setup

# Complete five-cohort schedule, without training.
./run.sh dry-run

# Small real-data execution of all seven models and both controls.
./run.sh smoke

# Full experiment: expensive and separate from smoke measurements.
./run.sh full

# Resume an existing run, even after editing the package or working workflow.
./run.sh resume benchmarks/results/scheduled-v2 --dry-run
./run.sh resume benchmarks/results/scheduled-v2
```

`run.sh` uses `uv venv` and `uv pip sync`; the latter is uv's built-in
installer, not the pip program, and needs no pip installation. It preserves
the exact measured closure locks instead of resolving a new scientific
protocol. The modern benchmark lives in `benchmarks/.venv-modern`, not the
project's `.venv`, so `uv sync` for development cannot remove its ESM dependencies.
Its exact PyPI torch 2.14.1 distribution already uses CUDA 13.0; do not substitute
the differently versioned `2.14.1+cu130` index distribution into measured locks.
Additional arguments are forwarded to Snakemake, for example
`./run.sh full --config run_dir=benchmarks/results/scheduled-v3`.
The defaults write `scheduled-v2` and `scheduled-smoke-v3`; measured smoke v1/v2
and their archived configurations are untouched. The marimo dependency changes
the source fingerprint, so use a fresh smoke directory rather than overwriting v2.

Defaults require cached, checksum-matching source tables and pinned ESM-C weights.
Set `--config allow_downloads=true` only after accepting the model's separate
access/license requirements. Choose a **new `run_dir`** when changing code or
configuration; measured directories are immutable. Each run freezes code,
resolved configuration, dependency versions, the legacy commit, source hashes
and pretrained weight identity. To replay after restoring `source.tar.gz` into
the run's `source/` directory, use its archived
`source/benchmarks/workflow/Snakefile` with `--configfile RUN/config.json`
and `--rerun-triggers mtime` from the repository root, replacing `RUN` with
the measured directory. Relocating the identical archived workflow changes
Snakemake's input/command metadata; worker SHA256 checks still enforce frozen
code and protocol identity. Recheck existing artifacts without retraining:

```bash
XIRT_BENCHMARK_REPO_ROOT="$PWD" .venv/bin/python \
  benchmarks/results/scheduled-smoke-v1/source/benchmarks/workflow/pipeline.py \
  report --run-dir benchmarks/results/scheduled-smoke-v1
```

`resume` verifies the archived configuration, source files and archive checksums,
syncs the environments from the **archived** locks, then schedules the frozen
Snakefile. Completed, up-to-date jobs are retained and incomplete jobs are rerun.
It does not apply current package/configuration changes to an existing measurement.
If a stopped run left a stale lock, first ensure no other process is using that
run, then execute `./run.sh resume benchmarks/results/scheduled-v2 --unlock`
and resume normally. Do not delete `.snakemake` or the run's snapshot files.
Normal `full`/`smoke` starts reject incompatible existing runs before execution
so a failed snapshot rule cannot delete their archived source and provenance.

The full default grid has eight prespecified LR/dropout/weight-decay/scheduler
candidates, three seeds and five correlated cohorts from **two studies**.
Selection uses mean validation objective, never test scores. Train-only
within-cohort pretraining reserves its own inner validation groups; scratch
recurrent budgets include the pretraining epoch allowance. Head dropout is
not GRU recurrent dropout. ESM variants use identical pinned weights and
seeded heads, live transformer forwards and explicit PTM-blind projection.
The local profile serializes measured jobs, though shared-host contention
remains possible. Final checkpoints are reconstructed before test scoring.

`report.md`, `summary.json` and `verification.json` independently verify
prediction metrics, selection means, grouped partitions, train-only scaling,
artifact hashes and actual adapter updates. Smoke scores demonstrate execution,
not model superiority or convergence. The full grid is a schedule, not evidence
until its jobs complete. Existing historical measurements below are preserved
and use their own protocols; do not mix their Adam results with this AdamW grid.

The executed `results/scheduled-smoke-v1/report.md` covers all nine variants:
48 real FA crosslink groups (55 aggregated rows), two tuning candidates,
one seed and nine reconstructed final checkpoints. Independent verification
passed. Its two-epoch adaptation/four-epoch scratch budgets are deliberately
too small for scientific superiority claims. The 1,080-tuning/135-final full
grid is prepared and dry-run validated, **not executed**.
The uv-managed `results/scheduled-smoke-v2/` comparison also completed all
nine variants through `./run.sh smoke`, with independent verification and a
successful no-op resume. It is separate from the preserved v1 artifacts.

## Interactive result analysis

Marimo is a default project dependency. After `uv sync --locked` with your
desired backend/extras, open the read-only dashboard locally:

```bash
uv run --no-sync marimo run benchmarks/analyze_results.py --host 127.0.0.1
# To edit the notebook:
uv run --no-sync marimo edit benchmarks/analyze_results.py --host 127.0.0.1
# Optional static snapshot; it contains scientific results and row-level predictions.
uv run --no-sync marimo export html benchmarks/analyze_results.py \
  --no-include-code -o benchmarks/.cache/benchmark-analysis.html
```

Select one frozen run and cohort at a time. **Refresh artifacts** updates
completion counts during a running workflow. The notebook shows missing jobs,
historical failure events, validation-selected candidates and tuning costs,
per-seed quality/adapter diagnostics, training/LR curves, and checked
validation/test prediction plots with a training-mean baseline. Seed SD is
not a confidence interval; one-seed uncertainty remains unavailable.
Its verification badge checks published final-record hashes, not a fresh
execution of every pipeline verification check. Prediction fingerprints,
row IDs and targets are checked before plotting.

No training, model downloads, test-based selection or artifact rewriting occurs.
The notebook and all analysis code remain outside the installed `xirt` package.
Keep the server local and review exported data before sharing it.

## Historical comparisons (preserved)

All benchmark code and artifacts live here; package code is never replaced by
the harness. The legacy network is loaded at runtime with `git show` at the
commit in `results/manifest.json`. No copied legacy implementation is maintained.

```bash
# Modern environment: install the package and optional experiments first.
uv sync --locked --python 3.12 --extra cuda --extra experiments --extra esm

# Separate Python 3.12 legacy environment; no pip bootstrap.
uv venv benchmarks/.venv-legacy --python 3.12.3 --allow-existing
uv pip install \
  --python benchmarks/.venv-legacy/bin/python -r benchmarks/requirements-legacy.txt

python3 benchmarks/run.py prepare --rows 1000 --epochs 12
python3 benchmarks/run.py suite
.venv/bin/python benchmarks/embedding_heads.py features --device cuda
.venv/bin/python benchmarks/embedding_heads.py heads
.venv/bin/python benchmarks/report.py
```

`suite` launches isolated subprocesses with a 570-second per-job limit, fixed CPU
and two threads. Use `--only legacy` or `--only lion` for a subset, `--rerun` to
replace existing jobs, and `--python`/`--legacy-python` for alternate interpreter
paths. Each suite freezes the actual new package into an ignored, SHA256-indexed
local snapshot before starting subprocesses, avoiding concurrent-edit races.
`results/new-source-index.json` records every source hash; the final comparison
must use a single snapshot. Seeded subset creation is deterministic; keep the manifest when comparing
different implementations. Do not run `prepare` with different settings over an
existing results directory. All raw candidates remain in `summary.csv`; the report
chooses experimental learning rates by mean validation loss, not test quality.

ESM-C downloads weights, but peptide sequences are processed **only locally**.
The cache, environments, binary features, and logs are ignored. Model download
failures remain durable JSON artifacts. `embedding_heads.py heads` adapts only a
train-only hSAX-pretrained downstream head. **`transformer_lokr.py` instead trains
genuine LoKr adapters in ESM-C transformer layers**, with matched frozen-backbone
controls, nonzero-gradient checks, and small trainable-only checkpoints.

## Complete linked-data evaluation

The primary verdict in `results/report.md` uses all linked model-ready observed-RT
tables, not the earlier 1,000-pair pilot. `results/full-report.md`,
`full-summary.json`, and `full-per-seed.csv` contain the full-cohort results.
The original pilot results remain available as explicitly exploratory ablations.
`results/source-coverage.md` explains eligible and excluded linked source tables.

```bash
.venv/bin/python benchmarks/full_prepare.py
.venv/bin/python benchmarks/full_suite.py --workers 4 --datasets \
  full_ecoli_modified full_plink_modified full_fa_cross_modified \
  full_fa_linear_modified full_ecoli_linear_modified \
  full_ecoli_canonical full_plink_canonical full_fa_cross_canonical \
  full_fa_linear_canonical full_ecoli_linear_canonical
.venv/bin/python benchmarks/full_suite.py --workers 4 --multitask-only \
  --focal-multitask --datasets full_ecoli_modified full_plink_modified \
  full_ecoli_linear_modified
.venv/bin/python benchmarks/full_esm.py
XIRT_BENCHMARK_RESULTS_DIR="$PWD/benchmarks/results/full_fa_cross_modified" \
  .venv/bin/python benchmarks/transformer_lokr.py --epochs 6 --batch-size 128 \
  --budget-seconds 540 --project-ptms
XIRT_BENCHMARK_RESULTS_DIR="$PWD/benchmarks/results/full_fa_cross_modified" \
  .venv/bin/python benchmarks/check.py
XIRT_BENCHMARK_RESULTS_DIR="$PWD/benchmarks/results/full_fa_cross_modified" \
  .venv/bin/python benchmarks/transformer_report.py
.venv/bin/python benchmarks/full_report.py
```

Prepare once; never regenerate manifests over existing measured results.
All modification states of one residue-only pair/sequence stay in one split.
Previously inspected pilot pair identities are reserved for training in the
fresh full-data E. coli held-outs. “Canonical” directories contain **originally
unmodified** sequences; the source census also reports a different PTM-stripped
projection count. The ESM runner evaluates **all** PTM-aware labels using an
explicit PTM-blind residue projection, and separately the native unmodified
view. It never claims that ESM represents PTM chemistry.
Feature-stage timing includes persistent embedding-cache lookups; strict
unmodified views can reuse embeddings from the full projected view, so this is
not a cold-cache GPU throughput measurement. Genuine transformer training does
not use those cached embeddings.

The full transformer runner checks a training-only feasibility preflight before
starting six matched runs within its total budget. Oversized cohorts have an
explicit `resource_blocked` manifest, not a silently sampled replacement.
Single-sequence cohorts use single inputs rather than duplicated Siamese inputs.
Validate each cohort with `check.py`; successful transformer cohorts additionally
use `transformer_report.py` to check saved tensors and independently score both
validation/test predictions. Scripts support both direct CLI execution and
absolute `benchmarks.*` imports from IPython at the repository root.
