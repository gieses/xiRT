"""Checkpoint replay for the one-time retirement of the TensorFlow reference."""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import types
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--model", choices=["legacy_tf", "pytorch"], required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    run = args.run.resolve()
    os.environ["XIRT_BENCHMARK_REPO_ROOT"] = str(Path.cwd())
    sys.path.insert(0, str(run / "source"))
    package = types.ModuleType("benchmarks")
    package.__path__ = [str(run / "source/benchmarks")]
    sys.modules["benchmarks"] = package
    from benchmarks.workflow.data import BenchmarkData
    from benchmarks.workflow.pipeline import provenance

    record = provenance(run)
    data = BenchmarkData(run / "data" / args.dataset, record["config"])
    directory = run / "final" / args.dataset / args.model / f"s{args.seed}"
    selected = json.loads((directory / "result.json").read_text())
    if args.model == "legacy_tf":
        from benchmarks.reference.legacy_tf import LegacyTensorFlowBackend

        backend = LegacyTensorFlowBackend(
            data, record["config"], selected["candidate"], args.seed, record["legacy_source_sha256"]
        )
    else:
        from benchmarks.workflow.torch_backend import TorchBackend

        backend = TorchBackend(
            data, record["config"], selected["candidate"], args.seed, args.model, None
        )
    backend.load(directory / "checkpoint.bin")
    args.output.mkdir(parents=True, exist_ok=True)
    for split, indices in data.manifest["splits"].items():
        predicted = backend.predict(indices, record["config"]["batch_size"])
        path = args.output / f"{split}.csv"
        data.write_predictions(path, predicted, indices)
        if split != "train":
            import numpy as np

            with path.open() as stream:
                actual = list(csv.DictReader(stream))
            with (directory / f"{split}.csv").open() as stream:
                original = list(csv.DictReader(stream))
            if [row["pair_index"] for row in actual] != [row["pair_index"] for row in original]:
                raise ValueError("Replayed prediction identities differ from recorded predictions.")
            if not np.allclose(
                [float(row["prediction_seconds"]) for row in actual],
                [float(row["prediction_seconds"]) for row in original],
                rtol=1e-5,
                atol=1e-3,
            ):
                raise ValueError("Replayed predictions differ from the published checkpoint.")
    print(f"Replayed {args.dataset}/{args.model}/s{args.seed}", flush=True)


if __name__ == "__main__":
    main()
