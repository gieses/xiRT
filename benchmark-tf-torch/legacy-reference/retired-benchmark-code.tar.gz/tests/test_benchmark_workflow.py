"""Small offline tests for scheduling semantics, leakage guards and adapter controls."""

from __future__ import annotations

import copy
import csv
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest
import torch
import yaml

from benchmarks.workflow import pipeline, resume
from benchmarks.workflow.data import BenchmarkData
from benchmarks.workflow.pipeline import select
from benchmarks.workflow.protocol import (
    LearningRateSchedule,
    epoch_budget,
    file_hash,
    identity,
    validate_config,
    write_json,
)
from benchmarks.workflow.report import report
from benchmarks.workflow.torch_backend import ESMPairedModel
from benchmarks.workflow.worker import run_job
from tests.test_embeddings import FakeESMC
from xirt.embeddings import ESMCRetentionModel

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.skipif(shutil.which("bash") is None, reason="Benchmark runner requires Bash")
@pytest.mark.parametrize("mode", ["full", "smoke", "dry-run", "setup"])
def test_uv_runner_modes_and_forwarded_options(tmp_path, mode):
    shutil.copyfile(ROOT / "run.sh", tmp_path / "run.sh")
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    scheduler = tmp_path / "benchmarks/.venv-snakemake/bin"
    scheduler.mkdir(parents=True)
    for path, label in ((bin_dir / "uv", "uv"), (scheduler / "snakemake", "snakemake")):
        path.write_text(f'#!/bin/sh\nprintf "%s\\n" "{label} $*" >> "$UV_TEST_LOG"\n')
        path.chmod(0o755)
    log = tmp_path / "commands.log"
    env = {
        **os.environ,
        "PATH": f"{bin_dir}{os.pathsep}{os.environ['PATH']}",
        "UV_TEST_LOG": str(log),
    }
    subprocess.run(
        ["bash", str(tmp_path / "run.sh"), mode, "--cores", "4"],
        cwd=ROOT,
        env=env,
        check=True,
    )
    calls = log.read_text().splitlines()
    assert len([call for call in calls if call.startswith("uv venv ")]) == 3
    assert len([call for call in calls if call.startswith("uv pip sync ")]) == 3
    assert "benchmarks/.venv-modern/bin/python" in calls[1]
    if mode == "setup":
        assert len(calls) == 6
    else:
        assert calls[-1].startswith("snakemake --snakefile benchmarks/workflow/Snakefile")
        assert calls[-1].endswith("--cores 4")
        assert ("--dry-run" in calls[-1]) == (mode == "dry-run")
        assert ("--configfile benchmarks/workflow/smoke.yaml" in calls[-1]) == (mode == "smoke")


def test_uv_runner_rejects_unknown_modes():
    if shutil.which("bash") is None:
        pytest.skip("Benchmark runner requires Bash")
    result = subprocess.run(
        ["bash", str(ROOT / "run.sh"), "unknown"], capture_output=True, text=True
    )
    assert result.returncode == 2
    assert "Usage:" in result.stderr


@pytest.mark.skipif(shutil.which("bash") is None, reason="Benchmark runner requires Bash")
def test_uv_runner_dispatches_resume_without_syncing_current_locks(tmp_path):
    shutil.copyfile(ROOT / "run.sh", tmp_path / "run.sh")
    helper = tmp_path / "benchmarks/workflow/resume.py"
    helper.parent.mkdir(parents=True)
    helper.write_text("import sys\nprint('resume ' + ' '.join(sys.argv[1:]))\n")
    bin_dir = tmp_path / "bin"
    bin_dir.mkdir()
    uv = bin_dir / "uv"
    uv.write_text(
        f'#!/bin/sh\n[ "$*" = "python find 3.12.3" ] || exit 77\n'
        f"printf '%s\\n' '{sys.executable}'\n"
    )
    uv.chmod(0o755)
    result = subprocess.run(
        ["bash", str(tmp_path / "run.sh"), "resume", "benchmarks/results/frozen", "--dry-run"],
        cwd=ROOT,
        env={**os.environ, "PATH": f"{bin_dir}{os.pathsep}{os.environ['PATH']}"},
        capture_output=True,
        text=True,
        check=True,
    )
    assert result.stdout.strip() == "resume benchmarks/results/frozen --dry-run"
    missing = subprocess.run(
        ["bash", str(tmp_path / "run.sh"), "resume"], capture_output=True, text=True
    )
    assert missing.returncode == 2
    assert "RUN_DIR" in missing.stderr


@pytest.fixture
def frozen_run(tmp_path):
    run = tmp_path / "benchmarks/results/frozen"
    source = run / "source"
    files = {
        "benchmarks/workflow/Snakefile": "rule all:\n    input: []\n",
        "benchmarks/workflow/profiles/local/config.yaml": "rerun-incomplete: true\n",
        **{
            f"benchmarks/workflow/envs/{label}.lock.txt": "# Python 3.12.3\n"
            for label in ("modern", "legacy", "scheduler")
        },
    }
    for name, text in files.items():
        path = source / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
    archive = run / "source.tar.gz"
    archive.write_bytes(b"fixture archive")
    config = {
        "run_dir": str(run.relative_to(tmp_path)),
        "modern_python": "benchmarks/.venv-modern/bin/python",
        "legacy_python": "benchmarks/.venv-legacy/bin/python",
    }
    hashes = {name: file_hash(source / name) for name in files}
    write_json(run / "config.json", config)
    write_json(
        run / "provenance.json",
        {
            "config": config,
            "protocol_sha256": identity(config),
            "source_files": hashes,
            "source_snapshot_sha256": identity(hashes),
            "source_archive_sha256": file_hash(archive),
        },
    )
    return tmp_path, run, config


def test_resume_verifies_frozen_assets_and_uses_archived_locks(frozen_run, monkeypatch):
    root, run, config = frozen_run
    (root / "xirt.py").write_text("unrelated working tree changes")
    calls = []

    def execute(command, **kwargs):
        calls.append((command, kwargs))
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(resume.subprocess, "run", execute)
    assert resume.validate_run(root, run) == config
    assert resume.main([str(run), "--dry-run", "--cores", "4"], root=root) == 0
    syncs = [command for command, _ in calls if command[:3] == ["uv", "pip", "sync"]]
    assert len(syncs) == 3
    assert all(str(run / "source/benchmarks/workflow/envs") in command[-1] for command in syncs)
    command, kwargs = calls[-1]
    assert command[command.index("--snakefile") + 1] == str(
        run / "source/benchmarks/workflow/Snakefile"
    )
    assert command[command.index("--configfile") + 1] == str(run / "config.json")
    assert command[-6:] == [
        "--rerun-triggers",
        "mtime",
        "--rerun-incomplete",
        "--dry-run",
        "--cores",
        "4",
    ]
    assert kwargs["cwd"] == root


@pytest.mark.parametrize(
    ("asset", "message"),
    [
        ("source/benchmarks/workflow/Snakefile", "Frozen workflow source changed"),
        ("source.tar.gz", "Frozen source archive was modified"),
        ("config.json", "config.json differs"),
    ],
)
def test_resume_rejects_modified_assets_before_environment_changes(
    frozen_run, monkeypatch, asset, message, capsys
):
    root, run, _ = frozen_run
    path = run / asset
    original = path.read_bytes()
    path.write_text("{}" if asset == "config.json" else "tampered")
    calls = []
    monkeypatch.setattr(resume.subprocess, "run", lambda *args, **kwargs: calls.append(args))
    with pytest.raises(SystemExit) as error:
        resume.main([str(run)], root=root)
    assert error.value.code == 2
    assert message in capsys.readouterr().err
    assert calls == []
    assert (run / "provenance.json").exists()
    assert path.read_bytes() != original


@pytest.mark.parametrize("option", ["--config", "--configfile=other.yaml", "--snakefile", "-d"])
def test_resume_rejects_configuration_overrides(frozen_run, option, capsys):
    root, run, _ = frozen_run
    with pytest.raises(SystemExit) as error:
        resume.main([str(run), option], root=root)
    assert error.value.code == 2
    assert "frozen workflow/configuration" in capsys.readouterr().err


def test_restart_guard_preserves_frozen_snapshot_when_working_source_changes(
    frozen_run, monkeypatch
):
    root, run, config = frozen_run
    record = json.loads((run / "provenance.json").read_text())
    paths = []
    for name in record["source_files"]:
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(run / "source" / name, path)
        paths.append(path)
    monkeypatch.setattr(pipeline, "SOURCE_ROOT", root)
    monkeypatch.setattr(pipeline, "source_inputs", lambda: paths)
    pipeline.check_existing_run(run, config)
    before = {path: path.read_bytes() for path in run.rglob("*") if path.is_file()}
    paths[0].write_text("working source changed")
    with pytest.raises(ValueError, match="bash run.sh resume"):
        pipeline.check_existing_run(run, config)
    assert all(path.read_bytes() == content for path, content in before.items())
    shutil.copyfile(run / "source" / paths[0].relative_to(root), paths[0])
    with pytest.raises(ValueError, match="bash run.sh resume"):
        pipeline.check_existing_run(run, {**config, "epochs": 99})


def test_restart_guard_rejects_missing_provenance_without_touching_results(tmp_path):
    run = tmp_path / "run"
    run.mkdir()
    result = run / "result.json"
    result.write_text('{"status": "ok"}')
    with pytest.raises(ValueError, match="no provenance"):
        pipeline.check_existing_run(run, {})
    assert result.read_text() == '{"status": "ok"}'


@pytest.fixture
def config():
    value = yaml.safe_load((ROOT / "benchmarks/workflow/config.yaml").read_text())
    value.update(yaml.safe_load((ROOT / "benchmarks/workflow/smoke.yaml").read_text()))
    return value


@pytest.fixture
def prepared(tmp_path, config):
    run = tmp_path / "run"
    directory = run / "data/full_fa_cross_modified"
    directory.mkdir(parents=True)
    rows = []
    for index in range(20):
        first, second = "A" * (index + 1) + "K", "CK"
        rows.append(
            {
                "peptide_a": first,
                "peptide_b": second,
                "rp_seconds": 100 + index * 17,
                "hsax": index % 2 + 1,
                "scx": index % 3 + 1,
                "tokens_a": json.dumps(["H-", *first, "-OH"]),
                "tokens_b": json.dumps(["H-", *second, "-OH"]),
                "group_key": json.dumps(sorted((first, second))),
            }
        )
    with (directory / "pairs.csv").open("w") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    train_y = np.array([row["rp_seconds"] for row in rows[:14]])
    write_json(
        directory / "manifest.json",
        {
            "scope": "smoke_subset",
            "pairs_sha256": file_hash(directory / "pairs.csv"),
            "siamese": True,
            "alphabet": ["H-", "-OH", "A", "C", "K"],
            "max_length": 24,
            "fraction_levels": {"hsax": [1, 2], "scx": [1, 2, 3]},
            "target_normalization": {"mean": float(train_y.mean()), "std": float(train_y.std())},
            "splits": {"train": list(range(14)), "validation": [14, 15, 16], "test": [17, 18, 19]},
            "pretraining_splits": {"train": list(range(12)), "validation": [12, 13]},
        },
    )
    return run, BenchmarkData(directory, config)


def test_protocol_labels_resources_and_budget(config):
    validated = validate_config(config, ROOT)
    assert set(validated["variants"]) >= {
        "legacy_tf",
        "pytorch",
        "esm_frozen",
        "esm_lora",
        "esm_lokr",
        "lokr_gru",
        "lokr_linear",
    }
    assert epoch_budget(config, "pytorch", "tune") == 4
    assert epoch_budget(config, "lokr_gru", "tune") == 2
    assert epoch_budget(config, "esm_lora", "tune") == 2
    invalid = copy.deepcopy(config)
    invalid["run_dir"] = "xirt"
    with pytest.raises(ValueError, match="distinct run directory"):
        validate_config(invalid, ROOT)
    invalid = copy.deepcopy(config)
    invalid["seeds"] = [43]
    with pytest.raises(ValueError, match="final seed"):
        validate_config(invalid, ROOT)


def test_common_schedulers_are_deterministic_and_validation_driven(config):
    cosine = LearningRateSchedule("cosine", 10, config["scheduler"])
    assert cosine.ratio(0) == 1
    assert cosine.ratio(9) == pytest.approx(0.01)
    plateau = LearningRateSchedule("plateau", 10, config["scheduler"])
    plateau.observe(1.0)
    for _ in range(3):
        plateau.observe(1.0)
    assert plateau.ratio(4) == 0.5
    plateau.observe(0.1)
    assert plateau.ratio(5) == 0.5
    constant = LearningRateSchedule("constant", 10, config["scheduler"])
    assert all(constant.ratio(epoch) == 1 for epoch in range(10))


def test_native_adapter_warmstart_controls_and_final_reconstruction(config, prepared):
    run, _ = prepared
    config["variants"] = [
        "pytorch",
        "lokr_gru",
        "lokr_linear",
        "recurrent_full_finetune",
        "recurrent_frozen_encoder",
    ]
    manifest_path = run / "data/full_fa_cross_modified/manifest.json"
    manifest = json.loads(manifest_path.read_text())
    manifest["actual_source_files"] = []
    write_json(manifest_path, manifest)
    (run / "source.tar.gz").write_bytes(b"offline-fixture")
    provenance = {
        "config": config,
        "protocol_sha256": identity(config),
        "source_snapshot_sha256": "offline-fixture",
        "legacy_source_sha256": "unused",
        "source_archive_sha256": file_hash(run / "source.tar.gz"),
        "scope": "smoke_subset",
    }
    run_job(ROOT, run, provenance, "full_fa_cross_modified", "pytorch", "pretrain", 17, None)
    for variant in (
        "pytorch",
        "lokr_gru",
        "lokr_linear",
        "recurrent_full_finetune",
        "recurrent_frozen_encoder",
    ):
        for candidate in config["candidates"]:
            run_job(
                ROOT,
                run,
                provenance,
                "full_fa_cross_modified",
                variant,
                "tune",
                17,
                candidate["id"],
            )
            directory = run / "tuning/full_fa_cross_modified" / variant / candidate["id"] / "s17"
            assert not (directory / "test.csv").exists()
        select(run, config, "full_fa_cross_modified", variant)
        run_job(ROOT, run, provenance, "full_fa_cross_modified", variant, "final", 17, None)
        record = json.loads(
            (run / "final/full_fa_cross_modified" / variant / "s17/result.json").read_text()
        )
        assert record["test_evaluated"]
        assert record["diagnostics"]["frozen_parameters_unchanged"]
        if variant.startswith("lokr"):
            assert record["initial_adapter_gradient_l2"] > 0
            assert record["diagnostics"]["adapter_update_l2"] > 0
    report(run, provenance)
    selection_path = run / "selection/full_fa_cross_modified/pytorch.json"
    selection = json.loads(selection_path.read_text())
    for candidate in selection["candidates"]:
        candidate["mean_validation_loss"] += 1
    write_json(selection_path, selection)
    with pytest.raises(ValueError, match="Candidate mean"):
        report(run, provenance)


def test_esm_heads_initialization_pair_symmetry_and_zero_adapters(config, prepared):
    _, data = prepared
    candidate = config["candidates"][0]
    models = [
        ESMPairedModel(
            ESMCRetentionModel(model=FakeESMC(), adapter_kind=kind),
            data,
            config,
            candidate,
            17,
        ).eval()
        for kind in ("none", "lora", "lokr")
    ]
    tokens, mask = models[0].encoder.tokenize(["AC", "W"])
    predictions = [model(tokens, mask, tokens.flip(0), mask.flip(0))["rp"] for model in models]
    for prediction in predictions[1:]:
        torch.testing.assert_close(prediction, predictions[0])
    torch.testing.assert_close(predictions[0][0], predictions[0][1])
