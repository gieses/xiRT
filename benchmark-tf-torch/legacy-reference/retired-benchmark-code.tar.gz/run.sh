#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"

mode="${1:-full}"
usage='Usage: ./run.sh [full|smoke|dry-run|setup] [Snakemake options...]
       ./run.sh resume RUN_DIR [Snakemake options...]'
case "$mode" in
    full|smoke|dry-run|setup|resume) [[ $# -eq 0 ]] || shift ;;
    -h|--help) printf '%s\n' "$usage"; exit 0 ;;
    *) printf '%s\n' "$usage" >&2; exit 2 ;;
esac

if [[ "$mode" == resume && $# -eq 0 ]]; then
    printf '%s\n' "$usage" >&2
    exit 2
fi

if ! command -v uv >/dev/null 2>&1; then
    printf '%s\n' 'uv is required: install it from https://docs.astral.sh/uv/getting-started/installation/' >&2
    exit 1
fi

if [[ "$mode" == resume ]]; then
    interpreter="$(uv python find 3.12.3)"
    exec "$interpreter" benchmarks/workflow/resume.py "$@"
fi

for environment in modern legacy snakemake; do
    uv venv --python 3.12.3 --allow-existing "benchmarks/.venv-$environment"
    lock="$environment"
    [[ "$environment" != snakemake ]] || lock=scheduler
    uv pip sync --python "benchmarks/.venv-$environment/bin/python" --strict \
        "benchmarks/workflow/envs/$lock.lock.txt"
done

[[ "$mode" != setup ]] || exit 0
options=()
case "$mode" in
    dry-run) options=(--dry-run) ;;
    smoke) options=(--configfile benchmarks/workflow/smoke.yaml) ;;
esac
exec benchmarks/.venv-snakemake/bin/snakemake \
    --snakefile benchmarks/workflow/Snakefile \
    --profile benchmarks/workflow/profiles/local "${options[@]}" "$@"
