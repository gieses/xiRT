"""Independently verify and report genuine pretrained-transformer adaptation."""

from __future__ import annotations

import csv
import json
import statistics
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from benchmarks.run import OUT, SEEDS, digest, load_data, metrics, write_json

DEST = OUT / "transformer_lokr"
MARKER = "## Genuine ESM-C transformer LoKr: matched supervised RP experiment"


def main() -> None:
    """Verify real gradients, trainable-only checkpoints, provenance, and predictions.

    >>> callable(main)
    True
    """
    import torch

    manifest, rows, _ = load_data()
    experiment = json.loads((DEST / "manifest.json").read_text())
    assert experiment["parent_manifest_sha256"] == digest((OUT / "manifest.json").read_bytes())
    records = [json.loads(p.read_text()) for p in sorted(DEST.glob("*-s[0-9]*.json"))]
    lines = [
        MARKER,
        "",
        f"This separate experiment uses the **same {manifest['pair_count']} pairs, saved "
        "train/validation/test indices and seeds 17/29/43**, with the genuine locally cached ESM-C 300M "
        "transformer. It is not the downstream-head-only experiment above.",
        "",
        f"- Matched budget: {experiment['epochs']} epochs, batch {experiment['batch_size_pairs']} "
        f"{'pairs' if manifest.get('siamese', True) else 'single sequences'}, no feature scaling, "
        "training-only RP normalization from the parent manifest.",
        "- Both variants use `ESMCRetentionModel`: one freezes the entire backbone including zero-update "
        "LoKr wrappers; the other trains rank-4/factor-4/alpha-4 LoKr in **all transformer Linear layers**. "
        "Both train the same linear regressor and begin with identical regressor weights per seed.",
        "- AdamW: adapter LR 0.0001, regressor LR 0.001, decay 0.01, gradient norm clip 1. "
        "CUDA bfloat16 autocast, float32 pooling/loss/targets. No hyperparameter choice uses test data.",
        "- Siamese add is implemented as predictions(first)+predictions(second)−regressor.bias, "
        "equivalent to one linear regressor over summed pooled representations with a single bias.",
        "- Validation chooses the checkpoint. Only trainable adapter/regressor tensors are saved; "
        "frozen pretrained weights are identified by their separately recorded checkpoint SHA256/revision.",
        "- Wall-clock training includes actual transformer forward/backward, validation and small "
        "trainable-only best-state copies. No cached embeddings are used in these timed training runs. "
        "Inference is median of three full held-out calls after warm-up, CUDA-synchronized.",
        "",
        "| Variant | seed | best epoch | validation MAE s | validation RMSE s | test MAE s | "
        "test RMSE s | test R² | Pearson | train s | inference ms | trainable params | GPU allocated MiB |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for result in records:
        assert result["status"] == "ok"
        assert result["epochs"] == 6 and len(result["history"]) == 6
        best = min(result["history"], key=lambda row: row["val_loss"])
        assert best["epoch"] == result["best_epoch"]
        assert np.isclose(best["val_loss"], result["validation_loss"])
        prediction_rows = list(
            csv.DictReader((DEST / f"{result['variant']}-s{result['seed']}-predictions.csv").open())
        )
        for split, key in (
            ("validation", "validation_quality_seconds"),
            ("test", "test_quality_seconds"),
        ):
            selected = [row for row in prediction_rows if row["split"] == split]
            indices = manifest["splits"][split]
            assert [int(row["pair_index"]) for row in selected] == indices
            truth = np.array([float(row["truth_seconds"]) for row in selected])
            assert np.allclose(truth, [float(rows[i]["rp_seconds"]) for i in indices])
            prediction = np.array([float(row["prediction_seconds"]) for row in selected])
            independently_scored = metrics(truth, prediction)
            for metric, value in independently_scored.items():
                assert np.isclose(value, result[key][metric], atol=1.0e-5, rtol=1.0e-5)
        checkpoint = DEST / result["checkpoint"]
        assert digest(checkpoint.read_bytes()) == result["checkpoint_sha256"]
        saved = torch.load(checkpoint, weights_only=True, map_location="cpu")
        tensors = saved["trainable_state"]
        assert tensors and all("lokr_" in name or name.startswith("regressor.") for name in tensors)
        assert sum(tensor.numel() for tensor in tensors.values()) == result["trainable_parameters"]
        assert checkpoint.stat().st_size == result["checkpoint_bytes"]
        assert saved["seed"] == result["seed"] and saved["best_epoch"] == result["best_epoch"]
        assert saved["variant"] == result["variant"]
        assert saved["pretrained_checkpoint"] == experiment["pretrained_checkpoint"]
        assert saved["adapter_config"] == {"rank": 4, "factor": 4, "alpha": 4.0}
        if result["variant"] == "frozen_backbone":
            assert set(tensors) == {"regressor.weight", "regressor.bias"}
        else:
            assert any("lokr_" in name for name in tensors)
            nonzero = sum(
                int(torch.count_nonzero(tensor))
                for name, tensor in tensors.items()
                if name.endswith("lokr_w2_b")
            )
            assert nonzero == result["nonzero_adapter_w2_b_entries"] > 0
        # Correct the earlier running->completed manifest pointer, not measured values.
        result["manifest_sha256"] = digest((DEST / "manifest.json").read_bytes())
        write_json(DEST / f"{result['variant']}-s{result['seed']}.json", result)
        v, t = result["validation_quality_seconds"], result["test_quality_seconds"]
        lines.append(
            f"| {result['variant']} | {result['seed']} | {result['best_epoch']} | "
            f"{v['mae']:.2f} | {v['rmse']:.2f} | {t['mae']:.2f} | {t['rmse']:.2f} | "
            f"{t['r2']:.3f} | {t['pearson']:.3f} | {result['train_seconds']:.2f} | "
            f"{result['inference_seconds'] * 1000:.2f} | {result['trainable_parameters']} | "
            f"{result['peak_gpu_allocated_mib']:.2f} |"
        )
    if len(records) == 6:
        for seed in SEEDS:
            paired = [r for r in records if r["seed"] == seed]
            assert (
                len(paired) == 2
                and paired[0]["initial_regressor_sha256"] == paired[1]["initial_regressor_sha256"]
            )
        groups = {
            variant: [r for r in records if r["variant"] == variant]
            for variant in ("frozen_backbone", "transformer_lokr")
        }
        frozen, adapted = groups.values()
        for row in frozen:
            assert row["nonzero_adapter_w2_b_entries"] == 0
        for row in adapted:
            assert row["first_adapter_gradient_l2"] > 0 and row["nonzero_adapter_w2_b_entries"] > 0
        rmse = {
            variant: statistics.mean(r["test_quality_seconds"]["rmse"] for r in values)
            for variant, values in groups.items()
        }
        lines += [
            "",
            f"Across three paired seeds, mean held-out RMSE was "
            f"**{rmse['frozen_backbone']:.2f}s frozen vs {rmse['transformer_lokr']:.2f}s transformer LoKr** "
            f"({(rmse['transformer_lokr'] / rmse['frozen_backbone'] - 1) * 100:+.1f}%). "
            "Nonzero adapter gradients during supervised RP training and nonzero initially-zero "
            "adapter factors after best-checkpoint restoration verify actual transformer adaptation.",
            "",
            f"All six runs completed in **{experiment['total_seconds']:.2f}s total**, including "
            f"cached model loading ({experiment['model_load_seconds']:.2f}s), feasibility preflight, "
            "training and held-out inference. No model download was needed.",
            "",
            "**Interpretation:** the limited six-epoch schedule and conservative prespecified learning rates "
            "establish genuine matched transformer adaptation, not converged quality or a universal "
            "LoKr advantage. They are not directly comparable to 12-epoch cached-feature/head experiments "
            "with different feature scaling, heads and iteration budgets. "
            "The original 84 small-subset runs remain unchanged and cannot alone support a full-data verdict.",
        ]
    else:
        lines += [
            "",
            "**Incomplete/resource-limited:** a full three-seed paired verdict is not justified.",
        ]
    lines += [
        "",
        "Artifacts: `transformer_lokr/manifest.json`, per-seed raw histories/validation/test "
        "predictions, parameter/memory/timing metadata and small trainable-only `.pt` checkpoints. "
        "Base checkpoint files are neither copied into checkpoints nor sent off-host.",
        "",
        "Re-run:",
        "",
        "```bash",
        ".venv/bin/python benchmarks/transformer_lokr.py --epochs 6 --batch-size 64 --budget-seconds 540",
        ".venv/bin/python benchmarks/transformer_report.py",
        "```",
    ]
    text = "\n".join(lines) + "\n"
    (DEST / "report.md").write_text(text)
    report = OUT / "report.md"
    if report.exists():
        previous = report.read_text()
        full_marker = "<!-- FULL-COHORT-REPORT-END -->"
        prefix = ""
        if full_marker in previous:
            prefix, previous = previous.split(full_marker, 1)
            prefix += full_marker + "\n\n"
        report.write_text(prefix + previous.split(MARKER)[0].rstrip() + "\n\n" + text)
    with (DEST / "summary.csv").open("w") as handle:
        fields = [
            "variant",
            "seed",
            "best_epoch",
            "validation_loss",
            "train_seconds",
            "inference_seconds",
            "trainable_parameters",
            "peak_gpu_allocated_mib",
            "checkpoint_bytes",
        ]
        fields += ["test_mae", "test_rmse", "test_r2", "test_pearson"]
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in records:
            writer.writerow(
                {
                    **{k: row[k] for k in fields if not k.startswith("test_")},
                    **{f"test_{k}": value for k, value in row["test_quality_seconds"].items()},
                }
            )
    print(f"Validated {len(records)} real transformer runs and saved report.")


if __name__ == "__main__":
    main()
