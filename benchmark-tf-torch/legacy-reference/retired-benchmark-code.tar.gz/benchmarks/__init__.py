"""Locally executed, provenance-recorded xiRT comparison experiments."""
