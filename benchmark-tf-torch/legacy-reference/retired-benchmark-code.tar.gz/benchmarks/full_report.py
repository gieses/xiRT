"""Report all linked observed-RT cohorts without substituting the earlier pilot."""

from __future__ import annotations

import collections
import csv
import json
import math
import statistics
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from benchmarks.run import ROOT, metrics, write_json

RESULTS = ROOT / "benchmarks/results"
MARKER = "<!-- FULL-COHORT-REPORT-END -->"


def mean_sd(values: list[float], digits: int = 2) -> str:
    """Format seed dispersion, not a confidence interval over independent studies.

    >>> mean_sd([1., 3.], 1)
    '2.0 ± 1.4'
    """
    mean = statistics.mean(values)
    return (
        f"{mean:.{digits}f} ± {statistics.stdev(values):.{digits}f}"
        if len(values) > 1
        else f"{mean:.{digits}f}"
    )


def validation_rmse(record: dict[str, Any], manifest: dict[str, Any]) -> float:
    """Convert the selected epoch's RP MSE to seconds, never joint-task loss.

    >>> validation_rmse({"best_epoch": 1, "history": [{"epoch": 1, "val_loss": .25}]},
    ...                 {"target_normalization": {"std": 10.}})
    5.0
    """
    epoch = next(item for item in record["history"] if item["epoch"] == record["best_epoch"])
    return (
        math.sqrt(epoch.get("val_rp_mse", epoch.get("val_rp_loss", epoch["val_loss"])))
        * manifest["target_normalization"]["std"]
    )


def main() -> None:
    """Write full-cohort aggregates, per-seed scores, and a leading verdict.

    >>> callable(main)
    True
    """
    manifests: dict[str, dict[str, Any]] = {}
    groups: dict[tuple[str, str, str, str], list[dict[str, Any]]] = collections.defaultdict(list)
    per_seed: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    baselines: dict[str, dict[str, float]] = {}
    for directory in sorted(RESULTS.glob("full_*")):
        manifest = json.loads((directory / "manifest.json").read_text())
        manifests[directory.name] = manifest
        with (directory / "pairs.csv").open() as handle:
            pairs = list(csv.DictReader(handle))
        truth = [float(pairs[index]["rp_seconds"]) for index in manifest["splits"]["test"]]
        baselines[directory.name] = metrics(
            truth, [manifest["target_normalization"]["mean"]] * len(truth)
        )
        for path in sorted(directory.glob("*-s[0-9]*.json")):
            record = json.loads(path.read_text())
            if "status" not in record:
                continue
            if record["status"] != "ok":
                failures.append(
                    {"dataset": directory.name, "path": str(path.relative_to(ROOT)), **record}
                )
                continue
            key = directory.name, record["backend"], record["optimizer"], record["loss"]
            groups[key].append(record)
            per_seed.append(
                {
                    "dataset": directory.name,
                    "backend": record["backend"],
                    "optimizer": record["optimizer"],
                    "loss": record["loss"],
                    "seed": record["seed"],
                    "best_epoch": record["best_epoch"],
                    "epochs_executed": len(record["history"]),
                    "validation_rp_rmse_seconds": validation_rmse(record, manifest),
                    "test_rp_mae_seconds": record["quality"]["mae"],
                    "test_rp_rmse_seconds": record["quality"]["rmse"],
                    "test_rp_r2": record["quality"]["r2"],
                    "train_seconds": record["train_seconds"],
                    "inference_seconds": record["inference_seconds"],
                    "snapshot_sha256": record.get("snapshot_sha256", ""),
                    "record": str(path.relative_to(ROOT)),
                }
            )
    aggregates = []
    for (dataset, backend, optimizer, loss), records in sorted(groups.items()):
        assert sorted(record["seed"] for record in records) == [17, 29, 43], (
            dataset,
            backend,
            optimizer,
            loss,
        )
        aggregates.append(
            {
                "dataset": dataset,
                "backend": backend,
                "optimizer": optimizer,
                "loss": loss,
                "seeds": len(records),
                "validation_rp_rmse_seconds_mean": statistics.mean(
                    validation_rmse(r, manifests[dataset]) for r in records
                ),
                "test_quality_mean": {
                    key: statistics.mean(record["quality"][key] for record in records)
                    for key in records[0]["quality"]
                },
                "test_quality_sd": {
                    key: statistics.stdev(record["quality"][key] for record in records)
                    for key in records[0]["quality"]
                },
                "train_seconds_mean": statistics.mean(r["train_seconds"] for r in records),
                "inference_seconds_mean": statistics.mean(r["inference_seconds"] for r in records),
                "peak_process_rss_mib_mean": statistics.mean(
                    r["peak_process_rss_mib"] for r in records
                ),
                "parameter_count": records[0]["parameter_count"],
            }
        )
    modified = [dataset for dataset in manifests if dataset.endswith("_modified")]
    comparisons = []
    for dataset in modified:
        legacy = groups[dataset, "legacy", "adam", "mse"]
        new = groups[dataset, "torch", "adam", "mse"]
        old_rmse = statistics.mean(r["quality"]["rmse"] for r in legacy)
        new_rmse = statistics.mean(r["quality"]["rmse"] for r in new)
        comparisons.append(
            {
                "dataset": dataset,
                "legacy_rmse": old_rmse,
                "new_rmse": new_rmse,
                "rmse_change_percent": 100 * (new_rmse / old_rmse - 1),
                "train_workflow_ratio_legacy_over_new": statistics.mean(
                    r["train_seconds"] for r in legacy
                )
                / statistics.mean(r["train_seconds"] for r in new),
                "inference_ratio_legacy_over_new": statistics.mean(
                    r["inference_seconds"] for r in legacy
                )
                / statistics.mean(r["inference_seconds"] for r in new),
            }
        )
    summary = {
        "schema_version": 1,
        "executed_date": "2026-10-12",
        "successful_runs": len(per_seed),
        "failures": failures,
        "biological_studies": 2,
        "correlated_modified_cohort_comparisons": comparisons,
        "aggregates": aggregates,
        "baselines": baselines,
        "selection": "prespecified LR .003; validation-only best epoch, not test-selected configuration",
        "dispersion": "sample SD across 3 training seeds; not study-level uncertainty",
        "transformer_experiments": {},
    }
    write_json(RESULTS / "full-summary.json", summary)
    with (RESULTS / "full-per-seed.csv").open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(per_seed[0]))
        writer.writeheader()
        writer.writerows(per_seed)
    improved = sum(item["new_rmse"] < item["legacy_rmse"] for item in comparisons)
    lines = [
        "# Full linked-data benchmark — primary verdict",
        "",
        "Executed October 12, 2026. This section supersedes the 1,000-pair pilot as the basis for the verdict; "
        "the original pilot artifacts and report remain intact below.",
        "",
        f"**{len(per_seed)} successful full-cohort runs; {len(failures)} failures.** "
        f"With prespecified Adam LR .003, new xiRT has lower mean held-out RP RMSE in **{improved}/5 correlated "
        "modification-aware cohorts**. These are two biological studies, not five independent replications. "
        "Quality and workflow speed are dataset-dependent; no universal production or pure-framework superiority is established.",
        "",
        "## Coverage, identity, and held-out protection",
        "",
        "All model-ready TT/FDR≤1% observed-RT cases from the linked E. coli and FA tables are included in the "
        "modification-aware views. E. coli primary/local tables use primary-priority normalized Run+PSMID deduplication "
        "(three duplicate CSMs removed). Alternative pLink results and linear/crosslinked views are correlated. "
        "Raw spectra/FASTA, software, unlabeled mzID subsets, and circular post-xiRT-rescoring tables add no independent "
        "supervised cases; see `source-coverage.md` and its JSON inventory.",
        "",
        "Modification-aware identity preserves PTMs. **Canonical here means originally unmodified 20-AA sequences**, "
        "not the source census's PTM-stripped projection counts. All PTM states of an uppercase-residue identity are "
        "assigned to one train/validation/test split; numeric BS3 annotations are removed from that grouping key. "
        "The 18 originally misgrouped FA-linear runs are quarantined under `superseded/` and excluded. "
        "Previously inspected E. coli pilot pair identities are training-only in these fresh held-outs.",
        "",
        "| Cohort | PTM-aware examples | Originally unmodified examples | PTM-stripped groups | PTM-aware train/val/test | Mean-baseline test RMSE s |",
        "|---|---:|---:|---:|---|---:|",
    ]
    for dataset in modified:
        manifest = manifests[dataset]
        canonical = manifests[dataset.replace("_modified", "_canonical")]
        counts = "/".join(
            str(len(manifest["splits"][key])) for key in ("train", "validation", "test")
        )
        lines.append(
            f"| {dataset.removeprefix('full_').removesuffix('_modified')} | {manifest['pair_count']} | "
            f"{canonical['pair_count']} | {manifest['unmodified_group_count']} | {counts} | {baselines[dataset]['rmse']:.2f} |"
        )
    lines += [
        "",
        "Units are seconds throughout; pLink's minute-valued RP is explicitly multiplied by 60. "
        "Each manifest saves source SHA256, row indices, aggregation, unit factors, tokens, split indices, and "
        "train-only target normalization. Crosslinked pair targets are CSM means; linear targets use single sequences.",
        "",
        "## Prespecified RP comparisons on complete modification-aware cohorts",
        "",
        "| Cohort | Legacy Adam RMSE s | New Adam RMSE s | RMSE change | Train legacy/new | Inference legacy/new |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for item in comparisons:
        lines.append(
            f"| {item['dataset']} | {item['legacy_rmse']:.2f} | {item['new_rmse']:.2f} | "
            f"{item['rmse_change_percent']:+.1f}% | {item['train_workflow_ratio_legacy_over_new']:.2f}× | "
            f"{item['inference_ratio_legacy_over_new']:.2f}× |"
        )
    lines += [
        "",
        "Thirty maximum epochs, validation-only early stopping (patience 8), seeds 17/29/43, "
        "GRU16/embedding8/dense16, no dropout/BN, two CPU threads per worker. Batch 64 (256 for >10,000 examples). "
        "The actual historical TensorFlow implementation is loaded by git revision; the new implementation uses "
        "immutable source snapshots recorded in each cohort. CPU runs overlapped on this shared host, so timings "
        "are measured workflow costs under contention, not isolated hardware throughput. Different padding, "
        "initialization, implementations, and stopping behavior prevent attribution to framework alone.",
        "",
        "## All RP views: mean ± sample SD over three seeds",
        "",
        "| Cohort | Backend/optimizer | Val RMSE s | Test MAE s | Test RMSE s | Test R² | Train s | Inference ms | RSS MiB |",
        "|---|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for key, records in sorted(groups.items()):
        dataset, backend, optimizer, loss = key
        if loss != "mse":
            continue
        lines.append(
            f"| {dataset} | {backend}/{optimizer} | "
            f"{mean_sd([validation_rmse(r, manifests[dataset]) for r in records])} | "
            f"{mean_sd([r['quality']['mae'] for r in records])} | "
            f"{mean_sd([r['quality']['rmse'] for r in records])} | "
            f"{mean_sd([r['quality']['r2'] for r in records], 3)} | "
            f"{mean_sd([r['train_seconds'] for r in records])} | "
            f"{mean_sd([1000 * r['inference_seconds'] for r in records])} | "
            f"{mean_sd([r['peak_process_rss_mib'] for r in records], 1)} |"
        )
    lines += [
        "",
        "Validation RMSE is derived from the selected epoch's RP MSE and training standard deviation; "
        "no unrecorded validation MAE is invented. Per-seed best epochs, validation/test scores, source snapshots, "
        "timings, and record paths are in `full-per-seed.csv`; aggregates and train-mean baselines in `full-summary.json`.",
        "",
        "## Genuine ESM-C features: complete PTM-blind projection and strict native view",
        "",
        "ESM-C 300M (332,997,184 frozen parameters; pinned checkpoint/revision and hashes recorded per cohort) "
        "processes sequences locally on the GPU. Modified cohorts **retain all modification-aware targets** but "
        "use an explicit uppercase-residue projection (U→C): ESM does not represent PTM chemistry. Distinct PTM states "
        "can therefore have identical embeddings with different RT targets. Strict originally unmodified cohorts "
        "are separately reported, not silently substituted for the complete-data comparisons. Head CPU inference "
        "above excludes GPU feature extraction, model loading and the 1.33 GB base-model storage.",
        "Feature-stage timings include persistent embedding-cache lookups: originally unmodified views "
        "can reuse embeddings from the preceding full PTM-blind cohort, and pilot embeddings can also be reused. "
        "These are measured warm-cache workflow costs, not cold-cache GPU throughput; hit/miss timing was not "
        "separately instrumented. Genuine transformer training below uses live forward/backward, not this feature cache.",
        "",
        "| Cohort | Unique projected sequences | Model load s | Feature extraction s | Peak GPU MiB |",
        "|---|---:|---:|---:|---:|",
    ]
    for dataset in manifests:
        metadata = json.loads((RESULTS / dataset / "esm-features.json").read_text())
        lines.append(
            f"| {dataset} | {metadata['unique_sequences']} | {metadata['model_load_seconds']:.2f} | "
            f"{metadata['embedding_seconds']:.2f} | {metadata['peak_gpu_allocated_mib']:.1f} |"
        )
    lines += [
        "",
        "## Joint RP/hSAX/SCX and focal ablation on all available fraction-labeled cohorts",
        "",
        "RP standardized MSE + two categorical objectives, unit weights; focal γ=2 with no α reweighting. "
        "Fraction labels are observed, not RP-derived bins. Select the epoch by **joint validation objective**, "
        "then report all held-out dimensions. Focal and cross-entropy losses are not numerically comparable "
        "selection criteria. Macro recall averages supported test classes.",
        "",
        "| Cohort | Backend/optimizer/objective | RP RMSE s | hSAX accuracy | hSAX macro recall | SCX accuracy | SCX macro recall | Train s |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for key, records in sorted(groups.items()):
        dataset, backend, optimizer, loss = key
        if not loss.startswith("multitask"):
            continue
        columns = ["rmse", "hsax_accuracy", "hsax_macro_recall", "scx_accuracy", "scx_macro_recall"]
        cells = [
            mean_sd([r["quality"][column] for r in records], 2 if column == "rmse" else 3)
            for column in columns
        ]
        lines.append(
            f"| {dataset} | {backend}/{optimizer}/{loss} | "
            + " | ".join(cells)
            + f" | {mean_sd([r['train_seconds'] for r in records])} |"
        )
    lines += [
        "",
        "## Genuine transformer LoKr versus matched frozen backbone",
        "",
        "Unlike the earlier downstream-head LoKr ablation, these experiments attach trainable LoKr adapters "
        "to actual ESM-C transformer linear layers. Rank/factor/alpha 4, adapter LR 1e-4, head LR 1e-3, "
        "AdamW, six epochs, identical seeded regressor initialization and splits, bf16 GPU with float32 pooling/loss. "
        "Every full-cohort experiment has a fixed 540-second total budget with a training-only preflight; "
        "resource-blocked cases are not replaced with subsets. Modification-aware targets use the same explicit "
        "PTM-blind projection. The small trainable-only checkpoints exclude frozen base tensors.",
        "",
        "| Cohort | Status | Runs | Total s | Frozen test RMSE s | LoKr test RMSE s |",
        "|---|---|---:|---:|---:|---:|",
    ]
    for dataset in modified:
        destination = RESULTS / dataset / "transformer_lokr"
        manifest_path = destination / "manifest.json"
        if not manifest_path.exists():
            lines.append(f"| {dataset} | not executed | 0 | — | — | — |")
            continue
        experiment = json.loads(manifest_path.read_text())
        results = [json.loads(path.read_text()) for path in destination.glob("*-s[0-9]*.json")]
        summary["transformer_experiments"][dataset] = {
            "status": experiment["status"],
            "completed_runs": len(results),
            "total_seconds": experiment.get("total_seconds"),
            "preflight_estimated_seconds": experiment["conservative_preflight_total_seconds"],
            "budget_seconds": experiment["total_budget_seconds"],
            "results": results,
        }
        quality = {}
        for variant in ("frozen_backbone", "transformer_lokr"):
            records = [r for r in results if r["variant"] == variant and r["status"] == "ok"]
            quality[variant] = (
                mean_sd([r["test_quality_seconds"]["rmse"] for r in records]) if records else "—"
            )
        elapsed = f"{experiment['total_seconds']:.2f}" if "total_seconds" in experiment else "—"
        lines.append(
            f"| {dataset} | {experiment['status']} | {len(results)} | "
            f"{elapsed} | {quality['frozen_backbone']} | {quality['transformer_lokr']} |"
        )
    lines += [
        "",
        "The original six matched 1,000-pair transformer runs remain under `transformer_lokr/` "
        "(93.61 seconds total): a feasibility/gradient proof, not the full-data verdict. Six epochs can underfit; "
        "no convergence, universal LoKr quality advantage, or production latency claim follows.",
        "",
        "Completed full FA experiments train 961 regressor parameters for the frozen control versus "
        "463,681 parameters for genuine transformer LoKr (well below the 333M-parameter backbone). "
        "Saved checkpoints are about 11 KB and 1.06 MB respectively and contain only trainable tensors; "
        "`transformer_report.py` loads them with `weights_only=True` and independently checks tensor names/counts, "
        "hashes, matched initialization, nonzero adapter gradients/updates, and validation/test predictions. "
        "E. coli union, pLink, and E. coli linear transformer runs were blocked before supervised runs because "
        "their conservative six-run estimates exceeded the 540-second budget. Missing blocked-preflight elapsed "
        "times are shown as — rather than invented.",
        "",
        "## Limits and decision",
        "",
        "The full-data recurrent results, not the favorable small pilot, determine the quality/speed assessment. "
        "AdamW is an additional fixed optimizer, not a test-selected winner. Lion/Muon and standalone hSAX binary/"
        "categorical focal learning-rate sweeps remain **pilot-only exploratory ablations**; they do not establish "
        "full-cohort superiority. ESM trades a large backbone/GPU extraction cost and PTM blindness for reusable "
        "features. LoKr demonstrably trains backbone adapters with fewer trainable weights, but that alone proves "
        "neither faster inference nor better accuracy. No independent biological validation, untouched external "
        "study, cross-study transfer, per-acquisition calibration, deployment stress test, or uncertainty estimate "
        "over studies is established. Changing the configuration after inspecting held-out results would require "
        "new held-outs. Do not pool correlated source views into an artificial meta-study.",
        "",
    ]
    report = "\n".join(lines)
    write_json(RESULTS / "full-summary.json", summary)
    (RESULTS / "full-report.md").write_text(report)
    root_report = RESULTS / "report.md"
    previous = root_report.read_text()
    if MARKER in previous:
        previous = previous.split(MARKER, 1)[1].lstrip()
    root_report.write_text(report + "\n" + MARKER + "\n\n" + previous)
    print(f"Reported {len(per_seed)} full-cohort successful runs; {len(failures)} failures.")


if __name__ == "__main__":
    main()
