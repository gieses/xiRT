"""Bounded genuine ESM-C transformer adaptation versus matched frozen backbone."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import re
import resource
import statistics
import sys
import time
import traceback
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from benchmarks.run import OUT, ROOT, SEEDS, digest, load_data, metrics, write_json

os.environ.setdefault("HF_HOME", str(ROOT / "benchmarks/.cache/huggingface"))
os.environ.setdefault("XDG_CACHE_HOME", str(ROOT / "benchmarks/.cache"))
os.environ.setdefault("HF_HUB_OFFLINE", "1")
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("TMPDIR", str(ROOT / "benchmarks/.cache/runtime"))
sys.path.insert(0, str(ROOT))
DEST = OUT / "transformer_lokr"


class BudgetExceeded(RuntimeError):
    """The experiment stopped rather than claiming an unmatched partial comparison."""


def run(args: argparse.Namespace) -> None:
    """Execute paired backbone experiments with a preflight-enforced total budget.

    >>> callable(run)
    True
    """
    import csv
    import random

    import numpy as np
    import torch
    from torch import nn

    from xirt.adapters import LoKrLinear
    from xirt.embeddings import ESMCRetentionModel

    DEST.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    deadline = started + args.budget_seconds
    torch.set_num_threads(2)
    if not torch.cuda.is_available():
        raise RuntimeError("Real ESM-C transformer experiment requires the available CUDA GPU")
    source_hashes = {
        name: digest((ROOT / "xirt" / name).read_bytes())
        for name in ("embeddings.py", "adapters.py")
    }
    manifest, rows, _ = load_data()
    parent_manifest_hash = digest((OUT / "manifest.json").read_bytes())
    base_metadata = json.loads((OUT / "esm-features.json").read_text())
    # Check the actual downloaded pinned file once, without copying model tensors.
    for checkpoint in base_metadata["checkpoint_files"]:
        if "path" in checkpoint:
            path = ROOT / checkpoint["path"]
            with path.open("rb") as handle:
                assert hashlib.file_digest(handle, "sha256").hexdigest() == checkpoint["sha256"]
    train, val, test = (manifest["splits"][key] for key in ("train", "validation", "test"))
    raw_y = np.array([float(row["rp_seconds"]) for row in rows], dtype=np.float32)
    norm = manifest["target_normalization"]
    y = torch.tensor((raw_y - norm["mean"]) / norm["std"], device="cuda")[:, None]
    load_started = time.perf_counter()
    model = ESMCRetentionModel("esmc_300m", device="cuda", rank=4, factor=4, alpha=4.0)
    torch.cuda.synchronize()
    load_seconds = time.perf_counter() - load_started
    paired = manifest.get("siamese", True)
    sequences = [row["peptide_a"] for row in rows]
    if paired:
        sequences += [row["peptide_b"] for row in rows]
    if args.project_ptms:
        sequences = [
            "".join(re.findall("[A-Z]", sequence)).replace("U", "C") for sequence in sequences
        ]
    tokens, masks = model.tokenize(sequences)
    size = len(rows)
    adapters = [module for module in model.backbone.modules() if isinstance(module, LoKrLinear)]

    def synchronize() -> None:
        """Wait for GPU kernels before wall-clock measurements.

        >>> torch.cuda.synchronize()  # doctest: +SKIP
        """
        torch.cuda.synchronize()

    def guard() -> None:
        """Enforce the shared, fixed experiment deadline.

        >>> guard()  # doctest: +SKIP
        """
        if time.perf_counter() >= deadline:
            raise BudgetExceeded(f"Total experiment budget {args.budget_seconds}s reached")

    def reset(seed: int, variant: str) -> None:
        """Restore matched seeded regressor and zero-update adapter initialization.

        >>> reset(17, "frozen_backbone")  # doctest: +SKIP
        """
        random.seed(seed)
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        with torch.no_grad():
            for adapter in adapters:
                nn.init.kaiming_uniform_(adapter.lokr_w1, a=math.sqrt(5))
                nn.init.kaiming_uniform_(adapter.lokr_w2_a, a=math.sqrt(5))
                nn.init.zeros_(adapter.lokr_w2_b)
            model.regressor.reset_parameters()
        model.backbone.requires_grad_(False)
        if variant == "transformer_lokr":
            for name, parameter in model.backbone.named_parameters():
                if "lokr_" in name:
                    parameter.requires_grad_(True)
        model.regressor.requires_grad_(True)
        model.zero_grad(set_to_none=True)

    def predict_batch(indices: Any) -> torch.Tensor:
        """Predict single sequences or unordered pairs with exactly one head bias.

        >>> predict_batch(train[:64])  # doctest: +SKIP
        """
        idx = torch.as_tensor(indices, dtype=torch.long, device="cuda")
        combined = torch.cat((idx, idx + size)) if paired else idx
        with torch.autocast("cuda", dtype=torch.bfloat16):
            predicted = model(tokens[combined], masks[combined])
        # Sum pooled peptide representations through the SAME linear regressor,
        # with a single bias, rather than accidentally adding the bias twice.
        if not paired:
            return predicted.float()
        return predicted[: len(idx)].float() + predicted[len(idx) :].float() - model.regressor.bias

    def evaluate(indices: list[int]) -> np.ndarray:
        """Evaluate a fixed held-out split without gradient tracking.

        >>> evaluate(val)  # doctest: +SKIP
        """
        model.eval()
        predictions = []
        with torch.no_grad():
            for start in range(0, len(indices), args.batch_size):
                guard()
                predictions.append(predict_batch(indices[start : start + args.batch_size]).cpu())
        return torch.cat(predictions).numpy().ravel()

    def optimizer_for(variant: str) -> torch.optim.Optimizer:
        """Use fixed separate learning rates for the head and backbone adapters.

        >>> optimizer_for("transformer_lokr")  # doctest: +SKIP
        """
        groups = [{"params": list(model.regressor.parameters()), "lr": 1.0e-3}]
        if variant == "transformer_lokr":
            groups.insert(
                0,
                {
                    "params": [
                        parameter
                        for parameter in model.backbone.parameters()
                        if parameter.requires_grad
                    ],
                    "lr": 1.0e-4,
                },
            )
        return torch.optim.AdamW(groups, weight_decay=0.01)

    # Only training examples are used for a forward/backward feasibility preflight.
    preflight = {}
    for variant in ("frozen_backbone", "transformer_lokr"):
        reset(SEEDS[0], variant)
        optimizer = optimizer_for(variant)
        samples = []
        for step in range(4):
            synchronize()
            begin = time.perf_counter()
            optimizer.zero_grad(set_to_none=True)
            prediction = predict_batch(train[: args.batch_size])
            loss = nn.functional.mse_loss(prediction, y[train[: args.batch_size]])
            loss.backward()
            nn.utils.clip_grad_norm_([p for p in model.parameters() if p.requires_grad], 1.0)
            optimizer.step()
            synchronize()
            if step:
                samples.append(time.perf_counter() - begin)
        preflight[variant] = statistics.median(samples)
        del prediction, loss, optimizer
    steps = math.ceil(len(train) / args.batch_size)
    estimated_seconds = sum(preflight.values()) * steps * args.epochs * len(SEEDS) * 1.25
    experiment = {
        "schema_version": 1,
        "status": "running",
        "parent_manifest_sha256": parent_manifest_hash,
        "pairs_sha256": manifest["pairs_sha256"],
        "splits": manifest["splits"],
        "seeds": SEEDS,
        "epochs": args.epochs,
        "batch_size_pairs": args.batch_size,
        "model": "esmc_300m",
        "embedding_dim": 960,
        "rank": 4,
        "factor": 4,
        "alpha": 4.0,
        "adapter_targets": list(model.adapter_targets),
        "framework_version": torch.__version__,
        "device": torch.cuda.get_device_name(),
        "precision": "CUDA bfloat16 autocast; pooling/loss/targets float32",
        "regressor_lr": 0.001,
        "backbone_adapter_lr": 0.0001,
        "weight_decay": 0.01,
        "gradient_clip_norm": 1.0,
        "selection": "minimum validation standardized RP MSE; no test selection",
        "pair_forward": "model(first tokens)+model(second tokens)-regressor.bias",
        "siamese": paired,
        "ptm_blind_projection": args.project_ptms,
        "projection_rule": "uppercase residues in original order; U->C"
        if args.project_ptms
        else "none",
        "normalization": norm,
        "source_sha256": source_hashes,
        "pretrained_checkpoint": base_metadata["checkpoint_files"],
        "model_load_seconds": load_seconds,
        "preflight_elapsed_seconds": time.perf_counter() - started,
        "preflight_seconds_per_step": preflight,
        "conservative_preflight_total_seconds": estimated_seconds,
        "total_budget_seconds": args.budget_seconds,
        "original_84_runs": "unchanged; this separate matched experiment uses a six-epoch budget",
        "initial_gpu_memory_note": "Shared host; no parent GPU benchmark overlap requested",
    }
    write_json(DEST / "manifest.json", experiment)
    print("PREFLIGHT", json.dumps(preflight), "estimated", estimated_seconds, flush=True)
    if estimated_seconds > deadline - time.perf_counter():
        experiment.update(
            status="resource_blocked",
            error="Preflight estimates exceed total fixed budget",
            total_seconds=time.perf_counter() - started,
        )
        write_json(DEST / "manifest.json", experiment)
        return
    completed = 0
    for seed in SEEDS:
        for variant in ("frozen_backbone", "transformer_lokr"):
            guard()
            reset(seed, variant)
            initial_regressor = digest(
                model.regressor.weight.detach().cpu().numpy().tobytes()
                + model.regressor.bias.detach().cpu().numpy().tobytes()
            )
            optimizer = optimizer_for(variant)
            trainable = {
                name: parameter
                for name, parameter in model.named_parameters()
                if parameter.requires_grad
            }
            generator = torch.Generator().manual_seed(seed + 1000)
            best, best_epoch, state = float("inf"), 0, None
            history = []
            first_adapter_gradient = None
            torch.cuda.reset_peak_memory_stats()
            synchronize()
            begin = time.perf_counter()
            for epoch in range(args.epochs):
                model.train()
                train_sum = 0.0
                for batch in torch.tensor(train)[
                    torch.randperm(len(train), generator=generator)
                ].split(args.batch_size):
                    guard()
                    optimizer.zero_grad(set_to_none=True)
                    prediction = predict_batch(batch)
                    loss = nn.functional.mse_loss(prediction, y[batch.to("cuda")])
                    if not torch.isfinite(loss):
                        raise FloatingPointError("Nonfinite RP training loss")
                    loss.backward()
                    if first_adapter_gradient is None and variant == "transformer_lokr":
                        gradients = [
                            p.grad.float().square().sum()
                            for name, p in trainable.items()
                            if "lokr_" in name and p.grad is not None
                        ]
                        first_adapter_gradient = float(torch.stack(gradients).sum().sqrt())
                        if first_adapter_gradient == 0:
                            raise RuntimeError(
                                "Real transformer adapters have zero training gradient"
                            )
                    nn.utils.clip_grad_norm_(list(trainable.values()), 1.0, error_if_nonfinite=True)
                    optimizer.step()
                    train_sum += float(loss.detach()) * len(batch)
                validation_prediction = evaluate(val)
                val_loss = float(
                    np.mean(
                        (validation_prediction - (raw_y[val] - norm["mean"]) / norm["std"]) ** 2
                    )
                )
                history.append(
                    {"epoch": epoch + 1, "train_loss": train_sum / len(train), "val_loss": val_loss}
                )
                if val_loss < best:
                    best, best_epoch = val_loss, epoch + 1
                    state = {
                        name: parameter.detach().cpu().clone()
                        for name, parameter in trainable.items()
                    }
                print(seed, variant, epoch + 1, f"val={val_loss:.5f}", flush=True)
            synchronize()
            train_seconds = time.perf_counter() - begin
            with torch.no_grad():
                for name, parameter in model.named_parameters():
                    if name in state:
                        parameter.copy_(state[name])
            validation_prediction = evaluate(val) * norm["std"] + norm["mean"]
            evaluate(test)
            timings = []
            for _ in range(3):
                synchronize()
                infer_begin = time.perf_counter()
                test_prediction = evaluate(test) * norm["std"] + norm["mean"]
                synchronize()
                timings.append(time.perf_counter() - infer_begin)
            nonzero_adapter_entries = sum(
                int(torch.count_nonzero(adapter.lokr_w2_b)) for adapter in adapters
            )
            result = {
                "status": "ok",
                "seed": seed,
                "variant": variant,
                "epochs": args.epochs,
                "history": history,
                "best_epoch": best_epoch,
                "validation_loss": best,
                "validation_quality_seconds": metrics(raw_y[val], validation_prediction),
                "test_quality_seconds": metrics(raw_y[test], test_prediction),
                "train_seconds": train_seconds,
                "inference_seconds": statistics.median(timings),
                "trainable_parameters": sum(p.numel() for p in trainable.values()),
                "total_parameters": sum(p.numel() for p in model.parameters()),
                "peak_gpu_allocated_mib": torch.cuda.max_memory_allocated() / 2**20,
                "peak_gpu_reserved_mib": torch.cuda.max_memory_reserved() / 2**20,
                "peak_process_rss_mib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024,
                "first_adapter_gradient_l2": first_adapter_gradient,
                "nonzero_adapter_w2_b_entries": nonzero_adapter_entries,
                "initial_regressor_sha256": initial_regressor,
                "manifest_sha256": digest((DEST / "manifest.json").read_bytes()),
                "source_sha256": source_hashes,
                "checkpoint": f"{variant}-s{seed}.pt",
            }
            if variant == "frozen_backbone":
                assert nonzero_adapter_entries == 0
            checkpoint_path = DEST / result["checkpoint"]
            torch.save(
                {
                    "trainable_state": state,
                    "seed": seed,
                    "variant": variant,
                    "best_epoch": best_epoch,
                    "adapter_config": {"rank": 4, "factor": 4, "alpha": 4.0},
                    "adapter_targets": list(model.adapter_targets),
                    "pretrained_checkpoint": base_metadata["checkpoint_files"],
                },
                checkpoint_path,
            )
            result["checkpoint_bytes"] = checkpoint_path.stat().st_size
            result["checkpoint_sha256"] = digest(checkpoint_path.read_bytes())
            write_json(DEST / f"{variant}-s{seed}.json", result)
            with (DEST / f"{variant}-s{seed}-predictions.csv").open("w") as handle:
                writer = csv.writer(handle)
                writer.writerow(["split", "pair_index", "truth_seconds", "prediction_seconds"])
                for split, indices, prediction in (
                    ("validation", val, validation_prediction),
                    ("test", test, test_prediction),
                ):
                    writer.writerows(
                        (split, index, float(raw_y[index]), float(value))
                        for index, value in zip(indices, prediction)
                    )
            completed += 1
            print(
                "DONE",
                seed,
                variant,
                json.dumps(result["test_quality_seconds"]),
                "train_seconds",
                train_seconds,
                flush=True,
            )
            del optimizer, state
    assert source_hashes == {
        name: digest((ROOT / "xirt" / name).read_bytes()) for name in source_hashes
    }
    experiment.update(
        status="ok", completed_runs=completed, total_seconds=time.perf_counter() - started
    )
    write_json(DEST / "manifest.json", experiment)
    manifest_checksum = digest((DEST / "manifest.json").read_bytes())
    for path in DEST.glob("*-s[0-9]*.json"):
        result = json.loads(path.read_text())
        result["manifest_sha256"] = manifest_checksum
        write_json(path, result)


def main() -> None:
    """Parse the bounded transformer experiment command.

    >>> callable(main)
    True
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--epochs", type=int, default=6)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--budget-seconds", type=int, default=540)
    parser.add_argument("--project-ptms", action="store_true")
    args = parser.parse_args()
    try:
        run(args)
    except Exception as exc:
        DEST.mkdir(parents=True, exist_ok=True)
        manifest_path = DEST / "manifest.json"
        if manifest_path.exists():
            experiment = json.loads(manifest_path.read_text())
            experiment.update(status="failed", error=f"{type(exc).__name__}: {exc}")
            write_json(manifest_path, experiment)
        write_json(
            DEST / "failure.json",
            {
                "status": "failed",
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(),
            },
        )
        raise


if __name__ == "__main__":
    main()
