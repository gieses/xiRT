"""Execute full-data experiments with isolated source snapshots and bounded workers."""

from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from benchmarks.run import ROOT, SEEDS, snapshot_package, write_json


def main() -> None:
    """Launch matched full-cohort jobs without changing their saved splits.

    >>> callable(main)
    True
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--datasets", nargs="+", default=["full_ecoli_modified", "full_ecoli_canonical"]
    )
    parser.add_argument("--workers", type=int, default=6)
    parser.add_argument(
        "--experiments",
        action="store_true",
        help="Also run Lion/Muon and true hSAX focal ablations",
    )
    parser.add_argument("--esm-only", action="store_true")
    parser.add_argument("--multitask-only", action="store_true")
    parser.add_argument("--focal-multitask", action="store_true")
    parser.add_argument("--rerun", action="store_true")
    args = parser.parse_args()
    jobs = []
    for dataset in args.datasets:
        destination = ROOT / "benchmarks/results" / dataset
        manifest = json.loads((destination / "manifest.json").read_text())
        index_path = destination / "new-source-index.json"
        if index_path.exists():
            index = json.loads(index_path.read_text())
            snapshot = ROOT / index["snapshot_path"]
            checksum = index["snapshot_sha256"]
        else:
            snapshot, checksum = snapshot_package(destination)
        for seed in SEEDS:
            if args.esm_only:
                jobs.append(
                    (
                        destination,
                        snapshot,
                        checksum,
                        "torch-esm",
                        seed,
                        "adamw",
                        0.003,
                        "multitask" if args.multitask_only else "mse",
                    )
                )
                continue
            for backend, optimizer in (("legacy", "adam"), ("torch", "adam"), ("torch", "adamw")):
                jobs.append(
                    (
                        destination,
                        snapshot,
                        checksum,
                        backend,
                        seed,
                        optimizer,
                        0.003,
                        "multitask" if args.multitask_only else "mse",
                    )
                )
            if args.focal_multitask:
                jobs.append(
                    (
                        destination,
                        snapshot,
                        checksum,
                        "torch",
                        seed,
                        "adamw",
                        0.003,
                        "multitask_focal",
                    )
                )
            if args.experiments:
                for optimizer, lr in (("lion", 0.0003), ("muon", 0.003)):
                    jobs.append(
                        (destination, snapshot, checksum, "torch", seed, optimizer, lr, "mse")
                    )
                if manifest.get("fraction_labels_available", True):
                    jobs += [
                        (destination, snapshot, checksum, "torch", seed, "adamw", 0.003, loss)
                        for loss in (
                            "binary_crossentropy",
                            "binary_focal",
                            "categorical_crossentropy",
                            "categorical_focal",
                        )
                    ]
    available_cpus = sorted(os.sched_getaffinity(0))
    runtime = ROOT / "benchmarks/.cache/runtime"
    runtime.mkdir(parents=True, exist_ok=True)

    def execute(job: tuple[Path, Path, str, str, int, str, float, str]) -> str:
        """Run one isolated candidate and retain explicit failures or timeouts.

        >>> execute(job)  # doctest: +SKIP
        """
        destination, snapshot, checksum, backend, seed, optimizer, lr, loss = job
        name = f"{backend}-{optimizer}-{lr:g}-{loss}-s{seed}"
        result_path = destination / f"{name}.json"
        if result_path.exists() and not args.rerun:
            return f"SKIP {destination.name}/{name}"
        python = ROOT / (
            "benchmarks/.venv-legacy/bin/python" if backend == "legacy" else ".venv/bin/python"
        )
        environment = os.environ.copy()
        environment.update(
            {
                "XIRT_BENCHMARK_RESULTS_DIR": str(destination),
                "XIRT_BENCHMARK_PACKAGE_ROOT": str(snapshot),
                "XIRT_BENCHMARK_SNAPSHOT": checksum,
                "CUDA_VISIBLE_DEVICES": "",
                "OMP_NUM_THREADS": "2",
                "MKL_NUM_THREADS": "2",
                "OPENBLAS_NUM_THREADS": "2",
                "TF_USE_LEGACY_KERAS": "1",
                "TF_CPP_MIN_LOG_LEVEL": "2",
                "TMPDIR": str(runtime),
            }
        )
        command = [
            str(python),
            str(ROOT / "benchmarks/run.py"),
            "worker",
            "--backend",
            backend,
            "--seed",
            str(seed),
            "--optimizer",
            optimizer,
            "--lr",
            str(lr),
            "--loss",
            loss,
            "--name",
            name,
        ]
        logs = destination / "logs"
        logs.mkdir(exist_ok=True)
        start = time.perf_counter()
        try:
            completed = subprocess.run(
                command, cwd=ROOT, env=environment, text=True, capture_output=True, timeout=570
            )
            (logs / f"{name}.txt").write_text(completed.stdout + "\n" + completed.stderr)
            if completed.returncode:
                write_json(
                    result_path,
                    {
                        "status": "failed",
                        "backend": backend,
                        "seed": seed,
                        "optimizer": optimizer,
                        "lr": lr,
                        "loss": loss,
                        "error": completed.stderr[-6000:],
                    },
                )
            return f"{destination.name}/{name}: exit={completed.returncode}, {time.perf_counter() - start:.2f}s"
        except subprocess.TimeoutExpired:
            write_json(
                result_path,
                {
                    "status": "timeout",
                    "backend": backend,
                    "seed": seed,
                    "optimizer": optimizer,
                    "lr": lr,
                    "loss": loss,
                    "seconds": 570,
                },
            )
            return f"{destination.name}/{name}: timeout570s"

    # CPU work only; all transformer/GPU timing remains in the separate live runner.
    print(
        f"Running {len(jobs)} full-data jobs, max {args.workers} subprocesses, "
        f"{len(available_cpus)} available CPUs; two framework threads/job",
        flush=True,
    )
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as pool:
        for result in pool.map(execute, jobs):
            print(result, flush=True)


if __name__ == "__main__":
    main()
