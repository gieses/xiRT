"""Validate durable benchmark provenance and independently recalculate RP scores."""

from __future__ import annotations

import csv
import json
import re
import statistics
import sys
from pathlib import Path
from typing import Any

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from benchmarks.run import OUT, ROOT, SEEDS, digest, load_data, metrics


def validate_full_sources(
    manifest: dict[str, Any], rows: list[dict[str, str]], observations: list[dict[str, str]]
) -> None:
    """Check every normalized observation against hashed raw files and unit factors.

    >>> callable(validate_full_sources)
    True
    """
    sources: dict[str, tuple[dict[str, Any], list[dict[str, str]]]] = {}
    for specification in manifest["actual_source_files"]:
        path = ROOT / specification["path"]
        assert digest(path.read_bytes()) == specification["sha256"]
        with path.open() as handle:
            raw = list(csv.DictReader(handle))
        assert len(raw) == specification["total_rows"]
        sources[specification["path"]] = specification, raw
    identities: set[tuple[str, str]] = set()
    for observation in observations:
        specification, original = sources[observation["source_file"]]
        raw = original[int(observation["source_row"])]
        assert raw["isTT"].lower() == "true" and float(raw["fdr"].replace(",", "")) <= 0.01
        value = float(raw[specification["rp_column"]].replace(",", ""))
        assert np.isclose(float(observation["rp"]), value * specification["rp_to_seconds_factor"])
        for normalized, column in (
            ("Peptide1", specification["peptide_a_column"]),
            ("Peptide2", specification["peptide_b_column"]),
        ):
            sequence = raw[column] if column else ""
            sequence = sequence.split(".")[1] if "." in sequence else sequence
            assert observation[normalized] == sequence
        for task in ("hsax", "scx"):
            assert observation[task] == raw.get(task, "")
        identity = observation["Run"], observation["PSMID"]
        assert identity not in identities
        identities.add(identity)
    assert len(observations) == manifest["confidence_eligible_rows"]
    for row in rows:
        sequences = (
            [row["peptide_a"], row["peptide_b"]] if manifest["siamese"] else [row["peptide_a"]]
        )
        group = sorted("".join(re.findall("[A-Z]", sequence)) for sequence in sequences)
        assert json.loads(row["group_key"]) == group
        if manifest["canonical_only"]:
            assert set("".join(sequences)) <= set("ACDEFGHIKLMNPQRSTVWY")
    if manifest["pilot_groups_reserved_for_training"]:
        with (ROOT / "benchmarks/results/pairs.csv").open() as handle:
            pilot = list(csv.DictReader(handle))
        inspected = {
            tuple(
                sorted("".join(re.findall("[A-Z]", r[key])) for key in ("peptide_a", "peptide_b"))
            )
            for r in pilot
        }
        held_out = manifest["splits"]["validation"] + manifest["splits"]["test"]
        assert all(
            tuple(json.loads(rows[index]["group_key"])) not in inspected for index in held_out
        )
    metadata_path = OUT / "esm-features.json"
    if metadata_path.exists():
        metadata = json.loads(metadata_path.read_text())
        assert metadata["status"] == "ok"
        assert metadata["pairs_sha256"] == manifest["pairs_sha256"]
        assert digest((OUT / "esm-features.npz").read_bytes()) == metadata["features_sha256"]
        assert metadata["ptm_blind_projection"] == (not manifest["canonical_only"])


def main() -> None:
    """Independently verify all recorded runs in the selected benchmark directory.

    >>> callable(main)
    True
    """
    manifest, rows, _ = load_data()
    splits = manifest["splits"]
    sets = [set(splits[key]) for key in ("train", "validation", "test")]
    assert sum(map(len, sets)) == len(rows)
    assert set.union(*sets) == set(range(len(rows)))
    assert not (sets[0] & sets[1] or sets[0] & sets[2] or sets[1] & sets[2])
    pairs = [tuple(sorted((r["peptide_a"], r["peptide_b"]))) for r in rows]
    assert len(pairs) == len(set(pairs))
    source = ROOT / manifest["source"]
    assert digest(source.read_bytes()) == manifest["source_sha256"]
    with source.open() as handle:
        original = list(csv.DictReader(handle))
    if manifest.get("actual_source_files"):
        validate_full_sources(manifest, rows, original)
    for pair, row in zip(pairs, rows):
        records = [original[int(index)] for index in row["source_rows"].split(";")]
        assert all(tuple(sorted((r["Peptide1"], r["Peptide2"]))) == pair for r in records)
        assert all(r["isTT"] == "True" and float(r["fdr"]) <= 0.01 for r in records)
        assert np.isclose(
            float(row["rp_seconds"]), statistics.mean(float(r["rp"]) for r in records)
        )
        if manifest.get("fraction_labels_available", True):
            assert int(row["hsax"]) == statistics.mode(int(float(r["hsax"])) for r in records)
            if "scx" in row:
                assert int(row["scx"]) == statistics.mode(int(float(r["scx"])) for r in records)
    targets = np.array([float(r["rp_seconds"]) for r in rows], dtype=np.float64)
    assert np.isclose(targets[splits["train"]].mean(), manifest["target_normalization"]["mean"])
    assert np.isclose(targets[splits["train"]].std(), manifest["target_normalization"]["std"])
    count, failures = 0, 0
    snapshots = set()
    for path in sorted(OUT.glob("*-s[0-9]*.json")):
        result = json.loads(path.read_text())
        assert result["seed"] in SEEDS
        if result["status"] != "ok":
            failures += 1
            continue
        if result["backend"] in ("torch", "torch-esm"):
            assert result.get("snapshot_sha256"), (
                "New-network jobs must use an immutable recorded source snapshot"
            )
            snapshots.add(result["snapshot_sha256"])
        if manifest.get("early_stopping_patience"):
            assert 1 <= len(result["history"]) <= manifest["epochs"] and manifest["epochs"] >= 30
        else:
            assert len(result["history"]) >= 10
        minimum = min(result["history"], key=lambda r: r["val_loss"])
        assert minimum["epoch"] == result["best_epoch"]
        assert np.isclose(minimum["val_loss"], result["validation_loss"])
        predictions = list(csv.DictReader(path.with_name(path.stem + "-predictions.csv").open()))
        assert [int(r["pair_index"]) for r in predictions] == splits["test"]
        if result["loss"] in ("mse", "multitask", "multitask_focal"):
            truth_key, prediction_key = (
                ("truth", "prediction")
                if "truth" in predictions[0]
                else ("truth_seconds", "prediction_seconds")
            )
            truth = np.array([float(r[truth_key]) for r in predictions])
            predicted = np.array([float(r[prediction_key]) for r in predictions])
            assert np.allclose(truth, targets[splits["test"]])
            scores = metrics(truth, predicted)
            for key, value in scores.items():
                assert np.isclose(value, result["quality"][key], rtol=1e-5, atol=1e-5), (path, key)
            if result["loss"].startswith("multitask"):
                for task in ("hsax", "scx"):
                    truth = np.array([int(row[f"{task}_truth"]) for row in predictions])
                    levels = manifest["fraction_levels"][task]
                    assert np.array_equal(
                        truth, [levels.index(int(rows[i][task])) for i in splits["test"]]
                    )
                    probabilities = np.array(
                        [json.loads(row[f"{task}_probabilities"]) for row in predictions]
                    )
                    labels = probabilities.argmax(1)
                    assert np.isclose(
                        float((labels == truth).mean()), result["quality"][f"{task}_accuracy"]
                    )
                    macro = float(
                        np.mean([np.mean(labels[truth == c] == c) for c in np.unique(truth)])
                    )
                    assert np.isclose(macro, result["quality"][f"{task}_macro_recall"])
        else:
            truth = np.array([int(float(r["truth"])) for r in predictions])
            expected = np.array([int(rows[i]["hsax"]) - 1 for i in splits["test"]])
            if result["loss"].startswith("binary"):
                expected = (expected >= 5).astype(int)
            assert np.array_equal(truth, expected)
            probabilities = np.array([json.loads(r["prediction"]) for r in predictions])
            labels = (
                probabilities.argmax(1)
                if result["loss"].startswith("categorical")
                else (probabilities.ravel() >= 0.5).astype(int)
            )
            accuracy = float((truth == labels).mean())
            macro = float(np.mean([np.mean(labels[truth == c] == c) for c in np.unique(truth)]))
            assert np.isclose(accuracy, result["quality"]["accuracy"])
            assert np.isclose(macro, result["quality"]["macro_recall"])
        count += 1
    assert len(snapshots) <= 1, "A comparative suite must not mix new source snapshots across seeds"
    if snapshots:
        index = json.loads((OUT / "new-source-index.json").read_text())
        assert snapshots == {index["snapshot_sha256"]}
        source_root = ROOT / index["snapshot_path"]
        if not source_root.exists():
            source_root = ROOT
        for name, checksum in index["files"].items():
            assert digest((source_root / "xirt" / name).read_bytes()) == checksum
    if manifest.get("split_group"):
        groups = [{rows[i]["group_key"] for i in indices} for indices in splits.values()]
        assert not (groups[0] & groups[1] or groups[0] & groups[2] or groups[1] & groups[2])
    print(
        f"Validated real-data/held-out provenance and metrics for {count} completed runs; {failures} recorded failures."
    )


if __name__ == "__main__":
    main()
