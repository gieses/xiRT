"""Snakemake entry points; orchestration stays outside the installed xiRT package."""

from __future__ import annotations

import argparse
import gzip
import importlib.metadata
import json
import os
import shutil
import subprocess
import sys
import tarfile
import traceback
import urllib.request
import zipfile
from pathlib import Path
from typing import Any

SOURCE_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(SOURCE_ROOT))
ROOT = Path(os.environ.get("XIRT_BENCHMARK_REPO_ROOT", SOURCE_ROOT)).resolve()

from benchmarks.run import LEGACY  # noqa: E402
from benchmarks.workflow.protocol import (  # noqa: E402
    DATA_SOURCES,
    file_hash,
    identity,
    validate_config,
    write_json,
)


def source_inputs() -> list[Path]:
    """List only code/config/lock assets actually used by this workflow."""
    paths = list((SOURCE_ROOT / "xirt").glob("*.py"))
    for directory in ("workflow", "reference"):
        paths.extend((SOURCE_ROOT / "benchmarks" / directory).rglob("*.py"))
    paths += [SOURCE_ROOT / "benchmarks" / name for name in ("run.py", "full_prepare.py", "sources.py")]
    paths += list((SOURCE_ROOT / "benchmarks/workflow/envs").glob("*.lock.txt"))
    paths += list((SOURCE_ROOT / "benchmarks/workflow").rglob("*.yaml"))
    paths += [SOURCE_ROOT / "benchmarks/results" / name for name in (
        "source-coverage.json", "sources-inventory.json", "paper-source-inventory.json", "pairs.csv",
    )]
    paths += [SOURCE_ROOT / name for name in (
        "benchmarks/workflow/Snakefile", "pyproject.toml", "uv.lock", "run.sh",
    )]
    return sorted(set(paths))


def check_existing_run(run_dir: Path, config: dict[str, Any]) -> None:
    """Reject incompatible restarts before Snakemake can clean up snapshot outputs."""
    if (run_dir / "provenance.json").exists():
        previous = provenance(run_dir)
        source_hashes = {
            str(path.relative_to(SOURCE_ROOT)): file_hash(path) for path in source_inputs()
        }
        if (
            previous["protocol_sha256"] != identity(config)
            or previous["source_snapshot_sha256"] != identity(source_hashes)
        ):
            raise ValueError(
                "Measured run is immutable and the working code/configuration changed. "
                f"Resume its frozen workflow with: bash run.sh resume {run_dir}. "
                "Choose a new run_dir to use changed code/configuration."
            )
    elif run_dir.exists() and any(run_dir.iterdir()):
        raise ValueError(
            f"Nonempty run directory has no provenance: {run_dir}. "
            "Restore its original snapshot before resuming; do not overwrite measured results."
        )


def snapshot(run_dir: Path, config: dict[str, Any]) -> None:
    """Freeze source, resolved config and interpreter/lock identity before any training."""
    config = validate_config(config, ROOT)
    source_hashes = {str(path.relative_to(SOURCE_ROOT)): file_hash(path) for path in source_inputs()}
    protocol_hash = identity(config)
    existing = run_dir / "provenance.json"
    if existing.exists():
        previous = json.loads(existing.read_text())
        if (
            previous["protocol_sha256"] != protocol_hash
            or previous["source_snapshot_sha256"] != identity(source_hashes)
        ):
            raise ValueError("Measured run is immutable: choose a new run_dir after code/config changes")
        if not (run_dir / "source").exists():
            if file_hash(run_dir / "source.tar.gz") != previous["source_archive_sha256"]:
                raise ValueError("Cannot restore a modified source archive")
            with tarfile.open(run_dir / "source.tar.gz") as archive:
                archive.extractall(run_dir / "source", filter="data")
        write_json(run_dir / "config.json", config)
        return
    if run_dir.exists() and any(run_dir.iterdir()):
        raise ValueError("Refusing to overwrite a nonempty run directory without provenance")
    environments = {}
    for label, key in (("modern", "modern_python"), ("legacy", "legacy_python")):
        interpreter = (ROOT / config[key]).resolve()
        payload = subprocess.check_output([
            str(interpreter), "-c",
            "import importlib.metadata as m,json,platform;"
            "print(json.dumps({'python':platform.python_version(),"
            "'packages':{d.metadata['Name']:d.version for d in m.distributions()}}))",
        ], text=True)
        environments[label] = json.loads(payload)
    source = subprocess.check_output(["git", "show", f"{LEGACY}:xirt/xirtnet.py"], cwd=ROOT)
    run_dir.mkdir(parents=True, exist_ok=True)
    destination = run_dir / "source"
    for path in source_inputs():
        target = destination / path.relative_to(SOURCE_ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
    archive = run_dir / "source.tar.gz"
    with archive.open("wb") as stream, gzip.GzipFile(fileobj=stream, mode="wb", mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode="w") as bundle:
            for path in sorted(destination.rglob("*")):
                if path.is_file():
                    info = bundle.gettarinfo(str(path), arcname=str(path.relative_to(destination)))
                    info.mtime, info.uid, info.gid, info.uname, info.gname = 0, 0, 0, "", ""
                    info.mode = 0o644
                    with path.open("rb") as handle:
                        bundle.addfile(info, handle)
    import hashlib
    import platform

    write_json(existing, {
        "schema_version": 1, "config": config, "protocol_sha256": protocol_hash,
        "source_snapshot_sha256": identity(source_hashes), "source_files": source_hashes,
        "source_archive_sha256": file_hash(archive), "legacy_commit": LEGACY,
        "legacy_source_sha256": hashlib.sha256(source).hexdigest(),
        "legacy_status": "deprecated benchmark reference; not shipped as application code",
        "environments": environments, "platform": platform.platform(),
        "scheduler_version": "9.27.0", "scope": "smoke_subset" if config["max_groups"] else "full_cohort",
        "environment_manager": subprocess.check_output(["uv", "--version"], text=True).strip(),
        "selection": "mean validation objective over prespecified tuning seeds; no test access",
        "test_status": "New grouped splits of previously studied data, not an untouched external study",
    })
    write_json(run_dir / "config.json", config)


def provenance(run_dir: Path) -> dict[str, Any]:
    """Check frozen code/locks, rather than silently running a moving implementation."""
    result = json.loads((run_dir / "provenance.json").read_text())
    if identity(result["config"]) != result["protocol_sha256"]:
        raise ValueError("Resolved protocol was modified")
    for name, expected in result["source_files"].items():
        if file_hash(run_dir / "source" / name) != expected:
            raise ValueError(f"Frozen workflow source changed: {name}")
    return result


def acquire(name: str, config: dict[str, Any]) -> None:
    """Retrieve one pinned source member, atomically checking its published local SHA256."""
    census = json.loads((SOURCE_ROOT / "benchmarks/results/source-coverage.json").read_text())
    item = next(source for source in census["sources"] if source["path"] == name)
    destination = ROOT / name
    if destination.exists():
        if file_hash(destination) != item["sha256"]:
            raise ValueError(f"Source checksum mismatch: {name}")
        return
    if not config["allow_downloads"]:
        raise FileNotFoundError(f"Missing source {name}; set allow_downloads=true to retrieve it")
    destination.parent.mkdir(parents=True, exist_ok=True)
    pending = destination.with_suffix(".pending")
    try:
        if item["archive"]:
            from benchmarks.sources import RangeReader

            inventory = json.loads((SOURCE_ROOT / "benchmarks/results/sources-inventory.json").read_text())
            archive = next(file for file in inventory["files"] if file["name"] == item["archive"])
            with zipfile.ZipFile(RangeReader(archive["url"], archive["size"])) as stream:
                with stream.open(item["member"]) as member, pending.open("wb") as target:
                    shutil.copyfileobj(member, target)
        elif name.endswith("FigS2_source_cde_part2.csv"):
            archive = ROOT / "benchmarks/.cache/sources/paper/source-data.zip"
            if not archive.exists():
                url = (
                    "https://media.springernature.com/full/springer-static/esm/art%3A10.1038%2F"
                    "s41467-021-23441-0/MediaObjects/41467_2021_23441_MOESM4_ESM.zip"
                )
                download = archive.with_suffix(".pending")
                try:
                    with urllib.request.urlopen(url, timeout=120) as response, download.open("wb") as target:
                        shutil.copyfileobj(response, target)
                    if file_hash(download) != census["publisher_source_archive_sha256"]:
                        raise ValueError("Publisher source ZIP checksum mismatch")
                    download.replace(archive)
                finally:
                    download.unlink(missing_ok=True)
            if file_hash(archive) != census["publisher_source_archive_sha256"]:
                raise ValueError("Publisher source ZIP checksum mismatch")
            with zipfile.ZipFile(archive) as stream:
                member = next(n for n in stream.namelist() if n.endswith("/FigS2_source_cde_part2.csv"))
                with stream.open(member) as source, pending.open("wb") as target:
                    shutil.copyfileobj(source, target)
        else:
            raise FileNotFoundError(f"Repository fixture must be restored from git: {name}")
        if file_hash(pending) != item["sha256"]:
            raise ValueError(f"Downloaded source checksum mismatch: {name}")
        pending.replace(destination)
    finally:
        pending.unlink(missing_ok=True)


def esm_assets(run_dir: Path, config: dict[str, Any]) -> None:
    """Pin an exact public repository revision and weight digest, never SDK 'main'."""
    spec = config["esm"]
    cache = ROOT / "benchmarks/.cache/huggingface/hub"
    path = cache / f"models--{spec['repository'].replace('/', '--')}" / "blobs" / spec["checkpoint_sha256"]
    if not path.exists():
        if not config["allow_downloads"]:
            raise FileNotFoundError("Pinned ESM weights missing; enable allow_downloads after accepting "
                                    "the model's separate access/license conditions")
        from huggingface_hub import hf_hub_download

        path = Path(hf_hub_download(
            spec["repository"], spec["filename"], revision=spec["revision"], cache_dir=cache,
        )).resolve()
    if file_hash(path) != spec["checkpoint_sha256"]:
        raise ValueError("ESM-C pretrained checkpoint digest differs from the prespecified protocol")
    write_json(run_dir / "esm-assets.json", {
        **spec, "path": str(path.relative_to(ROOT)), "size_bytes": path.stat().st_size,
    })


def prepare(run_dir: Path, record: dict[str, Any], dataset: str) -> None:
    """Reuse real aggregation, then reserve grouped pretraining validation inside training only."""
    import random

    config = record["config"]
    for name in DATA_SOURCES[dataset]:
        acquire(name, config)
    command = [
        sys.executable, str(SOURCE_ROOT / "benchmarks/full_prepare.py"),
        "--only", dataset.removesuffix("_modified"), "--views", "modified",
        "--output-root", str(run_dir / "data"), "--split-seed", str(config["split_seed"]),
        "--max-groups", str(config["max_groups"]),
        "--pilot-manifest", str(SOURCE_ROOT / "benchmarks/results/pairs.csv"),
    ]
    subprocess.run(command, check=True, cwd=ROOT)
    import csv

    directory = run_dir / "data" / dataset
    manifest_path = directory / "manifest.json"
    manifest = json.loads(manifest_path.read_text())
    with (directory / "pairs.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    train = manifest["splits"]["train"]
    groups = sorted({rows[index]["group_key"] for index in train})
    random.Random(config["split_seed"] + 1).shuffle(groups)
    count = max(1, round(len(groups) * config["pretraining"]["validation_fraction"]))
    reserved = set(groups[:count])
    manifest["pretraining_splits"] = {
        "train": [index for index in train if rows[index]["group_key"] not in reserved],
        "validation": [index for index in train if rows[index]["group_key"] in reserved],
    }
    if not manifest["pretraining_splits"]["train"]:
        raise ValueError("Insufficient training groups for a train-only pretraining split")
    manifest["protocol_sha256"] = record["protocol_sha256"]
    manifest["structural_metadata"] = (
        "Token alphabet and padding width describe the full input schema; "
        "all target scaling and fitted model weights use train only"
    )
    write_json(manifest_path, manifest)


def select(run_dir: Path, config: dict[str, Any], dataset: str, variant: str) -> None:
    """Select one candidate using validation scores only, with deterministic tie breaking."""
    import statistics

    candidates = []
    for candidate in config["candidates"]:
        scores, records = [], []
        for seed in config["tuning_seeds"]:
            path = run_dir / "tuning" / dataset / variant / candidate["id"] / f"s{seed}" / "result.json"
            result = json.loads(path.read_text())
            if result["status"] != "ok" or result["test_evaluated"]:
                raise ValueError("Candidate selection requires successful validation-only records")
            scores.append(result["validation_loss"])
            records.append({"path": str(path.relative_to(run_dir)), "sha256": file_hash(path)})
        candidates.append({
            "candidate_id": candidate["id"], "mean_validation_loss": statistics.mean(scores),
            "validation_losses": scores, "records": records,
        })
    selected = min(candidates, key=lambda item: (item["mean_validation_loss"], item["candidate_id"]))
    write_json(run_dir / "selection" / dataset / f"{variant}.json", {
        "dataset": dataset, "variant": variant, "candidate_id": selected["candidate_id"],
        "criterion": "mean validation objective; candidate ID breaks exact ties",
        "candidates": candidates, "test_used": False,
    })


def check_environment(config: dict[str, Any], variant: str) -> None:
    """Enforce exact worker dependency versions from the minimal isolated lock."""
    import re

    label = "legacy" if variant == "legacy_tf" else "modern"
    for line in (SOURCE_ROOT / f"benchmarks/workflow/envs/{label}.lock.txt").read_text().splitlines():
        if not line or line.startswith(("#", "--")):
            continue
        name, expected = line.split("==", 1)
        actual = importlib.metadata.version(name)
        if actual != expected:
            raise RuntimeError(f"{label} environment differs: {name} {actual} != {expected}")
    text = (SOURCE_ROOT / f"benchmarks/workflow/envs/{label}.lock.txt").read_text()
    required_python = re.search(r"# Python ([0-9.]+)", text)
    import platform

    if required_python is None or platform.python_version() != required_python.group(1):
        raise RuntimeError("Python interpreter differs from the recorded worker lock")


def main() -> None:
    """Dispatch short, composable rules; failures remain explicit and fail the DAG."""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=[
        "snapshot", "acquire", "esm-assets", "prepare", "job", "select", "report",
    ])
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--config-json")
    parser.add_argument("--dataset")
    parser.add_argument("--variant")
    parser.add_argument("--stage", choices=["pretrain", "tune", "final"])
    parser.add_argument("--seed", type=int)
    parser.add_argument("--candidate")
    parser.add_argument("--source")
    args = parser.parse_args()
    run_dir = (ROOT / args.run_dir).resolve()
    if not run_dir.is_relative_to(ROOT / "benchmarks/results") or run_dir == ROOT / "benchmarks/results":
        raise ValueError("Use a distinct run directory under benchmarks/results")
    if args.command == "snapshot":
        snapshot(run_dir, json.loads(args.config_json))
        return
    record = provenance(run_dir)
    config = record["config"]
    if args.command == "acquire":
        acquire(args.source, config)
        write_json(run_dir / "sources" / f"{identity(args.source)[:16]}.json", {
            "path": args.source, "sha256": file_hash(ROOT / args.source),
        })
    elif args.command == "esm-assets":
        esm_assets(run_dir, config)
    elif args.command == "prepare":
        prepare(run_dir, record, args.dataset)
    elif args.command == "select":
        select(run_dir, config, args.dataset, args.variant)
    elif args.command == "report":
        from benchmarks.workflow.report import report

        report(run_dir, record)
    else:
        from benchmarks.workflow.worker import run_job

        check_environment(config, args.variant)
        try:
            run_job(ROOT, run_dir, record, args.dataset, args.variant, args.stage,
                    args.seed, args.candidate)
        except Exception as error:
            write_json(run_dir / "failures" / (
                f"{args.dataset}-{args.variant}-{args.stage}-{args.candidate or 'selected'}-s{args.seed}.json"
            ), {"status": "failed", "error_type": type(error).__name__,
                "error": str(error), "traceback": traceback.format_exc()})
            raise


if __name__ == "__main__":
    main()
