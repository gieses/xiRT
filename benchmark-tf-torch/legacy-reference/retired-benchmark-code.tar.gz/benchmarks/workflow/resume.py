"""Resume an immutable measured run using its verified source and worker locks."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any


def file_hash(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def validate_run(root: Path, run: Path) -> dict[str, Any]:
    if not run.is_relative_to(root / "benchmarks/results") or run == root / "benchmarks/results":
        raise ValueError("Use a measured run directory under benchmarks/results")
    record = json.loads((run / "provenance.json").read_text())
    config = record["config"]
    config_hash = hashlib.sha256(
        json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    ).hexdigest()
    if config_hash != record["protocol_sha256"]:
        raise ValueError("Recorded protocol was modified")
    if json.loads((run / "config.json").read_text()) != config:
        raise ValueError("Archived config.json differs from the recorded protocol")
    if (root / config["run_dir"]).resolve() != run:
        raise ValueError("Recorded run_dir differs from the requested run")
    source = (run / "source").resolve()
    for name, expected in record["source_files"].items():
        path = (source / name).resolve()
        if not path.is_relative_to(source) or file_hash(path) != expected:
            raise ValueError(f"Frozen workflow source changed: {name}")
    source_hash = hashlib.sha256(
        json.dumps(
            record["source_files"], sort_keys=True, separators=(",", ":"), allow_nan=False
        ).encode()
    ).hexdigest()
    if source_hash != record["source_snapshot_sha256"]:
        raise ValueError("Recorded source manifest was modified")
    if file_hash(run / "source.tar.gz") != record["source_archive_sha256"]:
        raise ValueError("Frozen source archive was modified")
    return config


def main(argv: list[str] | None = None, *, root: Path | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run_dir", type=Path)
    args, options = parser.parse_known_args(argv)
    forbidden = {
        "--config",
        "--configfile",
        "--replace-workflow-config",
        "--snakefile",
        "-s",
        "--directory",
        "-d",
        "--profile",
        "--workflow-profile",
    }
    if any(option.split("=", 1)[0] in forbidden for option in options):
        parser.error("Resume uses the frozen workflow/configuration; choose a new run for changes")
    root = root or Path(__file__).resolve().parents[2]
    run = (root / args.run_dir).resolve()
    try:
        config = validate_run(root, run)
    except (OSError, ValueError) as error:
        parser.error(f"Cannot resume {args.run_dir}: {error}")
    source = run / "source"
    environments = (
        (Path(config["modern_python"]).parent.parent, "modern"),
        (Path(config["legacy_python"]).parent.parent, "legacy"),
        (Path("benchmarks/.venv-snakemake"), "scheduler"),
    )
    print(f"Resuming verified frozen run: {run.relative_to(root)}", flush=True)
    for environment, label in environments:
        subprocess.run(
            [
                "uv",
                "venv",
                "--python",
                "3.12.3",
                "--allow-existing",
                str(environment),
            ],
            cwd=root,
            check=True,
        )
        subprocess.run(
            [
                "uv",
                "pip",
                "sync",
                "--python",
                str(environment / "bin/python"),
                "--strict",
                str(source / "benchmarks/workflow/envs" / f"{label}.lock.txt"),
            ],
            cwd=root,
            check=True,
        )
    command = [
        str(root / "benchmarks/.venv-snakemake/bin/snakemake"),
        "--snakefile",
        str(source / "benchmarks/workflow/Snakefile"),
        "--profile",
        str(source / "benchmarks/workflow/profiles/local"),
        "--configfile",
        str(run / "config.json"),
        "--rerun-triggers",
        "mtime",
        "--rerun-incomplete",
        *options,
    ]
    return subprocess.run(command, cwd=root).returncode


if __name__ == "__main__":
    raise SystemExit(main())
