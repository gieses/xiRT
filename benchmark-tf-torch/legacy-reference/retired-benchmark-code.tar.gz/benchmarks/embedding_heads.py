"""Real locally downloaded ESM-C features and explicitly head-only LoKr adaptation."""

from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import importlib.metadata
import json
import os
import re
import resource
import sys
import time
import traceback
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from benchmarks.run import OUT, ROOT, SEEDS, digest, load_data, metrics, write_json

os.environ.setdefault("HF_HOME", str(ROOT / "benchmarks/.cache/huggingface"))
os.environ.setdefault("HF_HUB_DISABLE_TELEMETRY", "1")
os.environ.setdefault("TMPDIR", str(ROOT / "benchmarks/.cache/runtime"))
(ROOT / "benchmarks/.cache/runtime").mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(ROOT))


def features(args: argparse.Namespace) -> None:
    """Extract genuine, local-only frozen ESM-C features with hashed provenance.

    >>> callable(features)
    True
    """
    import numpy as np
    import torch

    from xirt.embeddings import ESMCEncoder

    torch.set_num_threads(2)
    manifest, rows, _ = load_data()
    columns = ("peptide_a", "peptide_b") if manifest.get("siamese", True) else ("peptide_a",)

    def project(sequence: str) -> str:
        """Explicitly remove PTM annotations only when the projection is requested.

        >>> "".join(re.findall("[A-Z]", "AKbs3ohMox"))
        'AKM'
        """
        if not args.project_ptms:
            return sequence
        return "".join(re.findall("[A-Z]", sequence)).replace("U", "C")

    sequences = sorted({project(r[key]) for r in rows for key in columns})
    start = time.perf_counter()
    encoder = ESMCEncoder(
        "esmc_300m",
        device=args.device,
        batch_size=16,
        cache_dir=ROOT / "benchmarks/.cache/embeddings",
    )
    model_seconds = time.perf_counter() - start
    start = time.perf_counter()
    encoded = encoder.encode(sequences)
    if args.device == "cuda":
        torch.cuda.synchronize()
    embedding_seconds = time.perf_counter() - start
    mapping = dict(zip(sequences, encoded))
    features = {
        name: np.stack([mapping[project(r[key])] for r in rows])
        for name, key in zip(("first", "second"), columns)
    }
    np.savez_compressed(OUT / "esm-features.npz", **features)
    metadata = {
        "status": "ok",
        "model": "esmc_300m",
        "sdk": importlib.metadata.version("esm"),
        "device": args.device,
        "embedding_dim": encoded.shape[1],
        "unique_sequences": len(sequences),
        "model_load_seconds": model_seconds,
        "embedding_seconds": embedding_seconds,
        "fingerprint": encoder.fingerprint,
        "features_sha256": digest((OUT / "esm-features.npz").read_bytes()),
        "pairs_sha256": manifest["pairs_sha256"],
        "peptide_inputs": len(columns),
        "ptm_blind_projection": args.project_ptms,
        "projection_rule": "uppercase residues in original order; lowercase/numeric PTM annotations removed; U->C"
        if args.project_ptms
        else "originally unmodified canonical sequences only",
        "pooling": "mean real residues; no BOS/EOS/pad",
        "inference": "local only",
        "model_parameter_count": sum(p.numel() for p in encoder.model.parameters()),
        "peak_process_rss_mib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024,
    }
    metadata["checkpoint_files"] = checkpoint_provenance()
    if args.device == "cuda":
        metadata["peak_gpu_allocated_mib"] = torch.cuda.max_memory_allocated() / 2**20
    write_json(OUT / "esm-features.json", metadata)
    print(json.dumps(metadata))


def checkpoint_provenance() -> list[dict[str, Any]]:
    """Identify cached base tensors and their pinned repository revision.

    >>> callable(checkpoint_provenance)
    True
    """
    home = Path(os.environ["HF_HOME"])
    records = []
    for path in sorted(home.glob("hub/models--EvolutionaryScale--esmc-300m-2024-12/blobs/*")):
        if path.is_file() and path.stat().st_size > 100_000_000:
            with path.open("rb") as handle:
                checksum = hashlib.file_digest(handle, "sha256").hexdigest()
            records.append(
                {
                    "path": str(path.relative_to(ROOT)),
                    "sha256": checksum,
                    "size_bytes": path.stat().st_size,
                }
            )
    for ref in home.glob("hub/models--EvolutionaryScale--esmc-300m-2024-12/refs/main"):
        records.append(
            {
                "repository": "EvolutionaryScale/esmc-300m-2024-12",
                "revision": ref.read_text().strip(),
            }
        )
    return records


def heads(args: argparse.Namespace) -> None:
    """Run the pilot's downstream-head-only adaptation ablation.

    >>> callable(heads)
    True
    """
    import numpy as np
    import torch
    from torch import nn

    from xirt.adapters import apply_lokr

    torch.set_num_threads(2)
    manifest, rows, _ = load_data()
    if args.features == "esm":
        meta = json.loads((OUT / "esm-features.json").read_text())
        if meta["status"] != "ok":
            raise RuntimeError("No genuine ESM-C embeddings: feature extraction blocked")
        feature_path = OUT / "esm-features.npz"
        assert digest(feature_path.read_bytes()) == meta["features_sha256"]
        assert meta["pairs_sha256"] == manifest["pairs_sha256"]
        with np.load(feature_path) as data:
            # No trainable ESM or recurrent parameters: add-merged frozen mean embeddings.
            array = data["first"] + data["second"]
    else:
        # An honest non-pretrained control, not a substitute labelled as ESM.
        array = np.array(
            [
                [r["peptide_a"].count(aa) + r["peptide_b"].count(aa) for aa in manifest["alphabet"]]
                + [len(r["peptide_a"]), len(r["peptide_b"])]
                for r in rows
            ],
            dtype=np.float32,
        )
    train, val, test = (manifest["splits"][key] for key in ("train", "validation", "test"))
    mean, std = array[train].mean(0), array[train].std(0).clip(0.01)
    X = torch.tensor((array - mean) / std, dtype=torch.float32)
    raw_y = np.array([float(r["rp_seconds"]) for r in rows], dtype=np.float32)
    norm = manifest["target_normalization"]
    y = torch.tensor((raw_y - norm["mean"]) / norm["std"])[:, None]
    # An actual train-only downstream pretraining task: binary lower/upper hSAX group.
    # No validation/test features or labels contribute to the pretrained head weights.
    source_y = torch.tensor([int(r["hsax"]) >= 6 for r in rows], dtype=torch.float32)[:, None]
    for seed in SEEDS:
        torch.manual_seed(seed)
        source = nn.Sequential(nn.Linear(X.shape[1], 32), nn.ReLU(), nn.Linear(32, 1))
        source_optimizer = torch.optim.AdamW(source.parameters(), lr=0.001, weight_decay=0.01)
        pre_start = time.perf_counter()
        for epoch in range(12):
            for idx in torch.tensor(train)[torch.randperm(len(train))].split(64):
                source_optimizer.zero_grad()
                loss = nn.functional.binary_cross_entropy_with_logits(source(X[idx]), source_y[idx])
                loss.backward()
                source_optimizer.step()
        pre_seconds = time.perf_counter() - pre_start
        initial = copy.deepcopy(source.state_dict())
        # A shared validation-only LR grid for both adaptation methods.
        for mode, lr in (
            (mode, lr) for mode in ("full_head", "lokr_head") for lr in (0.001, 0.003, 0.01)
        ):
            torch.manual_seed(seed)
            model = nn.Sequential(nn.Linear(X.shape[1], 32), nn.ReLU(), nn.Linear(32, 1))
            model.load_state_dict(initial)
            if mode == "lokr_head":
                model.requires_grad_(False)
                apply_lokr(model, ["0"], rank=4, factor=4, alpha=4.0)
                # Output task changes from fraction logits to RP regression, so train it.
                model[2].requires_grad_(True)
            optimizer = torch.optim.AdamW(
                [p for p in model.parameters() if p.requires_grad], lr=lr, weight_decay=0.01
            )
            generator = torch.Generator().manual_seed(seed + 1000)
            best, state, best_epoch = float("inf"), None, 0
            history = []
            start = time.perf_counter()
            for epoch in range(12):
                model.train()
                for idx in torch.tensor(train)[
                    torch.randperm(len(train), generator=generator)
                ].split(64):
                    optimizer.zero_grad()
                    loss = nn.functional.mse_loss(model(X[idx]), y[idx])
                    loss.backward()
                    optimizer.step()
                model.eval()
                with torch.no_grad():
                    score = float(nn.functional.mse_loss(model(X[val]), y[val]))
                history.append({"epoch": epoch + 1, "val_loss": score})
                if score < best:
                    best, best_epoch, state = score, epoch + 1, copy.deepcopy(model.state_dict())
            seconds = time.perf_counter() - start
            model.load_state_dict(state)
            model.eval()
            with torch.no_grad():
                model(X[test])
                times = []
                for _ in range(5):
                    begin = time.perf_counter()
                    prediction = model(X[test]).numpy().ravel() * norm["std"] + norm["mean"]
                    times.append(time.perf_counter() - begin)
            result = {
                "status": "ok",
                "backend": "esm-c-head" if args.features == "esm" else "composition-head",
                "seed": seed,
                "optimizer": "adamw",
                "lr": lr,
                "loss": "mse",
                "mode": mode,
                "device": "cpu",
                "framework_version": torch.__version__,
                "quality": metrics(raw_y[test], prediction),
                "validation_loss": best,
                "best_epoch": best_epoch,
                "train_seconds": seconds,
                "inference_seconds": float(np.median(times)),
                "pretraining_seconds": pre_seconds,
                "pretraining_epochs": 12,
                "pretraining_task": "binary hSAX lower/upper, train indices only",
                "parameter_count": sum(p.numel() for p in model.parameters()),
                "trainable_parameters": sum(
                    p.numel() for p in model.parameters() if p.requires_grad
                ),
                "peak_process_rss_mib": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024,
                "history": history,
                "test_count": len(test),
                "adapter_config": {"rank": 4, "factor": 4, "alpha": 4.0, "target": "0"}
                if mode == "lokr_head"
                else None,
                "features_sha256": meta["features_sha256"]
                if args.features == "esm"
                else digest(array.tobytes()),
                "runner_sha256": digest(Path(__file__).read_bytes()),
                "interpretation": "head adaptation only, NOT pretrained ESM transformer adaptation",
            }
            write_json(OUT / f"{args.features}-{mode}-{lr:g}-s{seed}.json", result)
            with (OUT / f"{args.features}-{mode}-{lr:g}-s{seed}-predictions.csv").open(
                "w"
            ) as handle:
                writer = csv.writer(handle)
                writer.writerow(["pair_index", "truth_seconds", "prediction_seconds"])
                writer.writerows(zip(test, raw_y[test], prediction))
            print(json.dumps({k: v for k, v in result.items() if k != "history"}), flush=True)


def main() -> None:
    """Dispatch feature extraction or explicitly head-only pilot adaptation.

    >>> callable(main)
    True
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["features", "heads"])
    parser.add_argument("--device", default="cuda", choices=["cuda", "cpu"])
    parser.add_argument("--features", choices=["esm", "composition"], default="esm")
    parser.add_argument("--project-ptms", action="store_true")
    args = parser.parse_args()
    try:
        (features if args.command == "features" else heads)(args)
    except Exception as exc:
        write_json(
            OUT / f"esm-{args.command}.json",
            {
                "status": "failed",
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(),
            },
        )
        raise


if __name__ == "__main__":
    main()
