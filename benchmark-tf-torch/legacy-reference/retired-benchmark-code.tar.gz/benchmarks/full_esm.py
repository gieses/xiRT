"""Extract genuine ESM features for all linked cohorts, including an explicit PTM-blind view."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    """Run local-only feature extraction followed by full-cohort supervised heads.

    >>> callable(main)
    True
    """
    successful: list[str] = []
    datasets = [
        f"{name}_{suffix}"
        for name in (
            "full_ecoli",
            "full_plink",
            "full_fa_cross",
            "full_fa_linear",
            "full_ecoli_linear",
        )
        for suffix in ("modified", "canonical")
    ]
    for dataset in datasets:
        destination = ROOT / "benchmarks/results" / dataset
        manifest = json.loads((destination / "manifest.json").read_text())
        metadata = destination / "esm-features.json"
        if metadata.exists() and (destination / "esm-features.npz").exists():
            existing = json.loads(metadata.read_text())
            if existing["status"] == "ok" and existing["pairs_sha256"] == manifest["pairs_sha256"]:
                successful.append(dataset)
                continue
        environment = os.environ.copy()
        environment.update(
            {
                "XIRT_BENCHMARK_RESULTS_DIR": str(destination),
                "HF_HOME": str(ROOT / "benchmarks/.cache/huggingface"),
                "XDG_CACHE_HOME": str(ROOT / "benchmarks/.cache"),
                "HF_HUB_OFFLINE": "1",
                "HF_HUB_DISABLE_TELEMETRY": "1",
            }
        )
        command = [
            str(ROOT / ".venv/bin/python"),
            str(ROOT / "benchmarks/embedding_heads.py"),
            "features",
            "--device",
            "cuda",
        ]
        if not manifest["canonical_only"]:
            command.append("--project-ptms")
        try:
            result = subprocess.run(command, cwd=ROOT, env=environment, timeout=300)
            if result.returncode == 0:
                successful.append(dataset)
            print(dataset, "features", result.returncode, flush=True)
        except subprocess.TimeoutExpired:
            metadata.write_text(json.dumps({"status": "timeout", "seconds": 300}) + "\n")
            print(dataset, "features TIMEOUT300", flush=True)
    if successful:
        command = [
            str(ROOT / ".venv/bin/python"),
            str(ROOT / "benchmarks/full_suite.py"),
            "--esm-only",
            "--datasets",
            *successful,
            "--workers",
            "4",
        ]
        subprocess.run(command, cwd=ROOT, check=True)
        fraction_datasets = [
            dataset
            for dataset in successful
            if dataset.endswith("_modified")
            and json.loads((ROOT / "benchmarks/results" / dataset / "manifest.json").read_text())[
                "fraction_labels_available"
            ]
        ]
        if fraction_datasets:
            command = [
                str(ROOT / ".venv/bin/python"),
                str(ROOT / "benchmarks/full_suite.py"),
                "--esm-only",
                "--multitask-only",
                "--datasets",
                *fraction_datasets,
                "--workers",
                "4",
            ]
            subprocess.run(command, cwd=ROOT, check=True)


if __name__ == "__main__":
    main()
