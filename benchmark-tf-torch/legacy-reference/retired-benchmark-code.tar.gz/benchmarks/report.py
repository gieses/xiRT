"""Generate an interpretation from measured JSON, selecting only on validation."""

from __future__ import annotations

import collections
import json
import platform
import statistics
import subprocess
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from benchmarks.run import OUT, ROOT, load_data, metrics, summarize, write_json


def mean_sd(
    records: list[dict[str, Any]], column: str, quality: bool = False, scale: float = 1
) -> str:
    """Format recorded seed-level mean and sample standard deviation.

    >>> mean_sd([{"x": 1.}, {"x": 3.}], "x")
    '2.000 ± 1.414'
    """
    values = [(r["quality"] if quality else r)[column] * scale for r in records]
    return (
        f"{statistics.mean(values):.3f} ± {statistics.stdev(values):.3f}"
        if len(values) > 1
        else f"{values[0]:.3f}"
    )


def main() -> None:
    """Generate the original pilot report, keeping full-data conclusions separate.

    >>> callable(main)
    True
    """
    import numpy as np

    manifest, rows, _ = load_data()
    records = [json.loads(path.read_text()) for path in sorted(OUT.glob("*-s[0-9]*.json"))]
    success = [r for r in records if r["status"] == "ok"]
    groups = collections.defaultdict(list)
    for record in success:
        key = record["backend"], record["optimizer"], record["loss"], record.get("mode", "")
        groups[key].append(record)
    selected = []
    for key, candidates in groups.items():
        by_rate = collections.defaultdict(list)
        for record in candidates:
            by_rate[record["lr"]].append(record)
        rate = min(
            by_rate, key=lambda lr: statistics.mean(r["validation_loss"] for r in by_rate[lr])
        )
        selected.extend(by_rate[rate])
    write_json(OUT / "selected-validation.json", selected)
    test = manifest["splits"]["test"]
    truth = np.array([float(rows[i]["rp_seconds"]) for i in test])
    baseline = metrics(truth, np.full(len(test), manifest["target_normalization"]["mean"]))
    labels = np.array([int(r["hsax"]) - 1 for r in rows])
    majority = collections.Counter(labels[manifest["splits"]["train"]]).most_common(1)[0][0]
    binary_majority = collections.Counter(
        (labels[manifest["splits"]["train"]] >= 5).astype(int)
    ).most_common(1)[0][0]
    fraction_baselines = {
        "categorical_train_majority_accuracy": float((labels[test] == majority).mean()),
        "binary_train_majority_accuracy": float(((labels[test] >= 5) == binary_majority).mean()),
        "all_pairs_class_counts": dict(collections.Counter(int(v) + 1 for v in labels)),
    }
    write_json(
        OUT / "baseline.json",
        {
            "rp_train_mean": baseline,
            "fraction_baselines": fraction_baselines,
            "description": "Training mean only, seconds; no test fitting",
        },
    )
    gpu = subprocess.run(
        ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader"],
        capture_output=True,
        text=True,
    ).stdout.strip()
    freeze = (
        "import importlib.metadata as m;"
        "print('\\n'.join(sorted(d.metadata['Name']+'=='+d.version for d in m.distributions())))"
    )
    environment = {
        "platform": platform.platform(),
        "processor": platform.processor(),
        "cpu_model": next(
            (
                line.split(":", 1)[1].strip()
                for line in Path("/proc/cpuinfo").read_text().splitlines()
                if line.startswith("model name")
            ),
            "",
        ),
        "gpu_available_not_used_for_recurrent": gpu,
        "legacy_freeze": subprocess.check_output(
            [
                str(ROOT / "benchmarks/.venv-legacy/bin/python"),
                "-c",
                freeze,
            ],
            text=True,
        ),
    }
    modern_python = ROOT / ".venv/bin/python"
    if modern_python.exists():
        environment["modern_freeze"] = subprocess.check_output(
            [
                str(modern_python),
                "-c",
                freeze,
            ],
            text=True,
        )
    write_json(OUT / "environment.json", environment)
    lines = [
        "# xiRT measured legacy / PyTorch and experiment benchmark",
        "",
        "Executed 2026-10-12. Results below are measured, not extrapolated. "
        "This is a small-data CPU comparison, not a claim of production superiority.",
        "",
        "## Design and reproducibility",
        "",
        f"- Source: `{manifest['source']}`; SHA256 `{manifest['source_sha256']}`.",
        f"- Actual legacy commit: `{manifest['legacy_commit']}`; runtime `git show` executes that source.",
        f"- New package source snapshot: "
        f"`{json.loads((OUT / 'new-source-index.json').read_text())['snapshot_sha256']}` "
        "(`new-source-index.json` lists every source SHA256). The final new-network suite runs against "
        "one immutable local snapshot so concurrent migration edits cannot mix implementations across seeds.",
        f"- {manifest['pair_count']} unique unordered unmodified TT peptide pairs sampled reproducibly from "
        f"{manifest['eligible_unique_pairs']} eligible pairs; FDR ≤ 1%. Duplicate measurements stay within "
        "one pair and use RP mean/hSAX mode. No reverse-order duplicate crosses splits.",
        "- Saved indices: 700 training / 150 validation / 150 test in `manifest.json`; seeds 17/29/43. "
        "Subset seed 20261012, split seed 101. RP targets standardized using training statistics only, "
        "and errors converted back to seconds.",
        "- Matched recurrent hyperparameters: embedding 8, unidirectional tanh GRU 16, one linear dense layer 16, "
        "add Siamese merge, output 1 linear/MSE, no BN/dropout/regularization, batch 64, 12 epochs. "
        f"input length {manifest['max_length']}, alphabet size 21 including padding. "
        "The same real-pair manifest is used for all experiments.",
        "- Best epoch selected using validation loss only. Optimizer LR chosen using mean validation loss "
        "across three seeds. Candidate test metrics were recorded automatically but never used for selection. "
        "Classification loss variants are separate objectives, not selected against each other using raw loss.",
        "- Baseline: training-mean RP, no test fitting: "
        f"MAE {baseline['mae']:.2f}s, RMSE {baseline['rmse']:.2f}s, R² {baseline['r2']:.3f}.",
        "- CPU, two framework threads with MKL/OMP capped at two; available GPU is not used in recurrent comparisons. "
        f"Host CPU: {environment['cpu_model']}. Available GPU: {gpu}.",
        "",
        "## Regression: mean ± sample SD over training seeds",
        "",
        "| Backend / optimizer / mode | seeds | LR | MAE s | RMSE s | R² | Pearson | train s | inference ms | params |",
        "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    chosen_groups = collections.defaultdict(list)
    for r in selected:
        chosen_groups[(r["backend"], r["optimizer"], r["loss"], r.get("mode", ""))].append(r)
    for (backend, optimizer, loss, mode), runs in sorted(chosen_groups.items()):
        if loss != "mse":
            continue
        mode_label = mode or ("frozen ESM head" if backend == "torch-esm" else "recurrent")
        lines.append(
            f"| {backend} / {optimizer} / {mode_label} | {len(runs)} | {runs[0]['lr']:g} | "
            + " | ".join(mean_sd(runs, k, True) for k in ("mae", "rmse", "r2", "pearson"))
            + f" | {mean_sd(runs, 'train_seconds')} | {mean_sd(runs, 'inference_seconds', scale=1000)}"
            + f" | {runs[0]['parameter_count']} |"
        )
    legacy = chosen_groups.get(("legacy", "adam", "mse", ""))
    modern = chosen_groups.get(("torch", "adam", "mse", ""))
    if legacy and modern and len(legacy) == len(modern) == 3:
        legacy_rmse = statistics.mean(r["quality"]["rmse"] for r in legacy)
        modern_rmse = statistics.mean(r["quality"]["rmse"] for r in modern)
        workflow_ratio = statistics.mean(r["train_seconds"] for r in legacy) / statistics.mean(
            r["train_seconds"] for r in modern
        )
        inference_ratio = statistics.mean(r["inference_seconds"] for r in legacy) / statistics.mean(
            r["inference_seconds"] for r in modern
        )
        lines += [
            "",
            f"For the prespecified Adam comparison, mean test RMSE was {legacy_rmse:.2f}s "
            f"(legacy) versus {modern_rmse:.2f}s (new), a {(modern_rmse / legacy_rmse - 1) * 100:+.1f}% "
            f"change. Measured legacy/new mean train-workflow time ratio was {workflow_ratio:.2f}×, "
            f"and held-out inference ratio {inference_ratio:.2f}×. These ratios apply only to this "
            "small CPU fixture and differ in padding handling and initialization; they do not isolate "
            "a pure framework effect or prove a general quality advantage.",
        ]
    lines += [
        "",
        "## Fraction classification: same fixed splits",
        "",
        "hSAX categorical: real fractions 1–10. Binary: prespecified fractions 6–10 vs 1–5. "
        "Focal γ=2, no α weighting. Accuracy and macro recall provide complementary views; "
        "these are real hSAX labels, not RP-derived artificial bins.",
        f"Training-majority baselines: categorical accuracy "
        f"{fraction_baselines['categorical_train_majority_accuracy']:.3f}, binary accuracy "
        f"{fraction_baselines['binary_train_majority_accuracy']:.3f}. All-pair class counts: "
        f"`{fraction_baselines['all_pairs_class_counts']}`. Macro recall averages supported test classes.",
        "",
        "| Backend / loss | seeds | accuracy | macro recall | train s |",
        "|---|---:|---:|---:|---:|",
    ]
    for (backend, optimizer, loss, mode), runs in sorted(chosen_groups.items()):
        if loss == "mse":
            continue
        lines.append(
            f"| {backend} / {loss} | {len(runs)} | {mean_sd(runs, 'accuracy', True)} | "
            f"{mean_sd(runs, 'macro_recall', True)} | {mean_sd(runs, 'train_seconds')} |"
        )
    lines += [
        "",
        "## Resource measurements",
        "",
        "| Backend / optimizer / mode (RP) | process peak RSS MiB | total params | trainable params |",
        "|---|---:|---:|---:|",
    ]
    for (backend, optimizer, loss, mode), runs in sorted(chosen_groups.items()):
        if loss != "mse":
            continue
        mode_label = mode or ("frozen ESM head" if backend == "torch-esm" else "recurrent")
        lines.append(
            f"| {backend} / {optimizer} / {mode_label} | "
            f"{mean_sd(runs, 'peak_process_rss_mib')} | {runs[0]['parameter_count']} | "
            f"{runs[0].get('trainable_parameters', runs[0]['parameter_count'])} |"
        )
    full_heads = chosen_groups.get(("esm-c-head", "adamw", "mse", "full_head"))
    lokr_heads = chosen_groups.get(("esm-c-head", "adamw", "mse", "lokr_head"))
    if full_heads and lokr_heads and len(full_heads) == len(lokr_heads) == 3:
        full_rmse = statistics.mean(r["quality"]["rmse"] for r in full_heads)
        lokr_rmse = statistics.mean(r["quality"]["rmse"] for r in lokr_heads)
        reduction = 100 * (
            1 - lokr_heads[0]["trainable_parameters"] / full_heads[0]["trainable_parameters"]
        )
        lines += [
            "",
            f"On real ESM-C frozen features, validation-selected LoKr-head adaptation reduced "
            f"trainable parameters by {reduction:.1f}% ({full_heads[0]['trainable_parameters']} → "
            f"{lokr_heads[0]['trainable_parameters']}). Mean held-out RMSE was {full_rmse:.2f}s "
            f"for full-head versus {lokr_rmse:.2f}s for LoKr-head ({(lokr_rmse / full_rmse - 1) * 100:+.1f}%). "
            "Parameter efficiency is not automatically a speed or accuracy improvement: this simple "
            "implementation materializes the Kronecker update. Longer training/rank sweeps could change "
            "the trade-off and are not established here.",
        ]
    lines += [
        "",
        "## Fairness, interpretation and limitations",
        "",
        "- **Architecture-compatible, not numerical parity.** New xiRT intentionally masks padding "
        "(legacy learns padding embeddings), and honors dense activation (this fixture sets linear to "
        "match legacy's omission). Initialization and Adam epsilon differ by framework. "
        "Both GRUs use separate recurrent/input biases; independent seeds do not imply identical weights "
        "or batch orders. Differences cannot be attributed solely to the framework.",
        "- Legacy source is unmodified. Runtime shims address tf-keras 2.16's float seed bound rejected "
        "by Python 3.12, and assign requested optimizer learning_rate because legacy `lr=` is deprecated. "
        "The initial incompatibility was actually observed, not silently replaced by a recreated model.",
        "- Legacy classification also uses the explicit categorical_accuracy metric name, avoiding "
        "tf-keras's ambiguous accuracy rank-inference failure with nested single-task targets. "
        "The task loss, outputs and externally calculated accuracy are unchanged.",
        "- Adam has zero weight decay; AdamW/Muon use 0.01, Lion 0.1, with Lion rates 10× lower. "
        "Search budgets are two rates per experimental optimizer. Muon routes hidden matrices to Muon "
        "and embeddings/output/vector parameters to AdamW. This is a hybrid, not all-Muon experiment.",
        "- Train wall time includes validation and per-epoch checkpoint snapshots, excludes imports/build. "
        "New fit additionally evaluates the training set after every epoch; TensorFlow fit does not. "
        "Thus this measures public training workflow, not kernel-only speed. Inference: median of five "
        "complete 150-pair calls after warm-up, including adapters/NumPy conversion.",
        "- Process peak RSS includes framework import/runtime, not incremental model memory; it is Linux "
        "ru_maxrss and should not be read as tensor-only memory. GPU allocation is separately reported "
        "only where GPU feature extraction occurred. Head grid jobs share a process, so their RSS peaks "
        "are cumulative and are not independently isolated memory comparisons.",
        "- Same peptide may occur in distinct pairs across splits. Pair-level deduplication prevents exact "
        "pair leakage but is not a peptide-, protein-, or experiment-held-out generalization benchmark. "
        "No significance test or universal optimizer recommendation is justified by three seeds and one split.",
        "- Only 12 epochs and 1000 pairs, a deliberately compact architecture and narrow LR grids. "
        "Some best epochs hit the final epoch; this is budget-limited optimization, not convergence. "
        "RP group means and fraction modes collapse repeated runs and reduce label variance.",
        "- Sequence-only fixture omits crosslink position and modification information; it excludes "
        "modified/noncanonical sequences rather than pretending to encode them as ESM-compatible peptides.",
        "- ESM embeddings were genuinely extracted from the downloaded pretrained local model, never "
        "random embeddings. Feature extraction cost must be added for cold-cache end-to-end comparison. "
        "Head-only LoKr starts from an actual train-only hSAX-trained downstream head, then adapts RP; "
        "**it does not train LoKr inside the pretrained ESM transformer**. ESM/full-head and LoKr-head "
        "are representation/adaptation experiments, not matched recurrent architecture comparisons.",
        "- Actual xiRT frozen-feature route (`torch-esm`) uses the 960-dimensional ESM-C 300M vectors "
        "with a linear dense-16 RP head, no recurrent encoder; both peptide branches are normalized "
        "using only training embeddings. The separate transfer experiments use dense-32/ReLU/output-1 "
        "heads, hSAX pretraining for 12 train-only epochs, then RP adaptation for 12 epochs. Head times "
        "exclude this pretraining and ESM extraction; per-run JSON records pretraining cost.",
        "- ESM table parameter counts describe the downstream trained head only; the downloaded frozen "
        "backbone has **332,997,184 parameters** and is not resident in CPU head-training subprocesses. "
        "Its separate GPU extraction memory and cold load/embedding costs are recorded below.",
        "- Head-adaptation LR grid is 0.001/0.003/0.01 shared by full and LoKr methods. It was expanded "
        "after the initial 0.001 pilot showed high **validation** error and a final-epoch best checkpoint; "
        "pilot artifacts remain under `pilot/`. Final choice uses only mean validation loss. "
        "Composition heads are an explicitly non-pretrained feature control, not artificial ESM embeddings.",
        "- Lion and Muon underfit strongly in this 12-epoch/two-rate experiment; it is not evidence that "
        "these optimizers universally fail. Focal categorical results are close to ordinary cross entropy "
        "and binary focal does not show a clear improvement here. This small comparison cannot establish "
        "broad optimizer or loss recommendations.",
        "",
        "## Failures / resource blocks",
        "",
    ]
    failures = [r for r in records if r["status"] != "ok"]
    for path in (OUT / "esm-features.json", OUT / "esm-heads.json"):
        if path.exists():
            result = json.loads(path.read_text())
            if result["status"] != "ok":
                lines.append(f"- `{path.name}`: {result.get('error', result['status'])}")
            elif path.name == "esm-features.json":
                lines.append(
                    f"- Real ESM-C extraction succeeded: {result['unique_sequences']} unique peptides, "
                    f"{result['embedding_dim']} features; load {result['model_load_seconds']:.2f}s, "
                    f"embedding {result['embedding_seconds']:.2f}s on {result['device']}; "
                    f"peak GPU allocation {result.get('peak_gpu_allocated_mib', 0):.2f} MiB, "
                    f"process RSS {result['peak_process_rss_mib']:.2f} MiB. "
                    "`esm-features.json` records actual checkpoint SHA256 and repository revision."
                )
    if failures:
        lines += [
            f"- {r['backend']} {r['optimizer']} {r['loss']} seed {r['seed']}: {r['status']}. "
            "See individual JSON and ignored local logs."
            for r in failures
        ]
    else:
        lines.append(
            "- No failed recurrent benchmark jobs remain; initial tf-keras/Python 3.12 "
            "compatibility failure and scoped fixes are documented above and in "
            "`compatibility-events.json`."
        )
    lines += [
        "",
        "## Re-run",
        "",
        "```bash",
        "python3 benchmarks/run.py prepare --rows 1000 --epochs 12",
        "python3 benchmarks/run.py suite",
        ".venv/bin/python benchmarks/embedding_heads.py features --device cuda",
        ".venv/bin/python benchmarks/embedding_heads.py heads",
        ".venv/bin/python benchmarks/report.py",
        "```",
        "",
        "Install isolated legacy requirements and modern experiment requirements as described in "
        "`benchmarks/README.md`. Existing job JSONs are resumed; pass `--rerun` to replace measured runs.",
        "",
        "## Primary references (checked 2026-10-12)",
        "",
        "- TensorFlow 2.16/Keras 2 switch: https://blog.tensorflow.org/2024/03/whats-new-in-tensorflow-216.html",
        "- Lion authors' LR/decay guidance: https://github.com/google/automl/blob/master/lion/README.md",
        "- Muon matrix-only/AdamW routing: https://docs.pytorch.org/docs/stable/generated/torch.optim.Muon.html",
        "- Focal Loss original paper: https://arxiv.org/abs/1708.02002",
        "- ESM official upstream (now redirects to Biohub; 3.2 pinned for API compatibility): "
        "https://github.com/evolutionaryscale/esm",
        "- LyCORIS LoKr implementation family: https://github.com/KohakuBlueleaf/LyCORIS",
        "",
        "All run metrics and histories are in per-job JSON; selected jobs in `selected-validation.json`; "
        "all tabular jobs in `summary.csv`; per-job held-out predictions in CSV; raw data/splits/hash "
        "provenance in `pairs.csv` and `manifest.json`.",
    ]
    report = OUT / "report.md"
    marker = "<!-- FULL-COHORT-REPORT-END -->"
    prefix = ""
    if report.exists() and marker in report.read_text():
        prefix = report.read_text().split(marker, 1)[0] + marker + "\n\n"
    report.write_text(prefix + "\n".join(lines) + "\n")
    summarize()


if __name__ == "__main__":
    main()
